# #################################################################
# Date      : 23-Dec-2014
# Author    : Harikrishnan GN
# Purpose   : Module to Parse and perform Remediation
# Updated   : 06-may-2016 by Umesh - Updated .Save() method of xml to support nano
# Updated   : 06-june-2016 by Umesh - Added functions Set-WCRLGPSettingsFromCSV and New-WCRLGPCSVFile 
#             to apply LGPO policies on Nano server

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

#region ModuleVariables
# this variable will hold value of baseline XML file supplied to the script that calls this module
# all functions of this module will reference it for baseline XML processing and updation
# once the caller script is done with processing of baseline XML then it should call a function to return
# this variable back to caller.
[xml]$ReportXML = $null
#endregion ModuleVariables

#region BaselineGetSetTestFunctions
# set module level baseline xml variable for policy processing. it should 
# be called before calling any other functions from this module. 
# ------------------------------------------------------------------------
Function Set-WCRXMLVariable([string]$ReportXMLFile,[Switch]$UpdateBranding) {
    Write-WCLog -Message "[Set-WCBXMLVariable]"
    try {
        #read the contents of the xml to variable
        [xml]$script:ReportXML = Get-Content $ReportXMLFile -ErrorAction Stop

        #check whether the report is a scan report or remediation report
        if($script:ReportXML.WinCompliance.RemediationReport -ne $null){
            Write-WCLog -Level Error -Message "The ReportXML is a Remediation Report.Remediation can be performed only using WinCompliance Scan Report";
            return "The ReportXML is a Remediation Report.Remediation can be performed only using WinCompliance Scan Report";
        }
		 #check whether the report supports remediation
        if($script:ReportXML.WinCompliance.SupportsRemediation -eq $null){
            
            Write-WCLog -Level Error -Message "The ReportXML does not support Remediation.";
            return "The ReportXML does not support Remediation.";
        }
        elseif(($script:ReportXML.WinCompliance.SupportsRemediation).ToString() -eq "false"){
            
            Write-WCLog -Level Error -Message "The ReportXML does not support Remediation.";
            return "The ReportXML does not support Remediation.";
        }
		
		#Update Branding if applicable
		if($UpdateBranding.IsPresent) {
			[xml]$script:ReportXML = Set-SOEBrandnginXML -SOEBuildXML $script:ReportXML
		}
		
        Write-WCLog -Level debug -Message "Successfully read baseline xml file into script variable"
		return "Success"
    }
    catch {
        Write-WCLog -Level error -Message "Error reading baseline xml file into script variable"
        Write-WCLog -Level error -Message ($_.Exception.Message)
		return $_.Exception.Message
    }
}
Function Set-WCRLogPath([string]$LogPath) {
    Write-WCLog -Message "[Set-WCRLogPath]"
    try {
        New-Item -ItemType Directory -Path $LogPath -Force | Out-Null;
    }
    catch {
        Write-WCLog -Level error -Message "Error assigning logpath Variable";
        Write-WCLog -Level error -Message ($_.Exception.Message)
    }
}
# returns contents of module level xml variable. null if it is not set
# --------------------------------------------------------------------
Function Get-WCRXMLVariable {
    return $script:ReportXML
}

# Test if module level baseline xml variable holds valid xml data
# ----------------------------------------------------------------
Function Test-WCRXMLVariable {
    return ($script:ReportXML -ne $null)
}
#endregion
# This function will update environment strings in Default Value field provided a list of policies
Function Update-WCREnvironmentVariables($Policies) {
	try {
		#Collect all Policy IDs for Processing
		$arrPolicyID = @();
        $Policies | Foreach-Object { $arrPolicyID += $_.ID }
		#Identify the PolicyIDs in BaseLine XML
		$colPolicy = (Get-WCXMLNodes -Xml $script:ReportXML -XPath "//Policy") | Where-Object { $arrPolicyID -contains $_.ID }
		#Identify the Policy that needs environment Variables Updation
		$PolFilter = $colPolicy | where { $_.DefaultValue.Value -like "*%*%*" }
		#Update the Variables
		if($PolFilter -ne $NULL) {
			$PolFilter | Foreach-Object { $_.DefaultValue.Value = [System.Environment]::ExpandEnvironmentVariables($_.DefaultValue.Value) }
		}
	}
	catch { 
		Write-WCLog -Level error -Message "Error updating environmental variables"
        Write-WCLog -Level error -Message ($_.Exception.Message)
	}
}
#region Get BaseLine XML Nodes
# Test if module level baseline xml variable holds valid xml data
Function Get-WCRPolicyByType {
<#
  .SYNOPSIS
  Get-WCRPolicyByType
  .DESCRIPTION
  Function to Get WC Poliy By Type
  .EXAMPLE
  Get-WCRPolicyByType "PolicyType" "HS002","PP002","AP001"
  .PARAMETER PolicyType
  PolicyType in the XML file Eg: SystemAccess
  .PARAMETER Array of Policy IDs to set
  #>
[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)]
    [string] $PolicyType,
	[Parameter(Mandatory=$true)]
    [string[]] $PolicyIDs
)
    $retXML = (Get-WCXMLNodes -Xml $script:ReportXML -XPath "//Policy") | Where-Object { ($_.PolicyType -eq $PolicyType) -and ($PolicyIDs -contains $_.ID) }
    return $retXML

}
# Test if module level baseline xml variable holds valid xml data
#--------------------------------------------------------------------------------------------------------------
#Function to read policies for remediation
#--------------------------------------------------------------------------------------------------------------
Function Get-WCRPoliciesToRemediate {
<#
  .SYNOPSIS
  Get-WCRPolicyType
  .DESCRIPTION
  Function to Get List of distinct Policy Ty[pes ina a given list of Policy IDs
  .EXAMPLE
  Get-WCRPolicyByType "PolicyType" "HS002","PP002","AP001"
  .PARAMETER PolicyType
  PolicyType in the XML file Eg: SystemAccess
  .PARAMETER Array of Policy IDs to set
  #>
[CmdletBinding()]
Param(
    $BaseLineXML, #Use the BaseLineXML if passed else use $script:ReportXML 
    [string[]] $PolicyIDs,
    [switch] $RemediateAll,
    [ValidateSet("Remediate", "Revert")]
    [string] $RemediationType
)
    $HardwareVendor = Get-HardwareVendorName; #Get Hardware Vendor
	$InterfaceMode = Get-WCInterfaceMode -ShortName;
    #Get which XML to use for filtering
    $BaseXML = $script:ReportXML;
    if($BaseLineXML -ne $null) { $BaseXML = $BaseLineXML;} #Use the BaselineXML if passed

    if($RemediateAll.IsPresent) { #Read all policies where readonly is false and platform as applicable
        $retXML = (Get-WCXMLNodes -Xml $BaseXML -XPath "//Policy") | Where-Object {($_.ReadOnly -eq "false")  -and ($_.TestResult -ne "Passed") -and ($_.Platform -eq "All" -or $_.Platform -eq $HardwareVendor)} 
    }
    else {  #Read the policies in the PolicyIDs argument where readonly is false and platform as applicable
        $retXML = (Get-WCXMLNodes -Xml $BaseXML -XPath "//Policy") | Where-Object { ($PolicyIDs -contains $_.ID)  -and ($_.TestResult -ne "Passed") -and ($_.ReadOnly -eq "false") -and ($_.Platform -eq "All" -or $_.Platform -eq $HardwareVendor)  } 
    }
	#Check whether Interface Mode Applicable
	$retXML = $retXML | Where-Object { ($_.Runson -eq "All") -or ($_.Runson -like "*$InterfaceMode*") }
	
    #if remediation Type is revert then current value has to be applied,So consider policies where processed field is set to true
    if($RemediationType -eq "revert") {$retXML = $retXML | Where-Object { $_.Processed -eq "True"} }
    #return XML Policy Node
    return $retXML

}
#--------------------------------------------------------------------------------------------------------------
#Function to read categories in Section for remediation
#--------------------------------------------------------------------------------------------------------------
Function Get-WCRCategoriesBySection {
<#
  .SYNOPSIS
  Get-WCRCategoriesBySection
  .DESCRIPTION
  Function to Get polciies from a list of categories
  .EXAMPLE
  Get-WCRCategoriesBySection -Section "Local Security Policy","SOE Configuration"
  .PARAMETER Section
  #>
[CmdletBinding()]
Param(
    $BaseLineXML, #Use the BaseLineXML if passed else use $script:ReportXML 
    [string[]] $Section
)
    #Get which XML to use for filtering
    $BaseXML = $script:ReportXML;
    if($BaseLineXML -ne $null) { $BaseXML = $BaseLineXML;} #Use the BaselineXML if passed\
	#Get the Section from XML
	$xmlSection = (Get-WCXMLNodes -Xml $BaseXML -XPath "//Section") | Where-Object {$_.Name -in $Section } 
	$xmlCat = $xmlSection.Category
    #return XML Category
    return $xmlCat

}
#--------------------------------------------------------------------------------------------------------------
#Function to read policies for remediation
#--------------------------------------------------------------------------------------------------------------
Function Get-WCRPoliciesByCategory {
<#
  .SYNOPSIS
  Get-WCRPoliciesByCategory
  .DESCRIPTION
  Function to Get polciies from a list of categories
  .EXAMPLE
  Get-WCRPoliciesByCategory -Category "Password Policy","AuditPolicy"
  .PARAMETER Category
  #>
[CmdletBinding()]
Param(
    $BaseLineXML, #Use the BaseLineXML if passed else use $script:ReportXML 
    [string[]] $Category
)
    #Get which XML to use for filtering
    $BaseXML = $script:ReportXML;
    if($BaseLineXML -ne $null) { $BaseXML = $BaseLineXML;} #Use the BaselineXML if passed\
	#Get the Category from XML
	$xmlCategory = (Get-WCXMLNodes -Xml $BaseXML -XPath "//Category") | Where-Object {$_.Name -in $Category } 
	$xmlPolicy = $xmlCategory.Policy
    #return XML Policy Nodes
    return $xmlPolicy

}

#--------------------------------------------------------------------------------------------------------------
#Function to update the remediation report with log the remediation time etc
#--------------------------------------------------------------------------------------------------------------
Function Write-WCRRemediationSummary {
<#
  .SYNOPSIS
  Set-WCRRemediationAction
  .DESCRIPTION
  Function to Set the Remediation Action
  .WCRRemediationAction
  Set-WCRRemediation PolicyIDs
  .PARAMETER xmlPolicyNodes to Remediate
  #>
[CmdletBinding()]
Param(
    [ValidateSet("Remediate", "Revert")]
    [string]$RemediationType = "Remediate",
    $PolicyIDs,
    $Date,
    $RemediationLog,
	$LogFilePath
)
    Write-WCLog -Message "[Write-WCRRemediationSummary]";
    try {
        $Script:ReportXML.WinCompliance.SetAttribute("RemediationReport","True");
        $Script:ReportXML.WinCompliance.SetAttribute("RemediationDate",$Date);
        $Script:ReportXML.WinCompliance.SetAttribute("RemediationType",$RemediationType);
	    $Script:ReportXML.WinCompliance.SetAttribute("RemediationLog",$RemediationLog);
        $Script:ReportXML.WinCompliance.SetAttribute("LogFilePath",$LogFilePath);
    
    }
    Catch {  
       Write-WCLog -Level Error -Message $_.Exception.Message;
    }
}
#endregion
#--------------------------------------------------------------------------------------------------------------
#Function to Start-Remediation
#--------------------------------------------------------------------------------------------------------------
Function Start-WCRRemediation {
<#
  .SYNOPSIS
  Start-WCRRemediation
  .DESCRIPTION
  Function to Start the WC Remediation
  .EXAMPLE
  Start-WCRRemediation "HS002","PP002","AP001"
  .PARAMETER Array of Policy IDs to set
  .PARAMETER ReportXML
  XML that has to be PROCESSED
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string] $ReportXMLFilePath,
    [Parameter(Mandatory=$true,ParameterSetName="PolicyID")]
    [string[]] $PolicyIDs,
    [Parameter(Mandatory=$true,ParameterSetName="RemediateAll")]
    [Switch] $RemediateAll,
    [ValidateSet("Remediate", "Revert")]
    [string]$RemediationType = "Remediate",
    [Switch] $HideProgress,
    [Parameter(Mandatory=$true)]
	$LogPath,
	$LogFilePath,
	[Parameter(Mandatory=$true)]
    $TimeStamp,
	[Parameter(Mandatory=$true)]
	$RemediationReportFile
)
	
    #Set Log Path
    $RemediationLogFolderName = New-WCRemediationLogFolderName $timeStamp;
    $RemediationLogFolder = "$LogPath\$RemediationLogFolderName";

    Write-WCLog -Message "[Start-WCRRemediation]";

    #Log the Policies to be remediated Remediation 
    if($RemediateAll.IsPresent) { Write-WCLog -Level info -Message "RemediateAll : True";}
	else { Write-WCLog -Level info -Message ("Policy IDs : " + @($PolicyIDs) -join ",");}

    try {
        #Set Log Path
        Set-WCRLogPath -LogPath $RemediationLogFolder;

        #Set the remediation Report Summary Variables in Remediation Report
        Write-WCRRemediationSummary -RemediationType $RemediationType -PolicyIDs $PolicyIDs -Date $timeStamp -RemediationLog $RemediationLogFolder -LogFilePath $LogFilePath

        #Get all Policies to Remediate
        $PolicyList = Get-WCRPoliciesToRemediate -RemediateAll:$RemediateAll -PolicyIDs $PolicyIDs -RemediationType $RemediationType;
		
		#Expand Environment Strings in Default Value
		Update-WCREnvironmentVariables $PolicyList

        #If RemediationType by default is  Remediate - so use Default Value
        $RemediationValue = "DefaultValue"
        #If Remediation Type is Revert use Current Value
        if($RemediationType -eq "Revert") { $RemediationValue = "CurrentValue"; }

        if($PolicyList -ne $NULL) {

            #Select the distinct list of Policy Types for the PolicyIDs
            $ColPolicyTypes = @((($PolicyList) | Where-Object { $_.PolicyType.Length -gt 0  } | Select-Object PolicyType -Unique).PolicyType)

            if($ColPolicyTypes -contains "LGPRegistry") {
                $lgpoPolicyList = ($PolicyList | Where-Object {$_.PolicyType -eq "LGPRegistry" })
                if((Get-WCInterfaceMode -ShortName) -ne 'Nano') { # not running on Nano server
                    Write-WCLog -Message "Processing Local Group Policy Registry related Policies"
                
                    #Calling Function to Generate the log file for LGPO.exe
                    $LGPOLogPath =  "$RemediationLogFolder\$RemediationLogFolderName" + "-LGPO.txt";
                    $LGPOLogPath =  New-WCRLGPInputFile -PolicyList ($PolicyList | Where-Object {$_.PolicyType -eq "LGPRegistry" }) -RemediationValue $RemediationValue -LGPOLogPath $LGPOLogPath  -HideProgress:$HideProgress;
                
                    #Run LGPO.exe utility to update Local GPO
                    if($LGPOLogPath -ne $null) {
                        Set-WCRLGPSettings -Path $LGPOLogPath | Out-Null ;
                    }
                }
                else { # this is Nano server! treat it differently
                    Write-WCLog -Message "Processing Local Group Policy Registry related Policies (on nano server)"
                    $csvPath = "$RemediationLogFolder\$RemediationLogFolderName" + "-LGPO.csv"
                    $csvPath = New-WCRLGPCSVFile -PolicyList $lgpoPolicyList -RemediationValue $RemediationValue -CSVFilePath $csvPath -HideProgress:$HideProgress
                    if($csvPath -eq $NULL) { # some issues with CSV conversion, log and exit
                        Write-WCLog -Message "Issues encountered during temporary CSV file generation, LGPO policies cannot be applied. See log file for detals"
                    }
                    else {
                        Write-WCLog -Message "Applying LGPO policies"
                        Set-WCRLGPSettingsFromCSV -CSVPath $csvPath  | Out-Null ;
                        Write-WCLog -Message "LGPO policies applied, refer to log for details"
                    }
                }
            }

            if($ColPolicyTypes -contains "Registry") {
                
                Write-WCLog -Message "Processing Registry related Policies"
                
                #Calling Function to Set/Delete RegistryKeys
                Update-WCRRegistryPolicy -PolicyList ($PolicyList | Where-Object {$_.PolicyType -eq "Registry" }) -RemediationValue $RemediationValue  -HideProgress:$HideProgress  | Out-Null ;
				
				Write-WCLog -Message "Completed Processing Registry related Policies"
            }

            if($ColPolicyTypes -contains "Service.StartUpType" -or $ColPolicyTypes -contains "Service.State") {
                
                Write-WCLog -Message "Processing Service related Policies"
                
                #Calling Function to change Service Status
                Update-WCRServicePolicy -PolicyList ($PolicyList | Where-Object {$_.PolicyType -eq "Service.StartUpType" -or $_.PolicyType -eq  "Service.State" }) -RemediationValue $RemediationValue  -HideProgress:$HideProgress  | Out-Null ;
				
				Write-WCLog -Message "Completed Processing Service related Policies"
            }
			
			if($ColPolicyTypes -contains "psmodule") {
                Write-WCLog -Message "Processing Policy Type: psModule"
				#Calling Function to Remediate UserProfile related Policies
                Update-psModuleProfilePolicy -PolicyList ($PolicyList | Where-Object {$_.PolicyType -eq "psModule" -and $_.DataType -eq "ProfileRegistry" }) -RemediationType $RemediationType -HideProgress:$HideProgress  | Out-Null ;
				
                #Calling Function to run psscripts for remediation
                Update-psModulePolicy -PolicyList ($PolicyList | Where-Object {$_.PolicyType -eq "psModule" -and $_.DataType -ne "ProfileRegistry" }) -RemediationType $RemediationType -HideProgress:$HideProgress | Out-Null ;
				
				Write-WCLog -Message "Completed Processing Policy Type: psModule"
            }
			
			#These two policy types should be applied only at the end of remediation action
			if($ColPolicyTypes -contains "SystemAccess" -or $ColPolicyTypes -contains "EventAudit" -or $ColPolicyTypes -contains "LSPRegistry" -or $ColPolicyTypes -contains "PrivilegeRights" -or $ColPolicyTypes -contains "Kerberos") {            
                
                Write-WCLog -Message "Processing Local Security Policies"
                
                #Calling Function to Generate SecEdit INF File
                $SecEditFilePath =  "$RemediationLogFolder\$RemediationLogFolderName" + "-SecEdit.inf";
                $SecEditFilePath = New-WCRLSPINFFile -PolicyList $PolicyList -RemediationValue $RemediationValue -PolicyType $ColPolicyTypes -SecEditFilePath $SecEditFilePath -HideProgress:$HideProgress;
           
                #Calling Function to run SecEdit /Configure Command to Apply the SecEdit Settings
                if($SecEditFilePath -ne $null) {
                    Set-WCRLSPSettings -Path $SecEditFilePath  | Out-Null ;
                }
				Write-WCLog -Message "Completed processing Local Security Policy"
            }
            if($ColPolicyTypes -contains "AdvancedAuditPol") {
                
                Write-WCLog -Message "Processing Advanced Audit Policy related Settings"
               
                #Calling Function to Apply Advanced Audit Policy Settigns using auditpol.exe
                Update-WCRAdvAuditPolPolicy -PolicyList ($PolicyList | Where-Object {$_.PolicyType -eq "AdvancedAuditPol" }) -RemediationValue $RemediationValue  -HideProgress:$HideProgress | Out-Null ;
				
				Write-WCLog -Message "Completed Processing Advanced Audit Policy related Settings"
            }
        }
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
    
	#Remove  Unprocessed Nodes
	$Script:ReportXML = Remove-WCUnprocessedNodes -Action "Remediate" -wcXML $Script:ReportXML
	
    $rxml = [system.io.file]::CreateText($RemediationReportFile)
    $Script:ReportXML.Save($rxml);
    $rxml.Close()
    return $RemediationReportFile
}

#region Functions to Support Start WCR Remediation

#region Functions to Support Registry Remediation
#--------------------------------------------------------------------------------------------------------------
#Function to process Registry settings related polciies
#--------------------------------------------------------------------------------------------------------------
Function Update-WCRRegistryPolicy {
<#
  .SYNOPSIS
  Update-WCRRegistryPolicy
  .DESCRIPTION
  Function to Remediate Registry Policies
  .EXAMPLE
  Update-WCRRegistryPolicy PolicyNode RemediationValue
  .PARAMETER Policies
  PolicyIDs
  .PARAMETER ("DefaultValue", "CurrentValue")
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $PolicyList,
    [Parameter(Mandatory=$true)]
    [string]$RemediationValue,
    [switch] $HideProgress
)
    Write-WCLog -Message "[Update-WCRRegistryPolicy]";

    try {
        if($PolicyList -ne $null) {
            #Process Each Policy
            $ProgressCount = 0;
            ForEach($xmlRegistry in $PolicyList) {
                try { #Capture error if xml entries are missing for this policy
                    if(!($HideProgress.IsPresent) -and ($PolicyList.Count -gt 0)) {
				        #Display Progress of  Registry Remediation
				        Write-Progress -activity "WinCompliance: Remediating [Registry] Related Policies" -status "Progress:" -percentcomplete (($ProgressCount/$PolicyList.count)*100) -CurrentOperation $xmlRegistry.PolicyName;
				        $ProgressCount = $ProgressCount + 1;
			        }

                    Write-WCLog -Level info -Message ("Processing Policy $($xmlRegistry.PolicyName)");

                    #Set XML Variable
                    $xmlRegistry.SetAttribute("Remediate","True");

                    #get Registry Value
                    $Value = "";

                    #If Policy Value has Value Enumeration covert to array
                    if($xmlRegistry.$RemediationValue.HasChildNodes) { $Value = @($xmlRegistry.$RemediationValue.ValueEnumeration); }
                    else { $Value =$xmlRegistry.$RemediationValue.Value; }

                    #Clear $Value is setting is not defined
                    if($Value.ToLower() -eq "notdefined" ) { $Value = "";}

                    $RegistryKey = $null;
                    $DataType = $null;

                    #Format Registry Key for Writing
                    $RegistryKey = Format-WCRRegistryKey -Value $xmlRegistry.PolicyKey;
                    #Format DataType for Writing
                    $DataType = Format-WCRRegistryDataType -Value $xmlRegistry.DataType;

                    if($RegistryKey -ne $null -and $DataType -ne $null) {
                        if($Value.ToLower() -eq "notexists") { $retValue =  Remove-WCRegistryValue -Path $RegistryKey[0] -Key $RegistryKey[1]; } #Calling Fcuntion to Remove Registry Key
                        else { $retValue = Set-WCRegistryValue -Path $RegistryKey[0] -Key $RegistryKey[1] -Value $Value -Type $DataType; } #Calling Function to Update Registry Key
                    
                        #Updating the Remediation Status
                        if($retValue) { 
                            Write-WCLog -Level debug -Message "Successfully Updated Key";
                            $xmlRegistry.SetAttribute("RemediationStatus","Passed");
                        }
                        else {
                            Write-WCLog -Level debug -Message "Error Updating Key";
                            $xmlRegistry.SetAttribute("RemediationStatus","Failed");
                        }
                    }
                    else {
                         Write-WCLog -Level debug -Message "Error Updating Key";
                         $xmlRegistry.SetAttribute("RemediationStatus","Failed");
                    }
                }
                Catch {
                    Write-WCLog -Level Error -Message $_.Exception.Message;
                    $xmlRegistry.SetAttribute("RemediationStatus","Failed");
                }
            }
        }
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
}
#Function to format Regsitry DataType before applying
#--------------------------------------------------------------------------------------------------------------
Function Format-WCRRegistryDataType {
<#
  .SYNOPSIS
  Format-WCRRegistryDataType
  .DESCRIPTION
  Function to Format WCRRegistryDataType  while remediation
  .EXAMPLE
  Format-WCRRegistryDataType <DataType>
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string] $Value
)
    Write-WCLog -Level debug -Message "[Format-WCRRegistryDataType]";

    #If DataType is NILL then SET it to REG_SZ
    if($Value -eq "") { $Value="REG_SZ"; }

    #Convert Registry DataType to Set-ItemProperty -PropertyType Format
    Switch($Value) {
        ('REG_SZ') { return "String";break; }
        ('REG_MULTI_SZ') { return "MultiString";break; }
        ('REG_EXPAND_SZ') { return "ExpandString";break; }
        ('REG_BINARY') { return "Binary";break; }
        ('REG_QWORD') { return "QWord";break; }
        ('REG_DWORD') { return "DWord";break; }
    }                   
}
#--------------------------------------------------------------------------------------------------------------
#Function to format Regsitry Key before applying
#--------------------------------------------------------------------------------------------------------------
Function Format-WCRRegistryKey {
<#
  .SYNOPSIS
  Format-WCRRegistryKey
  .DESCRIPTION
  Function to Format Registry Key while remediation
  .EXAMPLE
  Format-WCRRegistryKey <RegistryKey or DataType> <Type>
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string] $Value
)
    Write-WCLog -Level debug -Message "[Format-WCRRegistryKey]";

    try {
        $RetValue = @(); #is an Array

        #Get Registry Key
        #replace HKCU\,HKLM\,HKEY_LOCAL_MACHINE\,HKEY_CURRENT_USER\
        $RegistryPrefixes = "HKCU\","HKLM\","HKEY_LOCAL_MACHINE\","HKEY_CURRENT_USER\","MACHINE\","USER\";
        $RegistryPrefixReplace="HKCU:\","HKLM:\","HKLM:\","HKCU:\","HKLM:\","HKCU:\";

        #Replace Prefixes with PrefixesReplace String
        For([int] $i=0;$i -lt $RegistryPrefixes.Count;$i++) {
            if($Value.ToUpper().SubString(0,$RegistryPrefixes[$i].Length) -eq $RegistryPrefixes[$i]) { #If starting of the Vlaue is RegistryPrefix
                #Replace HKCU\ with HKCU\: HKLM\ with HKLM:\
                $Value = $Value -iReplace ("$($RegistryPrefixes[$i])\",$RegistryPrefixReplace[$i]);
                #Return the Result in Array Format Array[0] = RegistryPath Array[1]=RegistryKey
                $RetValue =  $RetValue + $Value.SubString(0,$Value.LastIndexOf("\"));
                $RetValue =  $RetValue + $Value.SubString($Value.LastIndexOf("\") +1 ,$Value.Length-$Value.LastIndexOf("\")-1);
                break;
            }
        }
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        $RetValue = $null;
    }
    return $RetValue;
}
#endregion

#region Functions to support SecEdit INF Creation
#--------------------------------------------------------------------------------------------------------------
#Function to create the secedit inf file for applying local security policy settings
#--------------------------------------------------------------------------------------------------------------
Function New-WCRLSPINFFile{
<#
  .SYNOPSIS
  Get-WCRLSPINFFile
  .DESCRIPTION
  Function to Build and Generate secedit INF file for applying if applicable
  .EXAMPLE
  Get-WCRLSPINFFile SecEditFilePath HeaderName PolicyNode
  .PARAMETER SecEditFilePath
  SecEdit FilePath
  .PARAMETER HeaderName
  HeaderName in SecEdit INF File
  .Parameter PolicyNode
  Policies to Update
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $PolicyList,
    [Parameter(Mandatory=$true)]
    [string] $RemediationValue,
    [Parameter(Mandatory=$true)]
    [string[]] $PolicyType,
    [Parameter(Mandatory=$true)]
    $SecEditFilePath,
    [switch] $HideProgress
)
    Write-WCLog -Message "[New-WCRLSPINFFile]";

    try {
        #Set Secedit INF Path
        Write-WCLog -Level info -Message ("Creating SecEdit INF File :" + $SecEditFilePath);
        New-WCRFile -Path $SecEditFilePath

        #Add Header Details to INF
        Write-WCRFile -Path $SecEditFilePath -Value "[Unicode]" -Unicode
        Write-WCRFile -Path $SecEditFilePath -Value "Unicode=yes" -Unicode

        #Get SystemAccess,EventAudit,LSPRegistry,User Rights related Policies from List of Policy ID
        if($PolicyType -contains "SystemAccess") {
            Write-WCLog -Message "Updating SystemAccess"
            Update-WCRLSPINF -INFPath $SecEditFilePath -INFHeader "[System Access]" -PolicyNode ($PolicyList | Where-Object {$_.PolicyType -eq "SystemAccess" }) -RemediationValue $RemediationValue -HideProgress:$HideProgress
        }
        if($PolicyType -contains "EventAudit") {
            Write-WCLog -Message "Updating EventAudit"
            Update-WCRLSPINF -INFPath $SecEditFilePath -INFHeader "[Event Audit]" -PolicyNode( $PolicyList | Where-Object {$_.PolicyType -eq "EventAudit" }) -RemediationValue $RemediationValue  -HideProgress:$HideProgress
        }
        if($PolicyType -contains "LSPRegistry") {
            Write-WCLog -Message "Updating Registry"
            Update-WCRLSPINF -INFPath $SecEditFilePath -INFHeader "[Registry Values]" -PolicyNode ($PolicyList | Where-Object {$_.PolicyType -eq "LSPRegistry" }) -RemediationValue $RemediationValue -IsRegistry  -HideProgress:$HideProgress
        }
        if($PolicyType -contains "PrivilegeRights") {
            Write-WCLog -Message "Updating User Assignment Rights"
            Update-WCRLSPINF -INFPath $SecEditFilePath -INFHeader "[Privilege Rights]" -PolicyNode ($PolicyList | Where-Object {$_.PolicyType -eq "PrivilegeRights" }) -RemediationValue $RemediationValue  -HideProgress:$HideProgress
        }
		if($PolicyType -contains "Kerberos") {
            Write-WCLog -Message "Updating Kerberos"
            Update-WCRLSPINF -INFPath $SecEditFilePath -INFHeader "[Kerberos Policy]" -PolicyNode( $PolicyList | Where-Object {$_.PolicyType -eq "Kerberos" }) -RemediationValue $RemediationValue  -HideProgress:$HideProgress
        }
		
        if(Test-WCRSOEBuildXML) { 
            $SOEBuildSecSettings = Get-WCRSOEBuildSecuritySettings
            #Additonal Security Settings that are readonly in xml but has to be applied while SOE build are updated here.
            #Eg : File Security Permissions are read only in WC Scan XML file 
            #but while SOE Build the file permissions have to be applied 
            #SOEBuild field in the xml will decide whether to append  additonal security entries or skip it
            Write-WCRFile -Path $SecEditFilePath -Value @($SOEBuildSecSettings) -Unicode
        }
		#Get SOE Description
		$SOEBuildSecSettings = $NULL
		$SOEBuildSecSettings =Get-WCRSOEBuildDescription
		Write-WCRFile -Path $SecEditFilePath -Value @($SOEBuildSecSettings) -Unicode
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        $SecEditFilePath = $null;
    }
    return $SecEditFilePath;
}
#--------------------------------------------------------------------------------------------------------------
#Function to update the secedit inf file with polciies for remediation based on the inf header passed
#--------------------------------------------------------------------------------------------------------------
Function Test-WCRSOEBuildXML {
<#
  .SYNOPSIS
  Test-WCRSOEBuildXML
  .DESCRIPTION
  Function to check whether the XML is for SOEBuild
  .EXAMPLE
  Test-WCRSOEBuildXML   
  #>
[CmdletBinding()]
Param()
    Write-WCLog -Level debug -Message "[Test-WCRSOEBuildXML]";

    try {
        #check hwther the XML is SOE Build XML
        if($script:ReportXML.WinCompliance.SOEBuild -ne $null){
            if($script:ReportXML.WinCompliance.SOEBuild -eq "True") {
                Write-WCLog -Level debug -Message "XML is SOE Build XML";
                return $true;
            } 
       }
       #return false if it not build XML
       Write-WCLog -Level debug -Message "XML is WC Scan XML";
       return $false;
    }
     Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
}
#--------------------------------------------------------------------------------------------------------------
#Function to get additonal settings that has to be applied only during SOEBuild
#--------------------------------------------------------------------------------------------------------------
Function Get-WCRSOEBuildSecuritySettings {
<#
  .SYNOPSIS
  Get-WCRSOEBuildSecuritySettings
  .DESCRIPTION
  Function to check whether the XML is for SOEBuild
  .EXAMPLE
  Get-WCRSOEBuildSecuritySettings  
  #>
[CmdletBinding()]
Param()
    Write-WCLog -Level debug -Message "[Get-WCRSOEBuildSecuritySettings]";
    $RetVal = $null;
    try {
        #check hwther the XML is SOE Build XML
        if($script:ReportXML.WinCompliance.SOEBuild -ne $null){
            if($script:ReportXML.WinCompliance.SOEBuild -eq "True") { #Check whether its SOEBuild XML
                if($script:ReportXML.WinCompliance.SOECustom.SOESecINF -ne $null) {
                    $RetVal = @($script:ReportXML.WinCompliance.SOECustom.SOESecINF.ValueEnumeration); #Return Additonal Security Settings
                }
            }
       }
    }
     Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        $RetVal = $null;
    }
    return $RetVal
}
#--------------------------------------------------------------------------------------------------------------
#Function to add SOE description to soesec.inf
#--------------------------------------------------------------------------------------------------------------
Function Get-WCRSOEBuildDescription {
<#
  .SYNOPSIS
  Get-WCRSOEBuildDescription
  .DESCRIPTION
  Function to check whether the XML is for SOEBuild
  .EXAMPLE
  Get-WCRSOEBuildDescription  
  #>
[CmdletBinding()]
Param()
    Write-WCLog -Level debug -Message "[Get-WCRSOEBuildDescription]";
    $RetVal = $null;
    try {
        #check hwther the XML is SOE Build XML
        if($script:ReportXML.WinCompliance.SOESecDesc -ne $null){
			$RetVal = @($script:ReportXML.WinCompliance.SOESecDesc.ValueEnumeration); #Return SOE Desc
       }
    }
     Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        $RetVal = $null;
    }
    return $RetVal
}
#--------------------------------------------------------------------------------------------------------------
#Function to update the secedit inf file with polciies for remediation based on the inf header passed
#--------------------------------------------------------------------------------------------------------------
Function Update-WCRLSPINF {
<#
  .SYNOPSIS
  Update-WCRLSPINF
  .DESCRIPTION
  Function to Start the WC Remediation
  .EXAMPLE
  Update-WCRLSPINF INFPath HeaderName PolicyNode
  .PARAMETER INFPath
  SecEdit FilePath
  .PARAMETER HeaderName
  HeaderName in SecEdit INF File
  .Parameter PolicyNode
  Policies to Update
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string] $INFPath,
    [Parameter(Mandatory=$true)]
    [string] $INFHeader,
    $PolicyNode,
    [Parameter(Mandatory=$true)]
    [string] $RemediationValue,
    [switch] $IsRegistry,
    [switch] $HideProgress
)
    Write-WCLog -Message "[Update-WCRLSPINF]";

    try
    {
        if($PolicyNode -ne $null) {

            Write-WCRFile -Path $INFPath -Value $INFHeader -Unicode  #Append Header to INF first

            $ProgressCount =0;
            #Process Policy and Update INF
            ForEach($XMLPolicy in $PolicyNode)
            {   
                try {
                    if(!($HideProgress.IsPresent) -and ($PolicyNode.Count -gt 0)) {
				    #Display Progress of  Remediation
				    Write-Progress -activity "WinCompliance: Remediating $INFHeader Related Policies" -status "Progress:" -percentcomplete (($ProgressCount/$PolicyNode.count)*100) -CurrentOperation $XMLPolicy.PolicyName;
				    $ProgressCount = $ProgressCount + 1;
			    }

                    Write-WCLog -Level info -Message ("Updating Policy : $($XMLPolicy.PolicyName)");

                    #Update XML to Denote that Remediation Action is performed for the setting
                    $XMLPolicy.SetAttribute("Remediate","True");

                    #Format Remdiation Value
                    $Value = "";
                    $Value = Format-WCRSecEditRemediationValue  -PolicyNode $XMLPolicy -RemediationValue $RemediationValue -INFHeader $INFHeader;

                    if($Value.ToLower() -eq "notdefined") {$Value = "";} #Clear if the setting is not defined

                    $bValueProcessed = $false #To skip INF Updation if the process is registry deletion

                    #Registry Key Deletion cannnot be performed using the secedit INF file.So this has to be takecare seperately
                    if($Value.ToLower() -eq "notexists" -and $IsRegistry.IsPresent) { #Delete Registry

                        #Format Registry Key for Deleting
                        $RegistryKey = Format-WCRRegistryKey -Value $XMLPolicy.PolicyKey;
                        $DataType = Format-WCRRegistryDataType -Value $XMLPolicy.DataType;
                        $retValue =  Remove-WCRegistryValue -Path $RegistryKey[0] -Key $RegistryKey[1];

                        $bValueProcessed = $true; #This policy Setting is Processed, dont update the secedit INF File

                        if($retValue) { 
                            Write-WCLog -Level debug -Message "Successfully Removed Registry Key";
                            $XMLPolicy.SetAttribute("RemediationStatus","Passed");
                        }
                        else {
                            Write-WCLog -Level debug -Message "Error Removing Registry Key";
                            $XMLPolicy.SetAttribute("RemediationStatus","Failed");
                        }
                    }
                    elseif($IsRegistry.IsPresent) { #Set the INF Entry to Registry=DataType,Value Format
                    $Value = (Get-WCRLSPRegDataType -DataType $XMLPolicy.DataType) + "," + $Value; 
                }
                    elseif ($Value.ToLower() -eq "notexists") { $Value = "";}  #Clear $Value if setting is not exists

                    if($bValueProcessed -eq $false) { #Process this section only if the above registry deletion has not been performed

                        #Write the Policy to SecEdit INF file
                        Write-WCLog -Level debug -Message "$($XMLPolicy.PolicyKey)=$Value";
                        Write-WCRFile -Path $INFPath -Value "$($XMLPolicy.PolicyKey)=$Value" -Unicode;

                        $XMLPolicy.SetAttribute("RemediationStatus","Passed");
                    }
                }
                Catch {
                    Write-WCLog -Level Error -Message $_.Exception.Message;
                    $XMLPolicy.SetAttribute("RemediationStatus","Failed");
                }
            }
        }
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
}
#--------------------------------------------------------------------------------------------------------------
#Function to format Value field for SecEdit INF file
#--------------------------------------------------------------------------------------------------------------
Function Format-WCRSecEditRemediationValue {
[CmdletBinding()]
Param(
    $PolicyNode,
    [Parameter(Mandatory=$true)]
    $RemediationValue,
    $INFHeader
)
    $bValueProcessed = $false;
    Write-WCLog -Level debug -Message "[Format-WCRSecEditRemediationValue]";

    try {
        if($INFHeader -eq "[Privilege Rights]") { #Convert UserName to SID and format the value if Header is Privilege Rights

            $Value = Format-WCRPrivilegeRights -PolicyNode $PolicyNode -RemediationValue $RemediationValue;
            $bValueProcessed = $true;

            if($Value -eq $NULL) { $bValueProcessed = $false; }  #Set the setting back to UserName format in case of error while SID Conversion
        }
        #if the INFHeader is not UserAssignmentRights or if there was an an error in SID to UserName convertion then use the value as in xml    
        if($bValueProcessed -eq $false) { #Setting is not Privilege Rights or SID Conversion failed
                if($XMLPolicy.$RemediationValue.HasChildNodes) { $Value = @($XMLPolicy.$RemediationValue.ValueEnumeration) -join ","; } #Has Child Nodes
                else {$Value =$XMLPolicy.$RemediationValue.Value;} #Setting is Single Value
        }
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
    return $Value;
}
#--------------------------------------------------------------------------------------------------------------
#Function to format User Assignment Rights Value field - convert UserName to SID while creating secedit INF file
#--------------------------------------------------------------------------------------------------------------
Function Format-WCRPrivilegeRights {
<#
  .SYNOPSIS
  Format-WCRPrivilegeRights
  .DESCRIPTION
  Function Convert UserNames to SID List
  .EXAMPLE
   Format-WCRPrivilegeRights INFPath HeaderName PolicyNode
  .PARAMETER PolicyNode
  SecEdit Policy Node
  #>
[CmdletBinding()]
Param(
    $PolicyNode,
    [Parameter(Mandatory=$true)]
    $RemediationValue
)
    Write-WCLog -Level debug -Message "[Format-WCRPrivilegeRights]";  
     
    try {
        if($PolicyNode.$RemediationValue.HasChildNodes) { #Has Child Nodes User Assignment Rights setting has multiple Users
            
            foreach($User in $PolicyNode.$RemediationValue.ValueEnumeration) {#process each user in xml for this setting and convert username to sid
                if($User.Length -gt 0) {

                    if($User.Trim().SubString(0,1) -ne "*") { $Value += "$(Get-UserNameToSID($User.Trim())),"; }#Entry is UserName and so Convert UserName to SID
                    else { $Value += $User.Trim() + ","; } #If entry in XML is SID

                }  
            }

            #remove the last coma character
            if($Value.Length -gt 0) {
                if($Value.SubString($Value.Length-1,1) -eq ",") {$Value = $Value.SubString(0,$Value.Length -1);}
            }
        }
        else { 
            #Entry is a single Value
            if($PolicyNode.$RemediationValue.Value -eq "notdefined") {$Value = "";}
            else { $Value =Get-UserNameToSID($PolicyNode.$RemediationValue.Value); } #Convert the UserName to SID
        }
     }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        $Value = $NULL;
    }

    return $Value;
}
#--------------------------------------------------------------------------------------------------------------
#Function to convert Registry datatype to local security policy secedit inf datatype format
#--------------------------------------------------------------------------------------------------------------
Function Get-WCRLSPRegDataType {
<#
  .SYNOPSIS
  Get-WCRLSPRegDataType
  .DESCRIPTION
  Function to Convert Registry DataType to its Value
  .EXAMPLE
  Get-WCRLSPDataType DataType
  .PARAMETER DataType
  Eg : REG_SZ,REG_MULTISZ
  #>
[CmdletBinding()]
Param(
    [string] $DataType
)
    Switch ($DataType) {
        ('REG_SZ') {
            return "1";break;
        }
        ('REG_EXPAND_SZ') {
            return "2";break;
        }
        ('REG_BINARY') {
            return "3";break;
        }
        ('REG_DWORD') {
            return "4";break;
        }
        ('REG_MULTI_SZ') {
            return "7";break;
        }
        ('REG_QWORD') {
            return "11";break;
        }
        default {
            return "1";break;
        }
    }
}
#--------------------------------------------------------------------------------------------------------------
#Function to run secedit and apply the lsp settings
#--------------------------------------------------------------------------------------------------------------
Function Set-WCRLSPSettings {
<#.SYNOPSIS
  Set-WCRLSPSettings
  .DESCRIPTION
  Function to Apply the SecEdit INF File
  .EXAMPLE
  Set-WCRLSPSettings Path
  .PARAMETER Path
  SecEdit FilePath

  #>
Param(
    [Parameter(Mandatory=$true)]
    [string] $Path
)
    Write-WCLog -Message "[Set-WCRLSPSettings]";

    try {
        #Creating DB File
        $cmd = "cmd.exe /c SecEdit /configure /cfg  " + [char]34 + $path + [char]34 + " /db " + [char]34 + $path.replace(".inf",".sdb") + [char]34;
        Write-WCLog -Level debug -Message "Running Command $cmd";
        $Res = Invoke-Expression $cmd;
        Write-WCLog -Level debug -Message $Res;

        #Applying DB File
        $cmd = "cmd.exe /c SecEdit /configure /db " + [char]34 + $path.replace(".inf",".sdb") + [char]34  + " /cfg  " + [char]34 + $path + [char]34 + " /log " + [char]34 + $path.replace(".inf",".log") + [char]34;
        Write-WCLog -Level debug -Message "Running Command $cmd";
        $Res = Invoke-Expression $cmd;
        Write-WCLog -Level debug -Message $Res;
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
}
#endregion

#region Functions to support Service Remediation
#--------------------------------------------------------------------------------------------------------------
#Function process service remediation related policies
#--------------------------------------------------------------------------------------------------------------
Function Update-WCRServicePolicy{
<#
  .SYNOPSIS
  Update-WCRServicePolicy
  .DESCRIPTION
  Function to Set Service State and StartupType
  .EXAMPLE
  Update-WCRServicePolicy PolicyNodes RemediationValue
  .PARAMETER PolicyNodes
  PolicyIDs
  .PARAMETER ("DefaultValue", "CurrentValue")
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $PolicyList,
    [Parameter(Mandatory=$true)]
    [string]$RemediationValue,
    [switch] $HideProgress
)
    Write-WCLog -Message "[Update-WCRServiceSettings]";

    try {
        if($PolicyList -ne $null) {

            #Process Each Policy
            $ProgressCount = 0;
            ForEach($xmlService in $PolicyList) {
                try {
                    if(!($HideProgress.IsPresent) -and ($PolicyList.Count -gt 0)) {
				    #Display Progress of Remediation
				    Write-Progress -activity "WinCompliance: Remediating [Service] Related Policies" -status "Progress:" -percentcomplete (($ProgressCount/$PolicyList.count)*100) -CurrentOperation $xmlService.PolicyName;
				    $ProgressCount = $ProgressCount + 1;
			    }

                    Write-WCLog -Level info -Message ("Processing Policy $($xmlService.PolicyName)");

                    #Update the XML Node that setting has been selected for remediation
                    $xmlService.SetAttribute("Remediate","True");

                    #calling function to perform remediation
                    Switch($xmlService.PolicyType) {
                    ('Service.StartUpType') {
                        $retStatus = Set-WCRServiceStartUp -ServiceName $xmlService.PolicyKey -State $xmlService.$RemediationValue.Value;break;
                    }
                     ('Service.State') {
                        $retStatus = Set-WCRServiceState -ServiceName $xmlService.PolicyKey -State $xmlService.$RemediationValue.Value;break;
                    }
                }

                    #Updating the Remediation Status
                    if($retStatus) {
                        Write-WCLog -Level debug -Message "Success";
                        $xmlService.SetAttribute("RemediationStatus","Passed");
                    }
                    else {
                        Write-WCLog -Level debug -Message "Failed";
                        $xmlService.SetAttribute("RemediationStatus","Failed");
                     }
                }
                Catch {
                     Write-WCLog -Level Error -Message $_.Exception.Message;
                     $xmlService.SetAttribute("RemediationStatus","Failed");
                }
            }

         }
    }
    catch
    {
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
}
#--------------------------------------------------------------------------------------------------------------
#Function change the service startup type
#--------------------------------------------------------------------------------------------------------------
Function Set-WCRServiceStartUp{
<#
  .SYNOPSIS
  Set-ServiceStartUp
  .DESCRIPTION
  Function to change Service StartUpType
  .EXAMPLE
  Set-ServiceStartUp snmp disable 
  .PARAMETER ServiceName
  PolicyIDs
  .PARAMETER StartupType
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $ServiceName,
    [ValidateSet("Disabled","Auto","Manual")]
    [Parameter(Mandatory=$true)]
    $State
    )
    Write-WCLog -Message "[Set-WCRServiceStartUp]";
    Write-WCLog -Level debug -Message "Service Name : $ServiceName";
    Write-WCLog -Level debug -Message "StartUp:$State";

    try {
        Set-Service -Name $ServiceName -StartupType $State  -ErrorAction Stop;  #changing service startup type
        return $true;
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
}
#--------------------------------------------------------------------------------------------------------------
#Function change service state
#--------------------------------------------------------------------------------------------------------------
Function Set-WCRServiceState{
<#
  .SYNOPSIS
  Set-WCRService
  .DESCRIPTION
  Function to change Service State
  .EXAMPLE
  Set-ServiceStartUp snmp Running 
  .PARAMETER ServiceName
  PolicyIDs
  .PARAMETER State
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $ServiceName,
    [ValidateSet("Running","Stopped")]
    [Parameter(Mandatory=$true)]
    $State
    )
    Write-WCLog -Message "[Set-WCRServiceState]";
    Write-WCLog -Level debug -Message "Service Name : $ServiceName";
    Write-WCLog -Level debug -Message "State:$State";

    try {
        Switch($State) { #chaning service state
            ('Running') { Start-Service -Name $ServiceName -ErrorAction Stop;break; } 
            ('Stopped') { Stop-Service -Name $ServiceName  -ErrorAction Stop;break; }
        }
        return $true;
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
}
#endregion

#region Local Group Policy Registry Settings - to be applied using LGPO exe
#--------------------------------------------------------------------------------------------------------------
#Function to create the pol log file for local group policy settings
#--------------------------------------------------------------------------------------------------------------
Function New-WCRLGPInputFile {
<#
  .SYNOPSIS
  Get-WCRLGPLogFile
  .DESCRIPTION
  Function to Start the WC Remediation
  .EXAMPLE
  Get-WCRLGPLogFile PolicyList RemedaitionValue Date
  .PARAMETER PolicyList
  Policy List to Remediate
  .PARAMETER RemediationValue
  Default Value or Current Value
  .Parameter Date
  Date Field for Log file creation
  #>
[CmdletBinding()]
Param(
    $PolicyList,
    [Parameter(Mandatory=$true)]
    [string] $RemediationValue,
    [string] $LGPOLogPath,
    [switch] $HideProgress
)
    Write-WCLog -Message "[New-WCRLGPInputFile]";

    try {

        #Set RegistryPol File Log Path
        Write-WCLog -Level info -Message ("Creating Local Group Policy Log File :" + $LGPOLogPath);

        #create the LogFile for LGPO 
        New-WCRFile $LGPOLogPath;

        if($PolicyList -ne $null) {

            #Process Policy and Update INF
            $ProgressCount = 0;
            ForEach($XMLPolicy in $PolicyList)
            {   
                try {
                    if(!($HideProgress.IsPresent) -and ($PolicyList.Count -gt 0)) {
				        #Display Progress of Remediation
				        Write-Progress -activity "WinCompliance: Remediating [Local Group Policy] Related Policies" -status "Progress:" -percentcomplete (($ProgressCount/$PolicyList.count)*100) -CurrentOperation $XMLPolicy.PolicyName;
				        $ProgressCount = $ProgressCount + 1;
			        }

                    Write-WCLog -Level info -Message ("Updating Policy $($XMLPolicy.PolicyName)");

                    #Set the XML Node to denote that the setting has been processed
                    $XMLPolicy.SetAttribute("Remediate","True");

                    #Get Registry Value
                    $Value = "";

                    #If Policy Value has Value Enumeration join by coma character
                    if($XMLPolicy.$RemediationValue.HasChildNodes) {  $Value = @($XMLPolicy.$RemediationValue.ValueEnumeration) -join ","; }
                    else { $Value =$XMLPolicy.$RemediationValue.Value; }

                    $RegistryKey = $null;
                    $DataType = $null;

                    #Format Registry Key for Writing
                    $RegistryKey = Format-WCRRegistryKey -Value $XMLPolicy.PolicyKey;
                    $DataType = Format-WCRLGPDataType -Value $XMLPolicy.DataType;

                    #Clear $Value is setting is not defined
                    if($Value.ToLower() -eq "notdefined") { $Value = "";}

                    if(($RegistryKey -eq $null -or $DataType -eq $null) -eq $false) {
                        #Updating Log File for Applying the Settings
                        Write-WCRFile -Path $LGPOLogPath -Value ""

                        #Update Key Field
                        Switch($RegistryKey[0].SubString(0,6)) { 
                            ('hklm:\') {
                                Write-WCRFile -Path $LGPOLogPath -Value "Computer"
                                Write-WCRFile -Path $LGPOLogPath -Value $RegistryKey[0].SubString(6,$RegistryKey[0].Length-6)
                                Write-WCRFile -Path $LGPOLogPath -Value $RegistryKey[1].Trim()
                                break;
                            }
                            ('hkcu:\') {
                                Write-WCRFile -Path $LGPOLogPath -Value "User"
                                Write-WCRFile -Path $LGPOLogPath -Value $RegistryKey[0].SubString(6,$RegistryKey[0].Length-6)
                                Write-WCRFile -Path $LGPOLogPath -Value $RegistryKey[1].Trim()
                                break;
                            }
                        }

                        #Update Value and DataType Fields
                        if($Value.ToLower() -eq "notexists") {Write-WCRFile -Path $LGPOLogPath -Value "DELETE" } #to delete a registry key
                        else { 
                            Write-WCRFile -Path $LGPOLogPath -Value "$($DataType):$Value";  }
                            Write-WCRFile -Path $LGPOLogPath -Value ""

                            $XMLPolicy.SetAttribute("RemediationStatus","Passed");
                        }
                        else { $XMLPolicy.SetAttribute("RemediationStatus","Failed"); }
                    }
                Catch {
                    Write-WCLog -Level Error -Message $_.Exception.Message;
                    $XMLPolicy.SetAttribute("RemediationStatus","Failed");
                }
            }
        }
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        $LGPOLogPath = $null;
    }
    return $LGPOLogPath;
}
#--------------------------------------------------------------------------------------------------------------
#Function to convert the datatype to LGPO.exe datatype format
#--------------------------------------------------------------------------------------------------------------
Function Format-WCRLGPDataType {
<#
  .SYNOPSIS
  Format-WCRLSPDataType
  .DESCRIPTION
  Function to Format DataType in LSP LGPO.exe Format
  .EXAMPLE
  Format-WCRLSPDataType <RegistryKey or DataType> <Type>
  #>
[CmdletBinding()]
Param(
    [string] $Value
)
    Write-WCLog -Level debug -Message "[Format-WCRLSPDataType]";

    try {
        #If DataType is NILL then SET it to REG_SZ
        if($Value -eq "") { $Value="REG_SZ"; }

        #Convert Registry DataType to LSP LGPO.exe Format
        switch ($Value) {          
            ('REG_SZ')
                {$RetValue = "SZ";break;}
            ('REG_EXPAND_SZ')
                {$RetValue = "EXSZ";break;}
            ('REG_DWORD')
                {$RetValue = "DWORD";break;}                 
        }

        if($RetValue -eq $null) { Write-WCLog -Level Error -Message "Unknown DataType $DataTpe for LGPO.exe"; }
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
    return $RetValue;
}
#--------------------------------------------------------------------------------------------------------------
#Function to run LGPO.exe and apply the local group policy related settings
#--------------------------------------------------------------------------------------------------------------
Function Set-WCRLGPSettings {
<#.SYNOPSIS
  Set-WCRLGPSettings
  .DESCRIPTION
  Function to Apply the Local Group Policy Registry Settings
  .EXAMPLE
  Set-WCRLGPSettings Path
  .PARAMETER WCRLGPSettings
  RegPol Log FilePath

  #>
Param(
    [Parameter(Mandatory=$true)]
    [string] $Path
)
    Write-WCLog -Message "[Set-WCRLGPSettings]"

    try {
        #Runing command to apply local group policy related settings
        $exePath = "$PSScriptRoot\..\bin\LGPO.Exe";
        if(Test-Path $exePath) {
            $exePath = Resolve-Path $exePath; #Get Exact Path
            $cmd = [char]34 + $exePath + [char]34 + " /q /v /t " + [char]34 + "$Path" + [char]34 + " > " + [char]34 + $($path.replace(".txt",".log")) + [char]34;
            Write-WCLog -Level debug -Message "Running Command $cmd"

            ($Res = Invoke-Expression "cmd.exe /c $cmd") 2> $Null ;

            Write-WCLog -Level debug -Message $Res
            #Invoke-Expression "CMD.EXE /C gpupdate /Force";
        }
        else {
             Write-WCLog -Level Error -Message "Missing \bin\LGPO.exe in the package";
        }
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
}
#endregion

#region Local Group Policy Registry Settings - to be applied using GPRegistryPolicy module on Nano server
#--------------------------------------------------------------------------------------------------------------
# Function to create input CSV file containing LGPO policies to be converted to POL file for applying
# LGPO policies on Nano server platform. On Nano Server, LGPO is applied only to LocalMachine!
#--------------------------------------------------------------------------------------------------------------
Function New-WCRLGPCSVFile {
<#
  .SYNOPSIS
  New-WCRLGPCSVFile
  
  .DESCRIPTION
  Function to create a CSV File in LGPO policy format for later conversion into a POL file
  
  .PARAMETER PolicyList
  List of Local GPO policies to be converted to CSV format
  
  .PARAMETER RemediationValue
  Default Value or Current Value
  
  .Parameter CSVFilePath
  Date Field for Log file creation

  .PARAMETER HideProgress
  Do not display progress bar

  .EXAMPLE 
  New-WCRLGPCSVFile -PolicyList $WCLGPPolicyList -RemediationValue "DefaultValue" -CSVFilePath "C:\temp.csv"
  #>
[CmdletBinding()]
Param(
    $PolicyList,
    [Parameter(Mandatory=$true)]
    [string] $RemediationValue,
    [string] $CSVFilePath,
    [switch] $HideProgress
)
    Write-WCLog -Message "[New-WCRLGPCSVFile]"

    try {

        # Set RegistryPol temporary CSV File path
        Write-WCLog -Level info -Message ("Creating LGPO temporary CSV file :" + $CSVFilePath)

        #create the CSV file for LGPO and write column header
        New-WCRFile $CSVFilePath
        Write-WCRFile -Path $CSVFilePath -Value "KeyName,ValueName,ValueType,ValueData"

        if($PolicyList -ne $null) {

            #Process Policy and Update INF
            $ProgressCount = 0 # progress counter
            ForEach($XMLPolicy in $PolicyList)
            {   
                $cline = "" # current line to be written in CSV. construct below in the loop
                try {
                    if(!($HideProgress.IsPresent) -and ($PolicyList.Count -gt 0)) {
				        #Display Progress of Remediation
				        Write-Progress -activity "WinCompliance: Remediating [Local Group Policy] Related Policies" -status "Progress:" -percentcomplete (($ProgressCount/$PolicyList.count)*100) -CurrentOperation $XMLPolicy.PolicyName
				        $ProgressCount = $ProgressCount + 1
			        }

                    Write-WCLog -Level info -Message ("Updating Policy $($XMLPolicy.PolicyName)")

                    #Set the XML Node to denote that the setting has been processed
                    $XMLPolicy.SetAttribute("Remediate","True")

                    #Get Registry Value
                    $Value = ""

                    #If Policy Value has Value Enumeration join by coma character
                    if($XMLPolicy.$RemediationValue.HasChildNodes) {  $Value = @($XMLPolicy.$RemediationValue.ValueEnumeration) -join "," }
                    else { $Value =$XMLPolicy.$RemediationValue.Value }

                    $RegistryKey = $null;
                    $DataType = $null;

                    #Format Registry Key for Writing
                    $RegistryKey = Format-WCRRegistryKey -Value $XMLPolicy.PolicyKey
                    $DataType = $XMLPolicy.DataType # for GPRegistryPolicy module, Data Type doesnt need formatting

                    # Clear $Value if setting is not defined. we dont want to write unwanted text as part of policy
                    if($Value.ToLower() -eq "notdefined") { $Value = "" }

                    if(($RegistryKey -eq $null -or $DataType -eq $null) -eq $false) {
                        #Update Key Field. 
                        Switch($RegistryKey[0].SubString(0,6)) { 
                            ('hklm:\') {
                                # add KeyName to current policy line
                                $cline = $RegistryKey[0].SubString(6,$RegistryKey[0].Length-6) + ',' # KeyName
                                # this reg valueName has to be deleted if it is set to "NotExists"
                                if($Value.ToLower() -eq "notexists") { 
                                    $cline = ("{0}{1}{2}{3}" -f $cline,'**Del.',$RegistryKey[1].Trim(),',') # ValueName
                                }
                                else { # write actual value name
                                    $cline = ("{0}{1}{2}" -f $cline, $RegistryKey[1].Trim(), ',') # ValueName
                                }
                                # write ValueType and ValueData
                                $cline = ("{0}{1}{2}" -f $cline, $DataType, ',')
                                # for 'NotExists' value, write value as 0. else, write actual value
                                if($Value.ToLower() -eq "notexists") { 
                                    $cline = ("{0}{1}" -f $cline, '')
                                }
                                else {
                                    $cline = ("{0}{1}" -f $cline, $Value)
                                }

                                # write current policy line to CSV file
                                Write-WCRFile -Path $CSVFilePath -Value $cline
                                # update XML with remediation status
                                $XMLPolicy.SetAttribute("RemediationStatus","Passed");
                                
                                break;
                            }
                            ('hkcu:\') {
                                Write-WCLog -Level info -Message "HKCU policy, skipping it"
                                break
                            }
                        }
                    }
                    else { 
                        $XMLPolicy.SetAttribute("RemediationStatus","Failed")
                    }
                }
                Catch {
                    Write-WCLog -Level Error -Message $_.Exception.Message
                    $XMLPolicy.SetAttribute("RemediationStatus","Failed")
                }
            }
        }
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message
        $CSVFilePath = $null;
    }
    return $CSVFilePath;
}

#--------------------------------------------------------------------------------------------------------------
#Function to apply the local group policy related settings on Nano Server using CSV input file
# Input CSV file is first converted to POL file and then it is applied
#--------------------------------------------------------------------------------------------------------------
Function Set-WCRLGPSettingsFromCSV {
Param(
    [Parameter(Mandatory=$true)]
    [string] $CSVPath
)
    Write-WCLog -Message "[Set-WCRLGPSettingsFromCSV]"

    try {
        # create POL file from CSV first
        $csvFileInfo = (Get-Item -Path $CSVPath)
        $polFile = $csvFileInfo.DirectoryName + '\' + $csvFileInfo.BaseName + '.pol' # pol file to create

        # create POL file from given CSV
        Write-WCLog -Message "Creating $polFile from $CSVPath"
        New-PolFileFromCSV -CSVPath $CSVPath -PolFilePath $polFile
        
        # now, apply the POL file to LocalMachine. On nano, POL file can only be applied to LocalMachine
        Write-WCLog -Message ("Applying $polFile to {0}" -f $env:COMPUTERNAME)
        Import-GPRegistryPolicy -Path $polFile -LocalMAchine *>> (Get-WCLogFile) # redirect all output to log file
        Write-WCLog -Message "Pol file $polFile applied."
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message
    }
}
#endregion

#region Function to support AuditPol Remediation
#--------------------------------------------------------------------------------------------------------------
#Function to process AdvancedAudit policy realted settings
#--------------------------------------------------------------------------------------------------------------
Function Update-WCRAdvAuditPolPolicy{
<#
  .SYNOPSIS
  Update-WCRAdvAuditPolPolicy
  .DESCRIPTION
  Function to Perform Audit Pol remediation
  .EXAMPLE
  Update-WCRAdvAuditPolPolicy PolicyNodes RemediationValue
  .PARAMETER ServiceName
  PolicyIDs
  .PARAMETER ("DefaultValue", "CurrentValue")
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $PolicyList,
    [Parameter(Mandatory=$true)]
    [string]$RemediationValue,
    [switch] $HideProgress
)
    Write-WCLog -Level debug -Message "[Update-WCRAdvAuditPolPolicy]"

    try {
        if($PolicyList -ne $null) {

            #Process Each Policy
            $ProgressCount = 0;
            ForEach($xmlAuditPol in $PolicyList) {
                try {
                    if(!($HideProgress.IsPresent) -and ($PolicyList.Count -gt 0)) {
				    #Display Progress of Remediation
				    Write-Progress -activity "WinCompliance: Remediating [Advanced Audit Policy] Related Policies" -status "Progress:" -percentcomplete (($ProgressCount/$PolicyList.count)*100) -CurrentOperation $xmlAuditPol.PolicyName
				    $ProgressCount = $ProgressCount + 1;
			    }

                    Write-WCLog -Level info -Message ("Processing Policy : $($xmlAuditPol.PolicyName)");
                    Write-WCLog -Level debug -Message "Value : $($xmlAuditPol.$RemediationValue.Value)"

                    #Set XML Node to denote that this setting has been processed
                    $xmlAuditPol.SetAttribute("Remediate","True")

                    $retStatus = "";
                    #Run Audit Pol to Remediate Value
                    Switch($xmlAuditPol.$RemediationValue.Value) {
                    ('Success and Failure') {
                      $retStatus =  Set-WCRAdvAuditPol -SubCategory $xmlAuditPol.PolicyKey -SuccessState "Enable" -FailureState "Enable" ;break;
                    }
                    ('No Auditing') {
                      $retStatus = Set-WCRAdvAuditPol -SubCategory $xmlAuditPol.PolicyKey -SuccessState "Disable" -FailureState "Disable";break;
                    }
                    ('Success') {
                      $retStatus= Set-WCRAdvAuditPol -SubCategory $xmlAuditPol.PolicyKey -SuccessState "Enable" -FailureState "Disable";break;
                    }
                    ('Failure') {
                      $retStatus= Set-WCRAdvAuditPol -SubCategory $xmlAuditPol.PolicyKey -SuccessState "Disable" -FailureState "Enable";break;
                    }
                }

                    #Update Status of Remediation
                    if($retStatus) {
                    Write-WCLog -Level debug -Message "Success";
                    $xmlAuditPol.SetAttribute("RemediationStatus","Passed");
                 }
                    else {
                    Write-WCLog -Level debug -Message "Failed";
                    $xmlAuditPol.SetAttribute("RemediationStatus","Failed");
                 }
                }
                Catch {
                    Write-WCLog -Level Error -Message $_.Exception.Message;
                    $xmlAuditPol.SetAttribute("RemediationStatus","Failed");
                }
            }
        }
    }
    Catch {
         Write-WCLog -Level Error -Message $_.Exception.Message;
    }
}
#--------------------------------------------------------------------------------------------------------------
#Function to run aduitpol.exe and set advanced audit policy
#--------------------------------------------------------------------------------------------------------------
Function Set-WCRAdvAuditPol {
<#
  .SYNOPSIS
  Set-WCRAuditPol
  .DESCRIPTION
  Function execute auditpol command to perform remediation
  .EXAMPLE
  Set-WCRAuditPol Subcategory SuccessState FailureState
  .PARAMETER Subcategory
  Advanced AUDITpOL sUBCATEGORY
  .PARAMETER SuccessState
  /Success:SuccessState
  .PARAMETER FailureState
   /Failure:FailureState
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $SubCategory,
    [ValidateSet("Enable", "Disable")]
    [string]$SuccessState,
    [ValidateSet("Enable", "Disable")]
    [string]$FailureState
)
    Write-WCLog -Message "[Set-WCRAuditPol]"
    Write-WCLog -Level debug -Message ("$SubCategory /Success:$SuccessState /Failure:$FailureState");

    try {
        #Run Audit Pol Command
        $cmd = "cmd.exe /c auditpol.exe /Set /SubCategory:" + [char]34 + $SubCategory + [char]34 + " /Success:$SuccessState /Failure:$FailureState";
        Write-WCLog -Level debug -Message "Running Command $cmd";
        $Res = Invoke-Expression $cmd;

        Write-WCLog -Level debug -Message $Res
        return $true;
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
}
#endregion

#region psModule Remediation
Function Update-psModulePolicy {
<#
  .SYNOPSIS
  Update-psModulePolicy
  .DESCRIPTION
  Function to Remediate psModule Policies
  .EXAMPLE
  Update-psModulePolicy PolicyNode RemediationValue
  .PARAMETER Policies
  PolicyIDs
  .PARAMETER ("DefaultValue", "CurrentValue")
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $PolicyList,
    [Parameter(Mandatory=$true)]
    [ValidateSet("Remediate", "Revert")]
    $RemediationType,
    [switch] $HideProgress
)
    Write-WCLog -Level debug -Message "[Update-psModulePolicy]"

    try {
        if($PolicyList -ne $null) {

            #Process Each Policy
            $ProgressCount = 0;
            ForEach($xmlpsModule in $PolicyList) {
                try {
                    if(!($HideProgress.IsPresent) -and ($PolicyList.Count -gt 0)) {
				    #Display Progress of Remediation
				    Write-Progress -activity "WinCompliance: Remediating [psModule Policy] Related Policies" -status "Progress:" -percentcomplete (($ProgressCount/$PolicyList.count)*100) -CurrentOperation $xmlpsModule.PolicyName
				    $ProgressCount = $ProgressCount + 1;
			    }

                    Write-WCLog -Level info -Message ("Processing Policy : $($xmlpsModule.PolicyName)");

					#Set XML Node to denote that this setting has been processed
					$xmlpsModule.SetAttribute("Remediate","True");

					$psValue = $NULL;
				    #default value or current Value will be passed to module parametername $DefaultValue
					$psDefValue = $xmlpsModule.DefaultValue;
					if($RemediationType -eq "Revert") { $psDefValue = $xmlpsModule.CurrentValue}
					
					if($psDefValue.ValueEnumeration -ne $Null) { #default value is an array
						$psValue = $psDefValue.ValueEnumeration	
					}
					else {
						$psValue = $psDefValue.Value #DefaultValue is a string
					}

					$retStatus = "";
					
					#Run psScripts 
					if($RemediationType -eq "Remediate") {
						#Pass the Parameter Remediate to the script
						$retStatus = Invoke-Expression "$($xmlpsModule.PolicyKey) -Action 'Remediate' -DefaultValue $psValue"
					}
					else {
						#Pass the Parameter Revert to the script
						$retStatus = Invoke-Expression "$($xmlpsModule.PolicyKey) -Action 'Revert' -DefaultValue $psValue"
					}
					
					#There are only two return values Success or Failure
					if($retStatus -eq "Success") { $xmlpsModule.SetAttribute("RemediationStatus","Passed"); }
					else { 
						$xmlpsModule.SetAttribute("RemediationStatus","Failed");
						Write-WCLog -Level error -Message $retStatus
					 }

				}
				Catch {
                    Write-WCLog -Level Error -Message $_.Exception.Message;
                    $xmlpsModule.SetAttribute("RemediationStatus","Failed");
                }
			}
        }
    }
    Catch {Write-WCLog -Level Error -Message $_.Exception.Message;}
}

Function Update-psModuleProfilePolicy {
<#
  .SYNOPSIS
  Update-psModuleProfilePolicy
  .DESCRIPTION
  Function to Remediate user Profile related Policies
  .EXAMPLE
  Update-psModuleProfilePolicy PolicyNode RemediationValue
  .PARAMETER Policies
  PolicyIDs
  .PARAMETER ("DefaultValue", "CurrentValue")
  #>
[CmdletBinding()]
Param(
    $PolicyList,
    [Parameter(Mandatory=$true)]
    [ValidateSet("Remediate", "Revert")]
    $RemediationType,
    [switch] $HideProgress
)
    Write-WCLog -Level debug -Message "[Update-psModuleProfilePolicy]"

    try {
        if($PolicyList -ne $null) {
            
            Invoke-SOEConfigDefaultUser -ProfilePolicyNode $PolicyList -Action $RemediationType
            
			#Set XML Node to denote that this setting has been processed
			$PolicyList | foreach-Object { $_.SetAttribute("Remediate","True"); $_.SetAttribute("RemediationStatus","Passed"); }
        }
    }
    Catch {Write-WCLog -Level Error -Message $_.Exception.Message;}
}

#endregion
#endregion

#region handle File Creation and Updation
Function Write-WCRFile {
<#
  .SYNOPSIS
  Write-WCRFile
  .DESCRIPTION
  Function to Update the SecEdit INF file with Contents
  .EXAMPLE
  Write-WCRFile FilePath Content
  .PARAMETER FilePath
  FilePath
  .PARAMETER Content
  Content to Update
#>
  [CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string] $Path,
    $Value,
    [Switch] $Unicode
)
    try
    {
        if($Unicode.IsPresent) {
            Add-Content -Path $Path -Encoding Unicode $Value
        }
        else {
            Add-Content -Path $Path $Value
        }
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
}
Function New-WCRFile {
<#.SYNOPSIS
  New-WCRFile
  .DESCRIPTION
  Function to Create  aFile
  .EXAMPLE
  Set-WCRFile FilePath
  .PARAMETER Path
  FilePath

  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [string] $Path
)
    try {
        #Create SecEdit File
        New-Item -ItemType File -Path $Path -Force | Out-Null;
    }
    Catch {
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
}
#endregion

#region BaseLine Validation
Function Test-WCRReportXML {
<#
  .SYNOPSIS
  Test-WCReportXML
  .DESCRIPTION
  Function to Validate BaseLine XML
  .EXAMPLE
  Test-WCReportXML
  #>
[CmdletBinding()]
Param(
    $PolicyIDs,
    [ValidateSet("Remediate", "Revert")] $RemediationType,
    [switch] $RemediateAll
)
    Write-WCLog -Level debug -Message "[Test-WCRReportXML]";
    try {
        #Validate Policy Item
        if((Test-WCRValidatePolicyItem) -eq $false) {return $false;}

        #Validate  Policies are processed if remediation Type is revert
        if($RemediationType -eq "Revert") {

            #Get the Policy List
            $PolicyList = Get-WCRPoliciesToRemediate -RemediateAll:$RemediateAll -PolicyIDs $PolicyIDs;
            
            #Check for Unprocessed Policies
            $XMLNotProcessed = $PolicyList | Where-Object { $_.Processed -ne "true" };
            if($XMLNotProcessed -ne $null) {
                Write-WCLog -Level Error -Message "[Test-WCRReportXML] : Processed field is set to false for the policies:$($XMLNotProcessed.id -join ",")";
                return $false;
            }
        }
    }
    catch {
        Write-WCLog -Level Error -Message "[Test-WCRReportXML] : Error Validating BaseLine XML";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
    return $True;
}

Function Test-WCRValidatePolicyItem {
<#
  .SYNOPSIS
  Test-WCRValidatePolicyItem
  .DESCRIPTION
  Function to Validate Policy Items  in XML
  .EXAMPLE
  Test-WCBValidatePolicyItem 
  #>
[CmdletBinding()]
Param()
    Write-WCLog -Level debug -Message "[Test-WCRValidatePolicyItem]";
    
    try {
         
        $ColMandatoryFields = "PolicyKey","PolicyName","PolicyType","Id","CompareMethod","DataType","DefaultValue","CurrentValue","TestResult";
        $ColNonEmptyFields = "PolicyKey","PolicyName","PolicyType","Id";
        
        #Validate Policy Mandatory Fields and Non Empty Fields
        $boolStatus = $true
        $colIPolicyItem = (Get-WCXMLNodes -Xml $script:ReportXML -XPath "//Policy")
		
        ForEach($PolicyItem in $colIPolicyItem) {
            ForEach($MandatoryField in $ColMandatoryFields) {
                if($PolicyItem.$MandatoryField -eq $NULL) { #Check for Mandatory Fields
                    Write-WCLog -Level Error -Message "[Test-WCRValidatePolicyItem] : MandatoryField $MandatoryField is missing for the Policy $($PolicyItem.ID)";
                    $boolStatus = $false;
                }
                elseif($ColNonEmptyFields -contains $MandatoryField) { #Check for NonEmty Fields
                    if($PolicyItem.$MandatoryField -eq "") {
                        Write-WCLog -Level Error -Message "[Test-WCRValidatePolicyItem] : MandatoryField $MandatoryField is Empty for Policy $($PolicyItem.ID)";
                        $boolStatus = $false;
                    }
                }           
            } 
        }
        if($boolStatus -eq $false) { return $false; }
        
        #Validate Duplicate Policy ID
        $CompareResult = ([string[]]($colIPolicyItem | Select-Object ID)  | group | Where-Object {$_.Count -gt 1}) |Select-Object Name;
        if($CompareResult -ne $NULL) {
            Write-WCLog -Level Error -Message "[Test-WCRValidatePolicyItem] : Duplicate Policy ID Exists : " + ([string[]]($CompareResult) -Join ',');
            return $false;
        }      
    }
    catch {
        Write-WCLog -Level Error -Message "[Test-WCRValidatePolicyItem] : Error Validating BaseLine XML";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
   return $true; 
}
#endregion


#region Lanuch Rescan
Function Update-WCScanStatus {
<#
  .SYNOPSIS
  Test-WCReportXML
  .DESCRIPTION
  Function to Validate BaseLine XML
  .EXAMPLE
  Test-WCReportXML
  #>
[CmdletBinding()]
Param(
    $ScanReport,    
    $RemediationReport,
    $PolicyIDs,
    [switch] $RemediateAll
)
    Write-WCLog -Level debug -Message "[Get-WCScanStatus]";
    try {

        #Load the Set Script XML Variable with the Scan report
        $Status = Set-WCRXMLVariable -ReportXMLFile $ScanReport;

        #Test whether the XML is in Valid WC report Format
        If((Test-WCRXMLVariable)) {
            #Collect Failed Policies from Scan Report
            if($RemediateAll.IsPresent) { 
                $FailedPolicies = (Get-WCRPoliciesToRemediate -RemediateAll -RemediationType "Remediate") | Where-Object { $_.TestResult -eq "failed" };
            }
            else {
                $FailedPolicies = (Get-WCRPoliciesToRemediate -PolicyIDs $PolicyIDs -RemediationType "Remediate") | Where-Object { $_.TestResult -eq "failed" };
            }

            #Update Remediation Report with the failed Policies
            if($FailedPolicies -ne $null) {
                 #Load Back the Remediation Report
                 [xml]$RemediationReportXML = Get-Content $RemediationReport;

                 #Update the failed Policy Id to Remediation Report
                 $ColFailedPolicy = (Get-WCRPoliciesToRemediate -BaselineXML $RemediationReportXML -PolicyIDs @($FailedPolicies.ID) -RemediationType "Remediate")
                 ForEach($FailedPolicy in $ColFailedPolicy) {
                    try { $FailedPolicy.RemediationStatus = "Failed"; } #Set the attribute Remediation Status to Failed
                    Catch {
                        $FailedPolicy.SetAttribute("RemediationStatus","Failed");
                    }
                 }

                 #Save the Remediation Report
                 $remXml = [system.io.file]::CreateText($RemediationReport)
                 $RemediationReportXML.Save($remXml);
                 $remXml.Close()
            }
        }
    }
    Catch {
        Write-WCLog -Level error -Message $_.Exception.Message
    }
    return $RemediationReport
}

#Function to perform WC Remediation Branding
Function Set-WCRBranding {    
    param(
        $WCRRegPath, # default SOE registry location
        $BrandingName, # name of branding element..like time,logpath
        $BrandingValue # value for branding element
    )
	try {
		# if SOE registry location doesn't exist then create it
		if(!(Test-Path $WCRRegPath)){New-Item $WCRRegPath -Force | Out-Null}

		#Append Script InstallMode with Branding
		Set-ItemProperty -Path $WCRRegPath -Name $BrandingName -Value $BrandingValue
	}
	Catch {
        Write-WCLog -Level error -Message $_.Exception.Message
    }
}
#endregion