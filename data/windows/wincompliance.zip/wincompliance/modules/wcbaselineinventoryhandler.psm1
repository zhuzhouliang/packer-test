##################################################################
#Date      : 17-Nov-2014
#Author    : Harikrishnan GN
#Purpose   : Module to Parse and Set Inventory XML
 
#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

#region Get Values in InventoryXML
#-----------------------------------------------------------------------
#Function to retrieve a particular InventoryItem in XML
#-----------------------------------------------------------------------
Function Get-WCInventoryByID {
<#
  .SYNOPSIS
  Get-WCInventoryByID
  .DESCRIPTION
  Function to Get the Inventory Node
  .EXAMPLE
  Get-WCInventoryByID "HS002" $InventoryXML
  .PARAMETER InventoryID
  InventoryID that has to be queried
  .PARAMETER BaseLineXML
  XML that has to be PROCESSED
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$InventoryID,
	[Parameter(Mandatory=$true)]
    [xml]$InventoryXML  
)
    $InventoryNode = $NULL;
    
    #Read the required XML Node
    $InventoryNode = $InventoryXML.SelectNodes("//InventoryItem") | Where-Object {$_.Id -eq $InventoryID};
      
    return $InventoryNode;
  
}
#-----------------------------------------------------------------------
#Function to retrieve all sections in XML
#-----------------------------------------------------------------------
Function Get-WCInventorySections {
<#
  .SYNOPSIS
  Get-WCInventorySections 
  .DESCRIPTION
  Function to return ALL WC Inventory Sections from XML
  Return Value : XMLNode
  .EXAMPLE
  Get-WCInventorySections $InventoryXML
  .PARAMETER InventoryXML
  BaseLine XML to be processed
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [xml]$InventoryXML
)
    $NodeXML = $NULL;
      
    #Read the required XML Node
    $NodeXML = $InventoryXML.SelectNodes("//Section")
    
    return $NodeXML #return Node
}
#-----------------------------------------------------------------------
#Function to retrieve a particular section in XML
#-----------------------------------------------------------------------
Function Get-WCSingleInventorySection {
<#
  .SYNOPSIS
  Get-WCSingleInventorySection 
  .DESCRIPTION
  Function to Get Inventory Section Node For Processing
  Return Value : XMLNode
  .EXAMPLE
  Get-WCSingleInventorySection "Hardware Inventory" $InventoryXML
  .PARAMETER SectionName
  SectionName from the BaseLine XML
  .PARAMETER InventoryXML
  BaseLine XML to be processed
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$SectionName,
	[Parameter(Mandatory=$true)]
    [xml]$InventoryXML
)
    $NodeXML = $NULL;
      
    #Read the required XML Node
    $NodeXML = $InventoryXML.SelectNodes("//Section") | Where-Object {$_.Name -eq $SectionName}; 
    
    return $NodeXML #return Node
}
#-----------------------------------------------------------------------
#Function to retrieve a particular Category in XML
#-----------------------------------------------------------------------
Function Get-WCSingleInventoryCategory {
<#
  .SYNOPSIS
  Get-WCSingleInventoryCategory 
  .DESCRIPTION
  Function to Get Inventory Category Node For Processing
  Return Value : XMLNode
  .EXAMPLE
  Get-WCSingleInventoryCategory "OS Inventory" $InventoryXML
  .PARAMETER CategoryName
  CategoryName from the BaseLine XML
  .PARAMETER InventoryXML
  BaseLine XML to be processed
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$CategoryName,
	[Parameter(Mandatory=$true)]
    [xml]$InventoryXML
)
    $NodeXML = $NULL;

    #Read the required XML Node
    $NodeXML = $InventoryXML.SelectNodes("//Category") | Where-Object {$_.Name -eq $CategoryName};
        
    return $NodeXML;
}
#-----------------------------------------------------------------------
#Function to retrieve a particular Category in XML
#-----------------------------------------------------------------------
Function Get-WCInventoryCategories {
<#
  .SYNOPSIS
  Get-WCInventoryCategories 
  .DESCRIPTION
  Function to Get all Categories from Inventory XML
  Return Value : XMLNode
  .EXAMPLE
  Get-WCInventoryCategories $InventoryXML
  .PARAMETER InventoryXML
  BaseLine XML to be processed
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [xml]$InventoryXML
)
    $NodeXML = $NULL;

    #Read the required XML Node
    $NodeXML = $InventoryXML.SelectNodes("//Category")
        
    return $NodeXML;
}
#endregion
#region Set Values in InventoryXML
#-----------------------------------------------------------------------
#Function to Set the Inventory Value Field in the Policy
#-----------------------------------------------------------------------
Function Set-WCInventoryValue {
<#
  .SYNOPSIS
  Set-WCInventoryValue
  .DESCRIPTION
  Function to Set the Ouput Result Value in Inventory Node
  .EXAMPLE
  Set-WCInventoryValue "HS002" $InventoryXML
  .PARAMETER InventoryID
  InventoryID that has to be queried
  .PARAMETER BaseLineXML
  XML that has to be processed
  .PARAMETER Value
  Result Value that has to be updated.
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$InventoryID,
	[Parameter(Mandatory=$true)]
    [xml]$InventoryXML,
    $PSValue=""
)
	Write-WCLog -Level debug -Message "[Set-WCInventoryValue]";
	Write-WCLog -Level debug  -Message "Inventory ID : $InventoryID";
	try {
		if($PSValue -ne $NULL) {
			#Get the Inventory Node
			$InventoryNode = $InventoryXML.SelectNodes("//InventoryItem") | Where-Object {$_.Id -eq $InventoryID};
            
			if($InventoryNode -ne $NULL) { #If Inventory Node is Valid
                
				#Reset All exisitng Enum Values
                $InventoryNode.InventoryValues.Name = "";
                $InventoryNode.InventoryValues.Value = "";
                if($InventoryNode.InventoryValues.HasChildNodes) {
                        $InventoryNode.InventoryValues.InnerXML = "";
                }
                  
                $ColPropertyName = $null;
                $nonCollDataType = "string|char|byte|int|int32|long|bool|decimal|double|datetime|";
				#If DataType is Object[],ManagementObject,PSCustomObject
                if($PSValue.GetType().BaseType.Name.ToLower().Contains("object")) { $ColPropertyName = $PSValue.PSObject.Properties; }
                #If DataType is an Array
                elseif($PSValue.GetType().BaseType.Name.ToLower().Contains("array")) {
                    #if the Array's first element dataType is in this list, then the data is ValueType
                    if($nonCollDataType -match $PSValue[0].GetType().Name.ToLower()) {
                        $ColPropertyName = "ValueEnumeration"; #ValueEnumeration field will be used to display the node
                    }
                    else {
                         $ColPropertyName = $PSValue[0].PSObject.Properties; #Update the ColProperty Name with Properties of the Object
                    }              
                }

                if($ColPropertyName -ne $null) {
                    
                    #Create Enum Node for Each Value
                    ForEach($oValue in $PSValue) {
                        $XMLEnumNode = New-InventoryEnumNode -InventoryXML $InventoryXML -HeaderName ($InventoryNode.Name.Replace(" ","")) -ColPropertyName $ColPropertyName -PSValue $oValue
                       
    					#Update the Enum to Value Element of the Inventory Node
    				    $InventoryNode.InventoryValues.AppendChild($XMLEnumNode) | Out-Null;
                    }
				}
				else { 
                    #DataType is a String
					Write-WCLog -Level debug -Message "Updating Value to XML Node . Value = $PSValue";
					$InventoryNode.InventoryValues.SetAttribute("Name",(Update-WCBInvalidXMLChars -Value $InventoryNode.Name));
                    $InventoryNode.InventoryValues.SetAttribute("Value", (Update-WCBInvalidXMLChars -Value $PSValue).ToString().Trim());
				}
			}
			else {
				Write-WCLog -Level debug -Message "Inventory ID $Inventory doesn't Exists.";
				$InventoryXML = $NULL;
			}
		}
		else {
			Write-WCLog -Level debug -Message "Value field is NULL.";
			$InventoryXML = $NULL;
		}
	}
	Catch {
		Write-WCLog -Level Error -Message "[Set-WCInventoryValue] : Error Updating Current Value for InventoryID : $InventoryID";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        Write-WCLog -Level Error -Message $_.ScriptStackTrace # added by Umesh
		$InventoryXML = $NULL;
	}
	#Return Updated BaselineXML
	return $InventoryXML;
}
#-----------------------------------------------------------------------
#Function to create EnumCategoryNode for EnumValues for InventoryItem
#-----------------------------------------------------------------------
Function New-InventoryEnumNode {
<#
  .SYNOPSIS
  New-InventoryEnumNode
  .DESCRIPTION
  Function to EnumCategoryNode for EnumValues for a psObject
  return Value: xmlNode
  .EXAMPLE
  New-InventoryEnumNode $InventoryXML $HeaderName $ColProperties $PSValue
  .PARAMETER BaseLineXML
  XML that has to be processed
  .PARAMETER HeaderName
  HeaderName of the Current Inventory Item
  .PARAMETER ColProperties
  List of available properties for the current psobject
  .PARAMETER PSValue
  Current powershell Object that is being processed
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    $InventoryXML,
    [Parameter(Mandatory=$true)]
    $HeaderName,
    [Parameter(Mandatory=$true)]
    $ColPropertyName,
    [Parameter(Mandatory=$true)]
    $PSValue
    )
    Write-WCLog -Level debug -Message "[New-InventoryEnumNode]";
    
	try {
        #Create Category/Header Node for EnumField
		$HeaderName = Update-WCBInvalidXMLChars -Value $HeaderName -XMLElement;
        $XMLCategoryNode = $InventoryXML.CreateElement($HeaderName);

        foreach($Attribute in $ColPropertyName) {
            if($Attribute -eq "ValueEnumeration") {
                $XMLValueNode = $InventoryXML.CreateElement($Attribute);
                $XMLValueNode.InnerText = (Update-WCBInvalidXMLChars -Value $PSValue).ToString().Trim()
            }
            else {		
                #Create the Enum Node and update each value from the psObject properties
                $XMLValueNode = $InventoryXML.CreateElement((Update-WCBInvalidXMLChars -Value $Attribute.Name -XMLElement));
                Write-WCLog -Level debug -Message "Creating XMLNode Value : $($Attribute.Name)";
			
                #IF Attribute Field is Null then set the value to NULL
                if($PSValue.$($Attribute.Name) -eq $NULL ) { $XMLValueNode.InnerText = ""; }
                else {
                    $Value="";
                
                    #If the Value is Array join them by ","
                    if(($PSValue.$($Attribute.Name)).GetType().BaseType.Name.ToLower() -eq "array") {
                        $Value = $PSValue.$($Attribute.Name) -join ",";
                    }
                    else { 
                        #Value is String
                        $Value = $PSValue.$($Attribute.Name)
                    }
                    Write-WCLog -Level debug -Message "Updating Value to XML Node : $Value";
				
                    #Update the Value in EnumNode
                    $XMLValueNode.InnerText = (Update-WCBInvalidXMLChars -Value $Value).ToString().Trim();
                }
            }
            #Append the XmlNode to CategoryNode
            $XMLCategoryNode.AppendChild($XMLValueNode) | Out-Null;
        }
    }
    Catch {
        Write-WCLog -Level Error -Message "[New-InventoryEnumNode] : Error Creating XML Node";
        Write-WCLog -Level Error -Message $_.Exception.Message;
		$XMLCategoryNode.InnerXML = ""
    }
    return $XMLCategoryNode;
}
#-----------------------------------------------------------------------
#Function to Set the Attributes/Value  Field in the InventoryNode
#-----------------------------------------------------------------------
Function Set-WCInventoryAttribute {
<#
  .SYNOPSIS
  Set-WCInventoryAttribute
  .DESCRIPTION
  Function to Set the Attributes/Value field in Inventory Node
  .EXAMPLE
  Set-WCInventoryAttribute "HS002" $InventoryXML $AttribName $Value $AttribType
  .PARAMETER InventoryID
  InventoryID that has to be queried
  .PARAMETER BaseLineXML
  XML that has to be processed
   .PARAMETER AttributeName
  Field Name that has to be Set.
  .PARAMETER Value
  Attribute.Field Value that has to be Set.
  .PARAMETER AttribType
  Is the field and Attribute or Value of the XML Node
  #>
[CmdletBinding()]
Param(
    [string]$InventoryID,
    [xml]$InventoryXML,
    $AttributeName,
    $Value,
    [ValidateSet("Attribute","Value")]
	$AttribType
) 
    #If the return Value is NULL then an Error has Occoured
    #Else its Updated BaseLine XML
    
	Write-WCLog -Level debug -Message "[Set-WCInventoryAttribute]";
    Write-WCLog -Level debug -Message  "InventoryID: $InventoryID,AttributeName:$AttributeName,Value:$Value";
	
	try {
		if($Value -ne $NULL) {
			#Get the Inventory Node
			$InventoryNode = $NULL;
			$InventoryNode = $InventoryXML.SelectNodes("//InventoryItem") | Where-Object {$_.Id -eq $InventoryID};
			
            #Replace Invalid XML Characters
            $Value = Update-WCBInvalidXMLChars $Value;
            #Replace Invalid XML Characters
			$AttributeName = Update-WCBInvalidXMLChars $AttributeName;
			
			if($InventoryNode -ne $NULL) { #If Inventory Node is Valid
				if($AttribType.ToLower().Trim() -eq "attribute") { #Set Attribute field
					$InventoryNode.SetAttribute($AttributeName,$Value.ToString());
				}
				else { #Set the Node Field
					$InventoryNode.$AttributeName = $Value.ToString();
				}
			}
			else {
				Write-WCLog -Level debug -Message "Inventory ID $Inventory doesn't Exists.";
				$InventoryXML = $NULL;
			}
		}
		else {
			Write-WCLog -Level debug -Message "Value field is NULL.";
			$InventoryXML = $NULL;
		}
	}
	Catch {
		Write-WCLog -Level Error -Message "[Set-WCInventoryAttribute] : Error Updating Value for InventoryID : $Inventory";
        Write-WCLog -Level Error -Message $_.Exception.Message;
		$InventoryXML = $NULL;
	}
	#Return Updated BaselineXML
	return $InventoryXML;

}
#-----------------------------------------------------------------------
#Function to Set the Attributes/Value  Field in the InventoryNode
#-----------------------------------------------------------------------
Function Remove-WCBaselineInventoryFields {
<#
  .SYNOPSIS
  Remove-WCBaselineInventoryFields
  .DESCRIPTION
  Function to remove Baseline Inventory Fields from final report.
  .EXAMPLE
  Remove-WCBaselineInventoryFields $ResultXML
  .PARAMETER InventoryXML
  XML that has to be processed
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [xml]$InventoryXML,
    $InventoryCategories
)  
    Write-WCLog -Level debug -Message "[Remove-WCBaselineInventoryFields]";
    
    try {
        $InventoryItemXML = $InventoryXML.SelectNodes("//InventoryItem");
        $NodeDeleteList = "InventoryCommand","DataType","InventoryType";#Remove Nodes InventoryCommand,Inventory Type,DataType
        
        ForEach($Inventory in $InventoryItemXML) { 
            ForEach($Field in $NodeDeleteList) {
            
            $node=$Inventory.SelectSingleNode($Field);
            $Inventory.RemoveChild($node)|Out-Null;
            
            }
        }
        if($InventoryCategories -ne $NULL) {
            #Identify Nodes which are not processed
            $ColICategoriestoDelete = Get-WCInventoryCategories -InventoryXML $InventoryXML | Where-Object { ($InventoryCategories -contains $_.Name) -eq $False };
            ForEach($CategoriestoDelete in $ColICategoriestoDelete) {
                #Remove Node
                ($CategoriestoDelete.ParentNode).RemoveChild($CategoriestoDelete)|Out-Null;
            }
        }
        
    }
   Catch {
		Write-WCLog -Level Error -Message "[Remove-WCBaselineInventoryFields] : Error Removing Default Fields from Ouput Inventory XML";
        Write-WCLog -Level Error -Message $_.Exception.Message;
		$InventoryXML = $NULL;
	} 
    return $InventoryXML;       
 }
#endregion
#region InventoryXML Process
#-----------------------------------------------------------------------
#Function to Set the Attributes/Value  Field in the InventoryNode
#-----------------------------------------------------------------------
Function Start-WCInventoryCollection {
<#
  .SYNOPSIS
  Start-WCInventoryCollection
  .DESCRIPTION
  Function to Parse and Process Inventory XML
  .EXAMPLE
  Start-WCInventoryCollection $InventoryXML $ColInventoryCategories 
  .PARAMETER InventoryXML
  XML that has to be processed
   .PARAMETER ColInventoryCategories (Optional Parameter)
  XML that has to be processed
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    $FilePath,
    $InventoryCategories,
	[Switch] $HideProgress
) 
    Write-WCLog -Level debug -Message "[Start-WCInventoryCollection]"
    Write-WCLog -Level debug -Message "Collecting inventory using baseLine XML $FilePath"
	
	try {
		if((Test-Path $FilePath) -eq $false) {
			Write-WCLog -Level debug -Message "Specified inventory collection XML File does not exist"
			return $NULL
		}
		#Reading XML File
		[xml]$InventoryXML = Get-Content $FilePath
		
		#If the Parametere is not Passed then process all categories
		if($InventoryCategories -eq $NULL) {
			$ColICategoriestoProcess = Get-WCInventoryCategories -InventoryXML $InventoryXML | Select-Object Name;
		}
		else {
			$ColICategoriestoProcess = Get-WCInventoryCategories -InventoryXML $InventoryXML | Where-Object { $_.Name -in @($InventoryCategories)} |  Select-Object Name;
		}

        # start processing each inventory category, set progress tracker variables
		$ProgressCount = 0 # progress tracker
        $ItemsCount = 0 # total number of inventory items to process. Calculated below.
        foreach($cat in $ColICategoriestoProcess) { 
            $ItemsCount = $ItemsCount + ($InventoryXML.SelectNodes("//Category") | 
                Where-Object { $_.Name -eq $cat.Name}).InventoryItem.Count 
        } # total Inventory items to process

		ForEach($CategorytoProcess in $ColICategoriestoProcess) {
			#Identify the CategoryNode By Name
			$CategoryName = $CategorytoProcess.Name;
			
			$CategoryNode = Get-WCSingleInventoryCategory -CategoryName $CategoryName -InventoryXML $InventoryXML;
			
			if($CategoryNode -ne $NULL) {
				#Process Each Inventory Item
				ForEach($InventoryItem in $CategoryNode.InventoryItem) {
                    if($HideProgress.IsPresent -eq $false) {
				        #Display Progress of  Inventory Collection
				        Write-Progress -activity "Collecting Inventory for Category: $($CategorytoProcess.Name)" `
                            -CurrentOperation "Processing Item: $($InventoryItem.Name)" `
                            -PercentComplete (($ProgressCount/$ItemsCount)*100)
				        $ProgressCount = $ProgressCount + 1;
			        }
					try { 
						Write-WCLog -Level debug -Message "Processing Inventory ID:$($InventoryItem.ID)";
						Write-WCLog -Level debug -Message "Running psExpression:$($InventoryItem.InventoryCommand)";
						#Run the ps Command to collect Inventory Item
						if($InventoryItem.InventoryType -eq "psExpression") {
							$ExpressionResult = Invoke-Expression $($InventoryItem.InventoryCommand);
							#Update the Result to XML Node
							$InterimResXML = Set-WCInventoryValue -InventoryID $InventoryItem.ID -InventoryXML $InventoryXML -psValue $ExpressionResult;
							if($InterimResXML -ne $NULL) {
								$InventoryXML = $InterimResXML;
							}
							else {
								Write-WCLog -Level debug -Message "Error Updating Inventory Value Node for InventoryID : $($InventoryItem.ID)";
							}
							#Processed = true
							$InventoryItem.Processed = "True";
						}
					}
					catch {
						Write-WCLog -Level Error -Message "[Start-WCInventoryCollection] : Error Processing Inventory Value for InventoryID : $($InventoryItem.ID)";
						Write-WCLog -Level Error -Message $_.Exception.Message;
						Write-WCLog -Level Error -Message $_.ScriptStackTrace;
					}
				}
			}
		}
		#Remove Baseline fields from the result XML
		$InterimResXML = Remove-WCBaselineInventoryFields -InventoryXML $InventoryXML -InventoryCategories $InventoryCategories;
		if($InterimResXML -ne $NULL) {
			$InventoryXML = $InterimResXML;
		}
	}
	catch {
        Write-WCLog -Level Error -Message "[Start-WCInventoryCollection] : Error Starting Inventory Collection";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        Write-WCLog -Level Error -Message $_.ScriptStackTrace;
        $InventoryXML = $NULL;
    }
    return $InventoryXML;  
}
#endregion
#region BaseLine Validation
Function Test-WCBaselLineInventoryXML {
<#
  .SYNOPSIS
  Test-WCBaselLineInventoryXML
  .DESCRIPTION
  Function to Validate Inventory XML
  .EXAMPLE
  Test-WCBaselLineInventoryXML $InventoryXML
  .PARAMETER InventoryXML
  XML that has to be processed
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [xml]$InventoryXML
)
    Write-WCLog -Level debug -Message "[Test-WCBaselLineInventoryXML]";
    try {
        #Validate Category
        if((Test-WCValidateInventoryCategory -InventoryXML $InventoryXML) -eq $false) {return $false;}
        #Validate InventoryItem
        if((Test-WCValidateInventoryItem -InventoryXML $InventoryXML) -eq $false) {return $false;}
    }
    catch {
        Write-WCLog -Level Error -Message "[Test-WCBaselLineInventoryXML] : Error Validating BaseLine XML";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
    return $True;
}

Function Test-WCValidateInventoryCategory {
<#
  .SYNOPSIS
  Test-WCValidateInventoryCategory
  .DESCRIPTION
  Function to Validate Category Sections in XML
  .EXAMPLE
  Test-WCValidateInventoryCategory $InventoryXML
  .PARAMETER InventoryXML
  XML that has to be processed
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [xml]$InventoryXML
)
    Write-WCLog -Level debug -Message "[Test-WCValidateInventoryCategory]";
    
    try {
        #Validate Category       
        $ValidateCategories = Get-WCInventoryCategories -InventoryXML $InventoryXML;
		#XML will append the Node Name as Category if not Specified
        if(($ValidateCategories | Where-Object { ($_.Name -eq "") -or ($_.Name -eq "Category") }) -ne $NULL) { 
            Write-WCLog -Level debug -Message "[Test-WCValidateInventoryCategory] : Category Names are not specified for some of the Nodes in XML";
            return $false; 
        }
        
        #Validate Duplicate Category Names
        $CompareResult = ([string[]]($ValidateCategories | Select-Object Name)  | group | Where-Object {$_.Count -gt 1}) |Select-Object Name;
        if($CompareResult -ne $NULL) {
            Write-WCLog -Level debug -Message "[Test-WCValidateInventoryCategory] : Duplicate Category Names Exists : " + ([string[]]($CompareResult) -Join ',');
            return $false;
        }
    }
    catch {
        Write-WCLog -Level Error -Message "[Test-WCValidateInventoryCategory] : Error Validating BaseLine XML";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
   return $true; 
}

Function Test-WCValidateInventoryItem {
<#
  .SYNOPSIS
  Test-WCValidateInventoryItem
  .DESCRIPTION
  Function to Validate Inventory Items  in XML
  .EXAMPLE
  Test-WCValidateInventoryItem $InventoryXML
  .PARAMETER InventoryXML
  XML that has to be processed
  #>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)]
    [xml]$InventoryXML
)
    Write-WCLog -Level debug -Message "[Test-WCValidateInventoryItem]";
    
    try {
         
        $ColMandatoryFields = "InventoryValues","InventoryCommand","DataType","Name","ID";
        $ColNonEmptyFields = "Name","ID";
        
        #Validate InventoryItem Mandatory Fields and Non Empty Fields
        $boolStatus = $true
        $colInventoryItem = $InventoryXML.SelectNodes("//InventoryItem")
        ForEach($InventoryItem in $colInventoryItem) {
            ForEach($MandatoryField in $ColMandatoryFields) {
                if($InventoryItem.$MandatoryField -eq $NULL) { #Check for Mandatory Fields
                    Write-WCLog -Level debug -Message "[Test-WCValidateInventoryItem] : MandatoryField $MandatoryField is missing for the InventoryItem $($InventoryItem.ID)";
                    $boolStatus = $false;
                }
                elseif($ColNonEmptyFields -contains $MandatoryField) { #Check for NonEmty Fields
                    if($InventoryItem.$MandatoryField -eq "") {
                        Write-WCLog -Level debug -Message "[Test-WCValidateInventoryItem] : MandatoryField $MandatoryField is Empty for InventoryItem $($InventoryItem.ID)";
                        $boolStatus = $false;
                    }
                }           
            } 
        }
        if($boolStatus -eq $false) { return $false; }
        
        #Validate Duplicate InventoryItem ID
        $CompareResult = ([string[]]($colInventoryItem | Select-Object ID)  | group | Where-Object {$_.Count -gt 1}) |Select-Object Name;
        if($CompareResult -ne $NULL) {
            Write-WCLog -Level debug -Message "[Test-WCValidateInventoryItem] : Duplicate InventoryItem ID Exists : " + ([string[]]($CompareResult) -Join ',');
            return $false;
        }
        
    }
    catch {
        Write-WCLog -Level Error -Message "[Test-WCValidateInventoryItem] : Error Validating BaseLine XML";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
   return $true; 
}
#endregion