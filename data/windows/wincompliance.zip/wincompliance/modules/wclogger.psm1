﻿# This script module contains functions related to logging in WinCompliance tool.
# Author: Umesh Thakur
# Date  : 12-Nov-2014

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

[CmdletBinding()]
Param ()

# set verbose/debug preferences of the script that loads this module
if((Get-Module).Name -contains 'LogCallerPref') { # works in PS3.0 and above
    $verbosePref = Get-CallerVerbosePreference # set it for module
    $DebugPref = Get-CallerDebugPreference # set it for module
}
else { 
    Write-Warning "You must import LogCallerPref module before importing this module"
    exit
}

#region ModuleVariables
# this is default log file name auto-created to write log entries to, in case user didn't set log name
# it is responsibility of the ps1 script that loads  this module to set the log file if they want.
[string] $WCLogFile = "$($env:temp)\wc-$((Get-Date).ToString('MMddyyyy-hhmmss')).log"
[string] $LogLevel = "info" # 'info', 'debug' are two options available
#endregion ModuleVariables

#region LogFileNameFunctions
function Get-WCLogFile { return $script:WCLogFile }
function Set-WCLogFile([string]$LogPath) { 
	if((Test-Path $LogPath) -eq $false) { 
        New-Item -ItemType File -Path $LogPath -Force | Out-Null
    }
	$script:WCLogFile = $LogPath 
}
#endregion LogFileNameFunctions

#region LogLevelFunctions
function Get-WCLogLevel { return $script:LogLevel }

function Set-WCLogLevel {
[CmdletBinding()]
param([string][ValidateSet('info', 'debug')]$LogLevel) 
    $script:LogLevel = $LogLevel 
}
#endregion LogLevelFunctions

#region LoggingFunctions

Function Test-IsLogLevelPermitted {
[CmdletBinding()]
param([string] [ValidateSet('warning', 'error', 'info', 'debug', 'none')]$MessageLogLevel)
    switch($script:LogLevel) {
        'info' { return ($MessageLogLevel -ne 'debug') }
        'debug' { return $true }
    }
}

# This function will write a log message in given log file. 
# Intended to be used with different log file
# -----------------------------------------------------------
Function Write-WCLog {
[CmdletBinding()]
param(
    [string]$LogFile = $Script:WCLogFile,   #if user didn't provide then default to what is set in the module
    [string][ValidateSet('warning', 'error', 'info', 'debug', 'none')] $Level = 'none',
    [string] $LogSource = "", # typically function name of the caller or blank
    $Message
)
    # based on logLevel set on script level (this module level); and logLevel passed with this function
    # determine if current log entry will go into log file. If it goes then write log, else skip it
    if(Test-IsLogLevelPermitted -MessageLogLevel $Level) { 
        # in date formatting, mm is minutes, MM is month!
        $formattedDateTime = "[" + (Get-Date).ToString("MM-dd-yyyy hh:mm:ss") + "] "

        if($LogSource) { $LogSource = "[$LogSource]" } # surround logSource with []

        # Construct message to log in the given log file
        if($Level -eq 'none') { 
            $Message = $formattedDateTime + $LogSource + $Message # updated message with date/log-level info
        }
        else {
            $Message = $formattedDateTime + $LogSource +  "[$Level] " + $Message # updated message with date/log-level info
        }
        
        # now write the log line into file
        try { 
            #Out-File -FilePath $LogFile -Encoding ascii -Append -InputObject $Message -Force -ErrorAction Stop
            [System.IO.File]::AppendAllText($LogFile,$Message + "`r`n") # use .net method for faster performance

            # if user has called main script (who loads this module) with -verbose then below line will output message
            if($verbosePref -eq 'Continue') { Write-Verbose -Message $Message -Verbose:($verbosePref -eq 'Continue') }
        }
        catch {
            Write-Warning "[warning] Unable to write to given log file $LogFile"
            Write-Warning ($_.Exception.Message)
        }
    }
}

# this is experimental function.. shouldn't be there in final module
Function Get-CallerName($scope) {
    # get caller function or script's name, for logging purposes
    $myCaller = (Get-Variable MyInvocation -Scope $scope).Value.MyCommand.Name
    if($myCaller) { $myCaller = "[$myCaller] " } else { $myCaller = "[Unknown] " }
    return $myCaller
}
#endregion LoggingFunctions
