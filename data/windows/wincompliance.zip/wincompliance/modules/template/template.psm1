#----------------------------------------------------------------------
#Function to update <>
#----------------------------------------------------------------------
#Start the function name with known verbs  eg: Start-ConfigSNMP Set-ConfigSNMP 
Function <functionName> { 
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
$DefaultValue
#You may wish to add additonal parameters and pass them from the policyKey field in the PolicyNode of BaseLine XML Eg: CommunityString
)
    
    try  {
        Write-WCLog -Level debug -Message "Logs cane be written using WC inbuilt function Write-WCLog which is imported by default while running scan or remediation"
        
        if($Action -eq "Scan") {
            #Write the code to read the setting while performing the WC Scan
			#return the value
			$oreturn = "";
			#You may wish to return only specific values while performing the scan, so that you can restrict the possible values for remedition
				#You may wish to find the list of possible values for the scan eg: Enabled,Disabled,NotExists
				#[ValidateSet("Enabled","Disabled","NotExists")] $DefaultValue
        }
	    elseif($Action -eq "remediate") {
			#write the code for remediation here
			
			#You may wish to use the $defaultvalue parameter to identify which setting should be applied.
			#In case of remediation DefaultValue is the policy Value which is there in DefaultValue field under the Policy Node in the baseline xml.
			#In case of revert the DefaultValue will hold the value from the Current Value field in the Policy Node in BaseLine XML.
			#Considering the above validation set [ValidateSet("Enabled","Disabled","NotExists")] $DefaultValue
			#The remediation code will be in below format
			#if($DefaultValue -eq "Enabled") #{  Code to set the value to Enabled }
			#elseif($DefaultValue -eq "Disabled") #{  Code to set the value to Disabled }
			#elseif($DefaultValue -eq "NotExists") #{  Code to set the value to NotExists }
			
			#return Success if remediation is succesfull as the script looks for the return value Success to mark the setting as remediated
            $oreturn = "Success"  
			
		}
    }
    catch {
        $oreturn = $_.Exception.Message;
    }
    return $oreturn;
}

#How to Import this Module at the time of Remediation or Scan 
#WC Remediation and Scan script has a parameter to import custom modules -importModule <path to the psm1 file> 
#You may wish to refer additional functionality guide for more details. 

#How to update the PolicyNode for calling above function
#In the Baseline XML create a Policy Node with psModule as DataType and in PolicyNamemention the function Name you are writting eg : Start-ConfigSNMP
#<Policy Id="SBC023" ReadOnly="True" Rank="0" Risk="3" Platform="All" Processed="False" Runson="All" Purpose="Compliance">
#	<PolicyKey>Function Name in template Module eg : Start-ConfigSNMP or Start-ConfigSNMP -CommunityString CSCSOE2K16 </PolicyKey>
#	<PolicyName>Configure SNMP</PolicyName>
#	<PolicyType>psModule</PolicyType>
#	<CompareMethod>-eq</CompareMethod>
#	<DataType>
#	</DataType>
#	<DefaultValue Value="Enabled" /> If you would like to Disable SNMP you can set this value to Disabled and while performing Remediation the setting will be disabled as per the code written in the function 
#	<CurrentValue Value="" />
#	<ValueDescription Suffix="">
#	</ValueDescription>
#	<TestResult />
#	<Comments />
#</Policy>