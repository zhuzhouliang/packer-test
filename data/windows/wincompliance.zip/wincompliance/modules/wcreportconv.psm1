﻿# This module will include functions related to converting WC report to different formats.
# it include csv, word, excel, formatted xml (for GUI display), TI etc.
# Author: Umesh Thakur
# Date  : 07-july-2015
# ----------------------------------------------------------------------------------------
# 29-apr-2016: umesh - added function to export report in Excel format
# 02-may-2016: umesh - added function to export report to Word format
# 07-jun-2016: umesh - added 'purpose' column in Format-WCReport
# 08-aug-2016: umesh - replaced .path with .providerPath on resolve-path calls to ensure UNC paths are identified
# ----------------------------------------------------------------------------------------

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

# ----------------------------------------------------------------------------------------
# This function will format WinCompliance report in a way that will be used for displaying
# it in a GUI window for basic reporting purposes. Output will be in XML format
# ----------------------------------------------------------------------------------------
Function Format-WCReport {
    [CmdletBinding()]
    param(
        [ValidateScript({([System.IO.File]::Exists((resolve-path $_).ProviderPath)) -and $_.trim().split(".")[-1] -eq 'xml'})]
        [string] $WCReportFile,
        [string] $OutputXMLFilePath, # if not specified, return a temp file containing formatted report
        [switch] $RiskRankAsNumbers
    )

    # create a dataTable with required columns for report display
    $dt = New-Object System.Data.DataTable
    $dt.TableName = 'WCReport'
    $dt.Columns.Add('ReadOnly',[bool]) | Out-Null
    $dt.Columns.Add('PolicyId',[string]) | Out-Null
    $dt.Columns.Add('Section',[string]) | Out-Null
    $dt.Columns.Add('Category',[string]) | Out-Null
    $dt.Columns.Add('Platform',[string]) | Out-Null
    $dt.Columns.Add('Purpose',[string]) | Out-Null # added 07-jun-2016
    $dt.Columns.Add('PolicyName',[string]) | Out-Null
    $dt.Columns.Add('Risk',[string]) | Out-Null
    $dt.Columns.Add('Rank',[string]) | Out-Null
    $dt.Columns.Add('DefaultValue',[string]) | Out-Null
    $dt.Columns.Add('CurrentValue',[string]) | Out-Null
    $dt.Columns.Add('Result',[string]) | Out-Null
    
    # read given report and add them to data table after getting them into reporting format
    [xml]$wcr = Get-Content $WCReportFile

    # determine if it is reporting os remediation report and adjust queries accordingly
    if($wcr.WinCompliance.RemediationReport -eq 'true' -and $wcr.WinCompliance.SupportsRemediation -eq 'true') { 
        # this is remediation report
        $reportType = 'remediation'
        $filterProperty = "Remediate"
    }
    else { 
        $ReportType = 'compliance_check'
        $filterProperty = "Processed"
    } # WC compliance check report

    # enumerate all policies in hierarchy of Section -> Category -> Policy order, process them and add to dataTable
    $sections = $wcr.SelectNodes("//Section") # collection of sections

    # start looping thru all sections
    foreach($s in $sections) {
        # all categories in current section, and enumerate thru them
        $categories = $s.Category
        foreach($c in $categories) {
            # all policies in current category and enumerate thru them, only those that are processed.
            $policies = $c.Policy 
            ForEach($p in ($policies | where {$_.$filterProperty -eq 'true'})) { # loop thru all policies in current category that matches type of report supplied

                # Identify what type of policy result current policy holds and restructure their value

                # this is an array, get defaultValue in array format (concat on ,)
                if($p.DefaultValue.HasChildNodes) { 
                    $dv = $p.DefaultValue.ValueEnumeration -join ','
                }
                else { # this is not an array, put default values as their original values
                    $dv = $p.DefaultValue.Value 
                    # if default value for given node is blank, define it as notfound to avoid xml issues
                    if($dv.Length -eq 0) { $dv='NotMentioned' }
                }

                # this is an array, get currentValue in array format (concat on ,)
                if($p.CurrentValue.HasChildNodes) { 
                    $cv = $p.CurrentValue.ValueEnumeration -join ','
                }
                else { # this is not an array, put current values as their original values
                    $cv = $p.CurrentValue.Value
                    # if current value for given node is blank, define it as notfound to avoid xml issues
                    if($cv.Length -eq 0) { $cv = 'NotFound' }
                }

                # These are values that have descriptive values mentioned in ValueDescription
                if($p.ValueDescription.HasChildNodes) { # this single value has key/value pair
                    $cvText = ($p.ValueDescription.Enum | where { $_.Key -eq $cv }).Value
                    $dvText = ($p.ValueDescription.Enum | where { $_.Key -eq $dv }).Value
                    if(-not [string]::IsNullOrEmpty($cvText)) { $cv = $cvText }
                    if(-not [string]::IsNullOrEmpty($dvText)) { $dv = $dvText }

                }
                else { # check and add suffix, these singular values just need suffix addition
                    $dv = $dv + ' ' + $p.ValueDescription.Suffix
                    $cv = $cv + ' ' + $p.ValueDescription.Suffix
                }

                # if, for some reason, risk/rank is not added/available, add them as 0
                if([string]::IsNullOrEmpty($p.Risk)) { $p.Risk = '0' }
                if([string]::IsNullOrEmpty($p.Rank)) { $p.Rank = '0' }

                # Represent risk/rank as string instead of numbers
                if(! ($RiskRankAsNumbers)) { # show risk/rank as text
                    $ht = @{''='N/A';'0'='None';'1'='Low';'2'='Medium';'3'='High';'-1'='Unknown'}
                    if(($p.risk -in (0,1,2,3))) { $p.Risk = $ht[$p.Risk] } else { $p.Risk = 'Unknown'}
                    if(($p.rank -in (0,1,2,3))) { $p.Rank = ($ht[$p.Rank]).replace('Risk','Rank') } else { $p.Rank = 'Unknown'}
                }

                # based on type of report, save Result in a variable
                if($reportType -eq 'remediation') { $res = $p.RemediationStatus } else { $res = $p.TestResult }

                # add policy to dataRow
                #$p.ReadOnly,$p.Id,$s.Name,$c.Name,$p.PolicyName,$p.Risk,$p.Rank,$dv,$cv,$p.TestResult
                $dt.Rows.Add($p.ReadOnly,$p.Id,$s.Name,$c.Name,$p.Platform,$p.Purpose,$p.PolicyName,$p.Risk,$p.Rank,$dv,$cv,$res) | Out-Null
            }
        }
    }
    
    # if user has not specified output XML file then create a temp file
    if(!($OutputXMLFilePath)) { $OutputXMLFilePath = "$($env:temp)\$([system.io.path]::GetRandomFileName())" }
   
    # save data table as XML and return the file path
    try { 
        $dt.WriteXml($OutputXMLFilePath,[System.Data.XmlWriteMode]::WriteSchema) 
        return $OutputXMLFilePath
    }
    catch { write-warning $_.Exception.Message;return $null } #error occured
}

# ------------------------------------------------------------------------------------
# This function will export WinCompliance report to CSV format. If user has specified
# Summary CSV file, report summary is also exported. Else, only report is exported.
# ------------------------------------------------------------------------------------
Function Export-WCReportToCSV {
    [CmdletBinding()]
    param(
        [ValidateScript({([System.IO.File]::Exists((resolve-path $_).ProviderPath)) -and $_.trim().split(".")[-1] -eq 'xml'})]
        [string] $WCReportFile,
        [string] $OutputCSVFilePath, 
        [string] $OutputCSVSummaryFilePath,
        [switch] $RiskRankAsNumbers
    )

    # If output path is not specified, throw warning and return error code
    if(-not $OutputCSVFilePath) {
        Write-Warning "You must specify CSV report file path to export WinCompliance report to"
        return 'export_wc_no_csv_file_specified'
    }

    # Read report XML, get report summary into a variable
    [xml]$x = Get-Content -Path $WCReportFile
    $repSummary = $x.SelectNodes("//RSItem") | select Name, DisplayName, Value

    # get formatted report in a temp file based on whether risk/rank need to be in numbers
    if($RiskRankAsNumbers) { 
        $repTempPath = Format-WCReport -WCReportFile $WCReportFile -RiskRankAsNumbers
    }
    else { $repTempPath = Format-WCReport -WCReportFile $WCReportFile }
    

    # read formatted report in XML variable for exporting it to CSV
    [xml]$repFormatted = Get-Content $repTempPath

    # if CSV summary file path is given then export the report summary in given file
    if($OutputCSVSummaryFilePath) {
        try {
            $repSummary | Export-Csv -Path $OutputCSVSummaryFilePath -Force -NoTypeInformation 
        }
        catch {
            Write-Warning "Error exporting WinCompliance report summary to CSV format."
            Write-Warning $_.Exception.Message
            #return 'export_wc_csv_summary_failed'
        }
    }
    else {
        Write-Warning "Report summary CSV file path not specified, report summary will not be exported"
    }

    # if CSV file path is given then export the report in given file
    if($OutputCSVFilePath) {
        try {
            $wcr = $repFormatted.SelectNodes("//WCReport") | Select-Object ReadOnly, PolicyId, Section, `
                Category, Platform, PolicyName, Risk, Rank, DefaultValue, CurrentValue, Result
            $wcr | Export-Csv -Path $OutputCSVFilePath -Force -NoTypeInformation
                return 'export_wc_report_success'
        }
        catch {
            Write-Warning "Error exporting WinCompliance report to CSV format."
            Write-Warning $_.Exception.Message
            return 'export_wc_csv_failed'
        }
    }
}

# ---------------------------------------------------------------------------------------------------------------
# given SOE report (and summary) CSV files, this function will export them into a new Excel spreadsheet and save 
# the file at given location. This function depends on Export-WCReportToCSV function written above
# todo: write to log file instead of verbose
# ---------------------------------------------------------------------------------------------------------------
Function Export-WCReportToExcel {
[cmdletbinding()]
param(
    [Parameter(Mandatory=$true)] [string]$WCReportFile,
    $WCReportSheetName = "WinComplianceReport",
    $WCReportSummarySheetName = "WinComplianceReportSummary",
    [Parameter(Mandatory=$true)] [string]$ExcelFilePath,
    $TableStyle = "TableStyleMedium9",
    [double[]] $ReportColumnsWidth = @(10.86,9.29,19.57,15.43,10,26,8.43,8.43,25.14,25.14,8.43), # width of report columns to set
    [switch]$HighlightFailedPolicies
)

    # construct a return object, and a method to update it with given values
    $returnObject = @{status='failed';code=0;message='WC report export to excel failed';object=$null}
    function set-returnObject($status,$code,$message,$robject) {
        if($status) { $returnObject.status = $status }
        if($code) { $returnObject.code = $code }
        if($message) { $returnObject.message = $message }
        if($robject) { $returnObject.object = $robject }
    }

    # get CSV reports first. if unable to get then return error
    $WCReportCSVFile = [System.IO.Path]::GetTempFileName().Replace('.tmp','.csv') # Temp CSV file, change .tmp to .csv for easy import in excel
    $WCReportSummaryCSVFile = [System.IO.Path]::GetTempFileName().Replace('.tmp','.csv') # Temp CSV file
    $res = Export-WCReportToCSV -WCReportFile $WCReportFile -OutputCSVFilePath $WCReportCSVFile -OutputCSVSummaryFilePath $WCReportSummaryCSVFile
    if($res -ne 'export_wc_report_success') {
        set-returnObject -code 16 -message "failed to export WC report $WCReportFile to intermediate CSV files."
        return $returnObject
    }
    Write-Verbose -Message "Attempting to create Excel COM object"

    # try to create excel object
    try { 
        $excel = New-Object -ComObject Excel.Application
    }
    catch { # error occured, throw error
        set-returnObject -code 1 -message 'error initializaing excel COM application' -robject $_
        return $returnObject
    }

    # Open given CSV files in excel workbooks
    Write-Verbose -Message "Opening WinCompliance report and summary files" 
    $excel.DisplayAlerts = $false # prevent excel from prompting any alerts to user
    #$wb1 = $excel.Workbooks.OpenText($WCReportSummaryCSVFile,[type]::Missing,[type]::Missing,1,[type]::Missing,$true,$false,$false,$true)
    $wb1 = $excel.Workbooks.OpenText($WCReportSummaryCSVFile)
    $wb2 = $excel.Workbooks.OpenText($WCReportCSVFile)
    $wbWCR = $excel.Workbooks.Item(1) # report summary CSV file
    $wbReport = $excel.Workbooks.Item(2) # WC Report CSV file
    $wbReport.Sheets.Item(1).Copy($wbWCR.Sheets.Item(1)) # copy report CSV sheet to first workbook (that has summary sheet)
    $wbWCR.Sheets.Item(1).Name = $WCReportSheetName # name them as per given name
    $wbWCR.Sheets.Item(2).Name =  $WCReportSummarySheetName 

    $wbReport.Close($false) # close report file that is opened in excel, without saving

    Write-Verbose -Message "Formatting tables"
    # name the data range as table, and format them with specified format name
    $wbWCR.Sheets.Item(1).ListObjects.Add(1,$wbWCR.Sheets.Item(1).UsedRange,0,1).name = $WCReportSheetName
    $wbWCR.Sheets.Item(1).ListObjects.Item(1).TableStyle = $TableStyle
    $wbWCR.Sheets.Item(2).ListObjects.Add(1,$wbWCR.Sheets.Item(2).UsedRange,0,1).name = $WCReportSummarySheetName
    $wbWCR.Sheets.Item(2).ListObjects.Item(1).TableStyle = $TableStyle
    
    [void]$wbWCR.Sheets.Item(2).UsedRange.EntireColumn.AutoFit() # autofit summary sheet
    
    $wbWCR.Sheets.Item(2).Move($wbWCR.Sheets.Item(1)) # move summary sheet as first sheet

    Write-Verbose -Message "Adjusting report column width"
    # adjust width of all reports column using given (or parameter default if not given) width, wrap text
    $reportSheet = $wbWCR.Sheets.Item(2) # reference to the sheet that contains report data
    $reportSheet.UsedRange.WrapText = $true # wrap text to width
    # iterate thru all table columns and set their width, only when count of columns and column width array count are same
    if($reportSheet.UsedRange.columns.count -eq $ReportColumnsWidth.count) {
        $reportSheet.UsedRange.columns | ForEach-Object { $_.ColumnWidth = $ReportColumnsWidth[$_.Column-1] }
    }

    # if user has specified to highlight failed policies then do so
    if($HighlightFailedPolicies) {
        Write-Verbose -Message "User specified to highlight failed policies, processing"
        $reportSheet.Activate() # activate this sheet to make selections
        $rows = $reportSheet.UsedRange.Rows.count # total policies in the sheet (includes header)
        # get column # of 'Result' column.. used for policy success/failure tracking
        #$reportSheet.UsedRange.Rows.Item(1) # output header for testing purposes
        
        [void]$reportSheet.UsedRange.Rows.Item(1).Select() # select header row
        $resultColIndex = ($excel.Selection | Where-Object { $_.Text -eq 'Result' }).Column

        # loop thru all policies and highlight failed policies. it overrides table format style that was specified!
        for($i=2; $i -le $rows; $i++) { # exclude header
            $pcomp = [math]::Round((($i*100)/$rows)) # % complete
            Write-Progress -Activity "Highlighting failed policies" -PercentComplete $pcomp -Status "Processing $i of $($rows-1) - $pcomp% complete"
	        [void]$reportSheet.UsedRange.Rows.Item($i).Select() # select row i
	        if($excel.Selection.Item($resultColIndex).Text -eq 'Failed') { 
		        #write-host "Row $i is a failed record, highlighting it"
		        $excel.Selection.Style = "40% - Accent2" 
	        }
            else { # passed policy, format differently
                $excel.Selection.Style = "40% - Accent6" 
            }
        }
        # after highlighting is done, move cursor to first cell in the sheet
        [void]$excel.Cells.Item(1,1).select()
    }

    # make report summary sheet active
    $wbWCR.Sheets.Item(1).Activate()

    # save file in excel 2007-2013 file format
    Write-Verbose -Message "Saving converted report/summary to $ExcelFilePath"
    try { # try to save it to given path/file
        $wbWCR.SaveAs($ExcelFilePath,51) #Open XML Workbook
        $wbWCR.Close()

        # set return object and return the worksheet once done
        set-returnObject -status 'success' -code 0 -message  ("Successfully exported WC report {0} to excel worksheet" -f $WCReportFile) -robject $ExcelFilePath
    }
    catch {
        Write-Verbose "Unable to save report to $ExcelFilePath" 
        set-returnObject -status 'failed' -code 4 -message ("Failed to export CSV file to excel worksheet {0}" -f $ExcelFilePath) -robject $_
    }
    
    # cleanup COM object, its ugly but it is how COM is!
    $wb1, $wb2, $reportSheet, $wbReport, $wbWCR | ForEach-Object {
        $_.Close()
        [void] [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($_)
    }
    
    $excel.quit() # quit excel application and release COM object
    [void] [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)

    $wb1 = $wb2 = $reportSheet = $wbReport = $wbWCR = $excel = $null # nullify them all

    return $returnObject # return the object with execution status

}

# -------------------------------------------------------------------------------------------------
# given SOE report file, this function will export them into a new Word document and save 
# the file at given location. 
# todo: write to log file instead of verbose
# --------------------------------------------------------------------------------------------------
Function Export-WCReportToWord {
[cmdletbinding()]
param(
    [Parameter(Mandatory=$true)] [string]$WCReportFile,
    [Parameter(Mandatory=$true)] [string]$WordFilePath,
    $TableStyle = "Grid Table 4 - Accent 5"
    #[double[]] $ReportColumnsWidth = @(10.86,9.29,19.57,15.43,10,26,8.43,8.43,25.14,25.14,8.43), # width of report columns to set
    #[switch]$HighlightFailedPolicies
)

    # construct a return object, and a method to update it with given values
    $returnObject = @{status='failed';code=0;message='WC report export to Word failed';object=$null}
    function set-returnObject($status,$code,$message,$robject) {
        if($status) { $returnObject.status = $status }
        if($code) { $returnObject.code = $code }
        if($message) { $returnObject.message = $message }
        if($robject) { $returnObject.object = $robject }
    }

    # get CSV reports first. if unable to get then return error
    $WCReportCSVFile = [System.IO.Path]::GetTempFileName().Replace('.tmp','.csv') # Temp CSV file, change .tmp to .csv for easy import in excel
    $WCReportSummaryCSVFile = [System.IO.Path]::GetTempFileName().Replace('.tmp','.csv') # Temp CSV file
    $res = Export-WCReportToCSV -WCReportFile $WCReportFile -OutputCSVFilePath $WCReportCSVFile -OutputCSVSummaryFilePath $WCReportSummaryCSVFile
    if($res -ne 'export_wc_report_success') {
        set-returnObject -code 16 -message "failed to export WC report $WCReportFile to intermediate CSV files."
        return $returnObject
    }
    Write-Verbose -Message "Attempting to create Word COM object"

    # try to create excel object
    try { 
        $word = New-Object -ComObject Word.Application
    }
    catch { # error occured, throw error
        set-returnObject -code 1 -message 'error initializaing Word COM application' -robject $_
        return $returnObject
    }

    $word.DisplayAlerts = "wdAlertsNone" # prevent excel from prompting any alerts to user
    $Word.Options.Pagination=$false
    $Word.ScreenUpdating=$false
    # start processing, load template file and add WC records
    $wcWordTemplate = "$PSScriptRoot\..\bin\wcwordt.docx" # WC word template file
    $doc = $word.Documents.Open($wcWordTemplate)
    $doc.ActiveWindow.View.Type = 1 # 1 is wdNormalView, 3 is wdPrintView
    if($doc.Tables.count -ne 3) { # something wrong with template, quit
        Write-Verbose "WC word template is not in expected format, WC report export to word failed"
        set-returnObject -code 2 -message 'WC word template is not in expected format, WC report export to word failed'
        return $returnObject
    }

    # prevent tables from auto-fit when data is added, it simply ruins the tables
    $doc.Tables.Item(2).AllowAutoFit = $false
    $doc.Tables.Item(3).AllowAutoFit = $false

    # import report summary - its table #2
    $csvSummary = Import-Csv -Delimiter ',' -Path $WCReportSummaryCSVFile
    $row = 2 # starting row
    Write-Verbose "Exporting report summary to word document"
    $csvSummary | foreach { 
        [void]$doc.Tables.Item(2).Rows.Add()
        $doc.Tables.Item(2).Cell($row,1).Range.Text = $_.Name 
        $doc.Tables.Item(2).Cell($row,2).Range.Text = $_.Value
        $row = $row + 1
    }

    # import report - its table #3
    $csvReport = Import-Csv -Delimiter ',' -Path $WCReportCSVFile
    $rows = $csvReport.count
    $row = 2 # starting row
    Write-Verbose "exporting WC policies to word document"
    $csvReport | foreach { 
        [void]$doc.Tables.Item(3).Rows.Add()
        $doc.Tables.Item(3).Cell($row,1).Range.Text = $_.PolicyId
        $doc.Tables.Item(3).Cell($row,2).Range.Text = $_.PolicyName
        $doc.Tables.Item(3).Cell($row,3).Range.Text = $_.DefaultValue
        $doc.Tables.Item(3).Cell($row,4).Range.Text = $_.CurrentValue
        $doc.Tables.Item(3).Cell($row,5).Range.Text = $_.Result
        
        # highlight failed policies in red font
        if($_.Result -eq 'Failed') { 
            #1..5 | foreach { $doc.Tables.Item(3).Cell($row,$_).Range.Font.Color = "wdColorRed"  }
            $doc.Tables.Item(3).rows.item($row).Range.Font.Color = "wdColorRed"
        }
        
        $pcomp = [math]::Round((($row*100)/$rows)) # % complete
        Write-Progress -Activity "exporting policies to word document" -PercentComplete $pcomp -Status "Processing $row of $($rows-1) - $pcomp% complete"
        $row = $row + 1 # next row
    }
    # change doc view to print view now
    $doc.ActiveWindow.View.Type = 3 # 1 is wdNormalView, 3 is wdPrintView
    Write-Verbose -Message "Saving converted report/summary to $ExcelFilePath"
    try { # try to save it to given path/file
        $doc.SaveAs([ref]$WordFilePath,[ref]16) # wdFormatDocument = 0 (97-2003 .doc), wdFormatDocumentDefault = 16 (.docx), wdFormatPDF=17
        #$doc.SaveAs([ref]($WordFilePath + '.pdf'),[ref]17) # wdFormatDocument = 0 (97-2003 .doc), wdFormatDocumentDefault = 16 (.docx), wdFormatPDF=17
        $doc.close()

        # set return object and return the worksheet once done
        set-returnObject -status 'success' -code 0 -message  ("Successfully exported WC report {0} to word document" -f $WCReportFile) -robject $WordFilePath
    }
    catch {
        Write-Verbose "Unable to save report to $ExcelFilePath" 
        set-returnObject -status 'failed' -code 4 -message ("Failed to export WC report to word document {0}" -f $WordFilePath) -robject $_
    }
    
    [void] [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($doc)
    $doc = $null
    $word.quit()
    [void] [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($word)
    $word = $null

    return $returnObject
}

# --------------------------------------------------------------
# This function will export WinCompliance report to HTML format.
# --------------------------------------------------------------
Function Export-WCReportToHTML {
    [CmdletBinding()]
    param(
        [ValidateScript({([System.IO.File]::Exists((resolve-path $_).ProviderPath)) -and $_.trim().split(".")[-1] -eq 'xml'})]
        [string] $WCReportFile,
        [string] $OutputHTMLFilePath, 
        [switch] $RiskRankAsNumbers
    )

    # check if output HTML file path is specified. quit if not 
    if(-not $OutputHTMLFilePath) { 
         Write-Warning "You must specify HTML report file path to export WinCompliance report to"
        return 'export_wc_no_html_file_specified'
    }

     # Read report XML, get report summary into a variable
    [xml]$x = Get-Content -Path $WCReportFile
    $repSummary = $x.SelectNodes("//RSItem") | select Name, DisplayName, Value

    # get formatted report in a temp file based on whether risk/rank need to be in numbers
    if($RiskRankAsNumbers) { 
        $repTempPath = Format-WCReport -WCReportFile $WCReportFile -RiskRankAsNumbers
    }
    else { $repTempPath = Format-WCReport -WCReportFile $WCReportFile }
    
    # read formatted report in XML variable for exporting it to HTML
    [xml]$repFormatted = Get-Content $repTempPath

    # get path of html report template in a variable. $psscriptroot will be modules root for this function
    $reptFile = "$PSScriptRoot\..\userInterface\psr\ht\rept.html"

    if(-not ([system.io.file]::Exists($reptFile))) { # if report template not found, exit and return
        return 'export_wc_html_rept_notfound'
    }

    # read report template in a variable for manipulation
    $rept = Get-Content $reptFile -Raw # read as a single big string rather than array of string

    # get some report summary items for compliance display
    $reptHostName = $x.SelectNodes("//RSItem[@Name='ReportGeneratedOnServer']").Value # server name
    $cp = $x.SelectNodes("//RSItem[@Name='CompliancePercent']").Value # compliance %
    $baselineUsed = $x.SelectNodes("//RSItem[@Name='BaselineUsed']").Value.split('\')[-1].replace('.xml','')

    # update report title -> __WC_REPORT_TITLE__
    $rept = $rept -replace '__WC_REPORT_TITLE__',"WinCompliance Report for server $reptHostName"

    # set compliance information in report (html) variable. replace placeholders with actuals
    $rept = $rept -replace '__SERVER__',$reptHostName
    $rept = $rept -replace '__CPERCENT__',$cp
    $rept = $rept -replace '__SOEVER__',($baselineUsed -replace 'soe','')

    # set color of compliance percentage row. It is calculated based on compliance percentage
    $cper = ($cp -replace '%','') # replace % from compliance score
    if([int]::TryParse($cper,[ref]$null)) { $cper = [int]$cper }
    if($cper -lt 60) { $cpColor = "red" }
    elseif($cper -lt 80) { $cpColor = "orangered" }
    elseif($cper -lt 100) { $cpColor = "blue" }
    elseif($cper -eq 100) { $cpColor = "green" }
    else { $cpColor = "black" } # in case none of conditions match
    $rept = $rept -replace '__CPCOLOR__',$cpColor

    # Update report summary -> __WC_REPORT_SUMMARY__
    $sbRepSummary = New-Object System.Text.StringBuilder
    
    # loop thru all report summary items and add them in report summary table
    For($i=0; $i -lt $repSummary.count; $i++) {
        # some summary items need alternate coloring.. identify and do it here # 
        $exStyleColor = "" # by-default, warning coloring will not be set.. only do it on identified items
        # if compatible baseline is not used, color as warning (orange)
        if($repSummary[$i].Name -eq 'CompatibleBaseline' -and $repSummary[$i].Value -eq 'false') {
            $exStyleColor = "style=`"color:orangered`""
        }
        # if SOE default baseline is not used for testing, color as warning (orange)
        if($repSummary[$i].Name -eq 'DefaultBaselineUsed' -and $repSummary[$i].Value -eq 'false') {
            $exStyleColor = "style=`"color:orangered`""
        }
        # if custom apps are installed, color as warning (orange)
        if($repSummary[$i].Name -eq 'CustomAppsInstalled' -and $repSummary[$i].Value -eq 'true') {
            $exStyleColor = "style=`"color:orangered`""
        }
        # color compliance percent as per identified color above
        if($repSummary[$i].Name -eq 'CompliancePercent') {
            $exStyleColor = "style=`"color:$cpColor`""
        }
        
        # alternate table row style
        if($i%2 -eq 0) { 
            $sbRepSummary.Append("`n`t`t`t`t<tr class=`"wc-table-odd`" $exStyleColor>") | Out-Null
        } 
        else { $sbRepSummary.Append("`n`t`t`t`t<tr $exStyleColor>") | Out-Null }

        # add td for summary item name
        $sbRepSummary.Append("`n`t`t`t`t`t<td>$($repSummary[$i].DisplayName)</td>") | Out-Null

        # add td for summary item value
        $sbRepSummary.Append("`n`t`t`t`t`t<td>$($repSummary[$i].Value)</td>") | Out-Null

        # close tr tag
        $sbRepSummary.Append("`n`t`t`t`t</tr>") | Out-Null
    }

    # replace summary items placeholder with actual data
    $rept = $rept -replace '__WC_REPORT_SUMMARY__',$sbRepSummary.ToString()

    # Update policy details to html variable -> __WC_REPORT_POLICY_DETAILS__
    $sbPolicies = New-Object System.Text.StringBuilder
    $rc = 1 # use it for row CSS style alternation

    $wcr = $repFormatted.SelectNodes("//WCReport")
    $sectionGroup = $wcr | Group-Object -Property Section
    foreach($sec in $sectionGroup) {
        #Write-host ("{0} ({1})" -f $sec.Name, $sec.Count)
        $sbPolicies.Append("`n`t`t`t`t<tr class=`"wc-table-section`">`n") | Out-Null
        $sbPolicies.Append("`n`t`t`t`t`t<td colspan=`"6`">$($sec.Name) ($($sec.Count))</td>`n") | Out-Null
        $sbPolicies.Append("`t`t`t`t</tr>") | Out-Null
        $catGroup = $sec.Group | Group-Object -Property Category
        foreach($cat in $catGroup) {
            #Write-host ("`t{0} ({1})" -f $cat.Name, $cat.Count)
            $sbPolicies.Append("`n`t`t`t`t<tr class=`"wc-table-category`">`n") | Out-Null
            $sbPolicies.Append("`n`t`t`t`t<td colspan=`"6`">$($cat.Name) ($($cat.Count))</td>`n") | Out-Null
            $sbPolicies.Append("`t`t`t`t</tr>") | Out-Null
            foreach($pol in $cat.Group) {
                # process policies here
                # write starting node for TR with row alternation style
                if($rc%2 -eq 0 -and $pol.purpose -eq 'info') {
                    $clName = "class=`"wc-table-odd wc-table-informational`""
                }
                elseif($rc%2 -eq 1 -and $pol.purpose -eq 'info') {
                    $clName = "class=`"wc-table-informational`""
                }
                elseif($rc%2 -eq 0 -and $pol.result -eq 'failed') {
                    $clName = "class=`"wc-table-odd wc-table-failed`""
                }
                elseif($rc%2 -eq 0 -and $pol.result -eq 'passed') {
                    $clName = "class=`"wc-table-odd`""
                }
                elseif($rc%2 -eq 1 -and $pol.result -eq 'failed') {
                    $clName = "class=`"wc-table-failed`""
                }
                
                else { $clName = "" }
        
                $sbPolicies.Append("`n`t`t`t`t<tr $clName>`n") | Out-Null
        

                # add td for each policy node
                $sbPolicies.Append("`t`t`t`t`t<td>$($rc.ToString('000'))</td>`n") | Out-Null
                $sbPolicies.Append("`t`t`t`t`t<td>$($pol.PolicyId)</td>`n") | Out-Null
                $sbPolicies.Append("`t`t`t`t`t<td>$($pol.PolicyName)</td>`n") | Out-Null
                $sbPolicies.Append("`t`t`t`t`t<td>$($pol.DefaultValue)</td>`n") | Out-Null
                $sbPolicies.Append("`t`t`t`t`t<td>$($pol.CurrentValue)</td>`n") | Out-Null
                if($pol.result -eq 'failed') { 
                    $sbPolicies.Append("`t`t`t`t`t<td>$($pol.Result)</td>`n") | Out-Null
                }
                else {
                    $sbPolicies.Append("`t`t`t`t`t<td>$($pol.Result)</td>`n") | Out-Null
                }
                $sbPolicies.Append("`t`t`t`t</tr>`n") | Out-Null

                $rc = $rc + 1 # increment row counter
            }
        }
    }

    # replace policy details placeholder with actual data
    $rept = $rept -replace '__WC_REPORT_POLICY_DETAILS__',$sbPolicies.ToString()

    # write html data to given report file
    [system.io.file]::WriteAllText($OutputHTMLFilePath,$rept)
    return 'export_wc_report_success'

}

Function Test-psrPath {
    write-host "psscript root is $PSScriptRoot"
    write-host "$PSScriptRoot\..\userInterface\psr\ht\rept.html"
}

