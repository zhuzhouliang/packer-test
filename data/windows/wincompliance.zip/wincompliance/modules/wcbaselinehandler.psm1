# Date    : 17-Nov-2014
# Author  : Harikrishnan GN
# Purpose : Module to Parse, Get and Set BaseLineXML Nodes
# Updated : 03-sep-2015 by Umesh - to correct condition for writing CustomApps branding in the registry
# Updated : 06-may-2016 by Umesh - updated SelectNodes calls with Get-WCXMLNodes function that supports Nano as well

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

#region ModuleVariables

# this variable will hold value of baseline XML file supplied to the script that calls this module
# all functions of this module will reference it for baseline XML processing and updation
# once the caller script is done with processing of baseline XML then it should call a function to return
# this variable back to caller.
[xml]$BaselineXML = $null
#endregion ModuleVariables

#region BaselineGetSetTestFunctions
# set module level baseline xml variable for policy processing. it should 
# be called before calling any other functions from this module. 
# ------------------------------------------------------------------------
Function Set-WCBXMLVariable([string]$BaselineXMLFile) {
    Write-WCLog -Message "[Set-WCBXMLVariable]"
    try {
        [xml]$script:BaselineXML = Get-Content $BaselineXMLFile -ErrorAction Stop
        Write-WCLog -Level debug -Message "Successfully read baseline xml file into script variable"
    }
    catch {
        Write-WCLog -Level error -Message "Error reading baseline xml file into script variable"
        Write-WCLog -Level error -Message ($_.Exception.Message)
    }
}

# returns contents of module level xml variable. null if it is not set
# --------------------------------------------------------------------
Function Get-WCBXMLVariable {
    return $script:BaselineXML
}

# Test if module level baseline xml variable holds valid xml data
# ----------------------------------------------------------------
Function Test-WCBXMLVariable {
    return ($script:BaselineXML -ne $null)
}
# This function will update environment strings in Default Value field provided a list of policies
Function Update-WCBEnvironmentVariables($Policies) {
	try {
		#Collect all Policy IDs for Processing
		$arrPolicyID = @();
        $Policies | Foreach-Object { $arrPolicyID += $_.ID }
		#Identify the PolicyIDs in BaseLine XML
		$colPolicy = (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy") | Where-Object { $arrPolicyID -contains $_.ID }
		#Identify the Policy that needs environment Variables Updation
		$PolFilter = $colPolicy | where { $_.DefaultValue.Value -like "*%*%*" }
		#Update the Variables
		if($PolFilter -ne $NULL) {
			$PolFilter | Foreach-Object { $_.DefaultValue.Value = [System.Environment]::ExpandEnvironmentVariables($_.DefaultValue.Value) }
		}
	}
	catch { 
		Write-WCLog -Level error -Message "Error updating environmental variables"
        Write-WCLog -Level error -Message ($_.Exception.Message)
	}
}

# This function will test if given WinCompliance Baseline XML contain at least one Local 
# Security policy item. It will help to identify whether LSP need to be processed or not
# --------------------------------------------------------------------------------------
Function Test-WCBaselineIncludesLSP {
param($PolicyList)
    # Identify if there are any policies from any of below LSP categories. AdvancedAuditPol is included as it is
    # collected along with other LSP collection. LSPRegistry is for SecurityOptions policy type
    $lspPolicyTypes = ('SystemAccess','EventAudit','AdvancedAuditPol','PrivilegeRights','LSPRegistry','Kerberos')
    
    # get a list of all LSP policy items,
    $lspPolicies = @($PolicyList | Where-Object { $lspPolicyTypes -contains $_.PolicyType })
    Write-WCLog -Level debug -Message "LSP policies count is $($lspPolicies.Count)"

    # return the boolean value indicating whether baseline XML contains at least one LSP category
    if($lspPolicies.Count -gt 0) { return $true } else { return $false } 
    
}
#endregion BaselineGetSetTestFunctions

#region Get XML Values
#-----------------------------------------------------------------------
#Function to Count the total/Passed/Failed Settings in a category
#-----------------------------------------------------------------------
Function Get-WCBPolicyCountByCategory {
 <#
  .SYNOPSIS
  Get-WCPolicyCountByCategory 
  .DESCRIPTION
  Function to Get WC Policy Result Status Count By Category
  .EXAMPLE
  Get-WCPolicyCountByCategory "AuditPolicy" $BaseLineXML "Total"
  .EXAMPLE
  Get-WCPolicyCountByCategory "AuditPolicy" $BaseLineXML "Failed"
  .PARAMETER CategoryName
  CategoryName from the BaseLine XML
  .PARAMETER TestResultType	
  Specify the Value in TestResult Field against which comparion has to be performed.
  Total - Count the total Number of Tests
  Passed - Count the test result that are Passed
  Failed- Count the test result that are Failed
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$CategoryName,
	[Parameter(Mandatory=$true)]
    [string]$TestResultType #total/passed/failed

)
    $Count = 0;
    $NodeXML = $null;
    
    Write-WCLog -Level debug -Message "[Get-WCBPolicyCountByCategory]";
    Write-WCLog -Level debug -Message ("Calculating number of $TestResultType Policies in Category : $CategoryName");
    
    #Read the required XML Node
    $NodeXML = (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Category") | Where-Object {$_.Name -eq $CategoryName};
    
    try {
        if($NodeXML -ne $null) { 
            if($TestResultType.ToLower() -eq "total") { 
                #Calculate total number of policies
                #Identify the processed nodes of the selected Node
                $Count = @($NodeXML.ChildNodes | Where-Object {$_.Processed -eq "True"}).Count;
            }
            else { 
                #Calculate passed or failed polices
                #If CountType is pass/fail check the test result field in Policy Node also ensure that the node is processed.
                $Count = @($NodeXML.ChildNodes | Where-Object{$_.TestResult -eq $TestResultType -and $_.Processed -eq "True"}).Count ;
            }              
        }
    }
    Catch {
        $Count = $null;
        Write-WCLog -Level Error -Message "[Get-WCBPolicyCountByCategory] : Error in Calculating Count.";
        Write-WCLog -Level Error -Message $_.Exception.Message;
    }
    
    Write-WCLog -Level debug -Message ("Number of $TestResultType Policies in Category $CategoryName : $Count");  
    return $Count #return the count
}
#-----------------------------------------------------------------------
#Function to Count the total/Passed/Failed Settings in a Section
#-----------------------------------------------------------------------
Function Get-WCBPolicyCountBySection{
<#
  .SYNOPSIS
  Get-WCPolicyCountBySection 
  .DESCRIPTION
  Function to Get WC Policy Result Status Count By Section
  .EXAMPLE
  Get-WCPolicyCountBySection "LocalSecurityPolicy" $BaseLineXML "Total"
  .EXAMPLE
  Get-WCPolicyCountBySection "LocalSecurityPolicy" $BaseLineXML "Failed"
  .PARAMETER SectionName
  SectionName from the BaseLine XML
  .PARAMETER TestResultType	
  Specify the Value in TestResult Field against which comparion has to be performed.
  Total - Count the total Number of Tests
  Passed - Count the test result that are Passed
  Failed- Count the test result that are Failed
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$SectionName,
	[Parameter(Mandatory=$true)]
    [string]$TestResultType
)
    $Count = $null;
    
    Write-WCLog -Message "[Get-WCBPolicyCountBySection]";
    Write-WCLog -Level debug -Message ("Calculating number of $TestResultType Policies in Section : $SectionName");
    
    try {  
        #Read the required XML Node
        foreach($sec in (Get-WCBSingleSection -SectionName $SectionName).ChildNodes) { 
            #For each Category in Selected Section Calculate the Number of total/pass/failed test cases
            $Count += Get-WCBPolicyCountByCategory -CategoryName $sec.Name -TestResultType $TestResultType;
		}
    }
    Catch {
        $Count = $null;
        Write-WCLog -Level Error -Message "[Get-WCBPolicyCountBySection] : Error in Calculating Count.";
        Write-WCLog -Level Error -Message $_.Exception.Message
    }
    
    Write-WCLog -Level Info -Message ("Number of $TestResultType Policies in Section $SectionName : $Count");
    return $Count #return the actual count
}
#-----------------------------------------------------------------------
#Function to retrieve all sections in XML
#-----------------------------------------------------------------------
Function Get-WCBSections {
<#
  .SYNOPSIS
  Get-WCSections 
  .DESCRIPTION
  Function to return ALL WC Sections in XML
  Return Value : XMLNode
  .EXAMPLE
  Get-WCSections
  #>
[CmdletBinding()]
Param()
    $NodeXML = $null;
      
    #Read the required XML Node
    $NodeXML = (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Section")
    
    return $NodeXML #return Node
}
#-----------------------------------------------------------------------
#Function to retrieve a particular section in XML
#-----------------------------------------------------------------------
Function Get-WCBSingleSection {
<#
  .SYNOPSIS
  Get-WCSingleSection 
  .DESCRIPTION
  Function to Get Section Node For Processing
  Return Value : XMLNode
  .EXAMPLE
  Get-WCSingleSection "LocalSecurityPolicy" $BaseLineXML
  .PARAMETER SectionName
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$SectionName
)
    $NodeXML = $null;
      
    #Read the required XML Node. Remember that this query (//[@Name=value]) returns XpathNodeList array!
    $NodeXML = (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Section[@Name='$SectionName']")
    
    return $NodeXML #return the matching Node (ideally should be only one)
}
#-----------------------------------------------------------------------
#Function to retrieve a particular Category in XML
#-----------------------------------------------------------------------
Function Get-WCBSingleCategory {
<#
  .SYNOPSIS
  Get-WCSingleCategory 
  .DESCRIPTION
  Function to Get Category Node For Processing
  Return Value : XMLNode
  .EXAMPLE
  Get-WCSingleCategory "PasswordPolicy" $BaseLineXML
  .PARAMETER CategoryName
  CategoryName from the BaseLine XML
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$CategoryName
)
    $NodeXML = $null;

    #Read the required XML Node
    $NodeXML = (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Category[@Name='$CategoryName']")
        
    return $NodeXML;
}
#-----------------------------------------------------------------------
#Function to retrieve a particular Category in XML
#-----------------------------------------------------------------------
Function Get-WCBCategories {
<#
  .SYNOPSIS
  Get-WCCategories 
  .DESCRIPTION
  Function to all Categories in XML
  Return Value : XMLNode
  .EXAMPLE
  Get-WCCategories 
  #>
[CmdletBinding()]
Param(
    [string] $Section
)
    #Read the required XML Node
    if($Section) { # category count has to be taken from given section)
        $NodeXML = (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Category") | Where-Object {(Get-WCXMLNodes -Xml $_ -XPath "..").Name.ToLower() -eq $Section.ToLower() }
    }
    else {
        $NodeXML = (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Category")
    }
        
    return $NodeXML;
}
#-----------------------------------------------------------------------
#Function to retrieve a particular Policy in XML
#-----------------------------------------------------------------------
Function Get-WCBPolicyByID {
<#
  .SYNOPSIS
  Get-WCPolicyByID 
  .DESCRIPTION
  Function to Get Policy Node For Processing
  Return Value : XMLNode
  .EXAMPLE
  Get-WCPolicyByID "PP001" $BaseLineXML
  .PARAMETER PolicyID
  Policy ID from the BaseLine XML
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$PolicyID
)   
    #Read the required XML Node
    $PolicyNode = ((Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy[@Id='$PolicyID']"))
    return $PolicyNode
}

# ------------------------------------------------------------------------------------
# Function to get filtered policy list based on given criteria. Used with WCReportGen
# script to support -PolicyFilter parameter to process filtered policies 
# ------------------------------------------------------------------------------------
Function Get-WCXmlFilterNodes($BaselineXml, [string]$XmlFilter) {
    $fltArray = $XmlFilter.Split(' ') # format is 'PolicyField -op PolicyFieldValue'
    if($fltArray.Length -ne 3) { #invalid filter
        return @() # return blank array
    }
    else {
        switch($fltArray[1]) { # operator
            # some of operators are not working as expected, commented them out till they're verified
            '-eq' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where-object { $_.($fltArray[0]) -eq $fltArray[2]}) }
            '-ne' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where-object { $_.($fltArray[0]) -ne $fltArray[2]}) }
            '-lt' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where-object { $_.($fltArray[0]) -lt $fltArray[2]}) }
            '-gt' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where-object { $_.($fltArray[0]) -gt $fltArray[2]}) }
            '-le' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where-object { $_.($fltArray[0]) -le $fltArray[2]}) }
            '-ge' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where-object { $_.($fltArray[0]) -ge $fltArray[2]}) }
            #'-contains' { return(Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where { $fltArray[0] -contains $_.($fltArray[2])}) }
            #'-notcontains' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where { $fltArray[0] -notcontains $_.($fltArray[2])}) }
            '-like' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where-object { $_.($fltArray[0]) -like $fltArray[2]}) }
            '-notlike' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where-object { $_.($fltArray[0]) -notlike $fltArray[2]}) }
            '-match' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where-object { $_.($fltArray[0]) -match $fltArray[2]}) }
            '-notmatch' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where-object { $_.($fltArray[0]) -notmatch $fltArray[2]}) }
            #'-in' { return (Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where { $_.($fltArray[0]) -in $fltArray[2]}) }
            #'-notin' { return(Get-WCXMLNodes -Xml $BaselineXml -XPath "//Policy" | where { $_.($fltArray[0]) -notin $fltArray[2]}) }
            default { return @() }
        }
        
    }
}
#endregion

#region Compare-Policy
#region Compare Policy Value
#region Compare Functions to separate and process on CurentValue and Default Value based on Enum/Value fields
#------------------------------------------------------------------------------------------
#Function to Compare Default and Current Policy Value and return the boolean result
#-------------------------------------------------------------------------------------------
Function Compare-WCBPolicyByID {
<#
  .SYNOPSIS
  Compare-WCPolicyByID 
  .DESCRIPTION
  Function to Compare the Current and Default Value of the Policy Node and return the Comparison Status
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCPolicyByID "PP001" 
  .PARAMETER PolicyID
  Policy ID from the BaseLine XML
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$PolicyID 
)
	$BoolReturn = $false; #This Variable will be returned by this function
    $PolicyNode = $null;
    
    Write-WCLog -Level debug -Message "[Compare-WCBPolicyByID]";
                        
	#Read the required XML Node
	$PolicyNode = Get-WCBPolicyByID -PolicyID $PolicyID 
    
	if($PolicyNode -ne $null) {
        try {
            Write-WCLog -Level debug -Message "Comparing the Default Value with Current Value for PolicyID: $PolicyID. CompareMethod : $($PolicyNode.CompareMethod)";
			
    		if($PolicyNode.CurrentValue.HasChildNodes) {
                #Current Value has ENUM/ARRAY Field
                $BoolReturn = Compare-WCBEnum -DefaultValue $PolicyNode.DefaultValue -CurrentValue $PolicyNode.CurrentValue -CompareMethod $PolicyNode.CompareMethod      
    	    }
    		else {#Section Current Value is Single Value
                
                if($PolicyNode.DefaultValue.HasChildNodes -and (("-eq","=" -contains $PolicyNode.CompareMethod) -eq $false)) {
					#Default Value is an Array	
					$BoolReturn = Compare-WCBEnumToSingleValue -DefaultValue $PolicyNode.DefaultValue -CurrentValue $PolicyNode.CurrentValue -CompareMethod $PolicyNode.CompareMethod
                }
                else {#Both Current and Default Value has Single Value
                     $BoolReturn = Compare-WCBSingleValue -DefaultValue $PolicyNode.DefaultValue -CurrentValue $PolicyNode.CurrentValue -CompareMethod $PolicyNode.CompareMethod -DataType $PolicyNode.DataType
                }
            }
        }
        Catch {
            Write-WCLog -Level Error -Message "[Compare-WCPolicyByID] : Error while Comparing the Default and Current Value.";
            Write-WCLog -Level Error -Message $_.Exception.Message
        }
	}
	else {
		 Write-WCLog -Level Error -Message "PolicyID $PolicyID Doesn't Exist.";
	}
    
    Write-WCLog -Level debug -Message ("[Compare-WCBPolicyByID] Comparison Status : $BoolReturn");
	return $BoolReturn;
}
#----------------------------------------------------------------------------
#Function to Validate the ARRAY/ENUM Current Value to ARRAY/VALUEENUMERATION Default Value
#----------------------------------------------------------------------------
Function Compare-WCBEnum {
<#
  .SYNOPSIS
  Compare-WCBEnum 
  .DESCRIPTION
  Function to Compare the Current and Default Value of the Policy Node and return the Comparison Status
  Current Value and Default Value are Both Arrays/(Enum Field in Baseline)
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCBaseLineEnum $DefaultValue $CurrentValue "-eq"
  .PARAMETER DefaultValue
  DefaultValue of the Policy : DataType Array
  .PARAMETER CurrentValue
  CurrentValue of the Policy : DataType Array
  .PARAMETER CompareMethod
  Comparision Method to be used to compare the array
  -eq,-like,-match,-contains
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    $DefaultValue,
	[Parameter(Mandatory=$true)]
    $CurrentValue,
	[Parameter(Mandatory=$true)]
	$CompareMethod
    )
	Write-WCLog -Level debug -Message "[Compare-WCBEnum]";
	Write-WCLog -Level debug -Message ("Current Value : " + (@($CurrentValue.ValueEnumeration) -join " | "));
	Write-WCLog -Level debug -Message ("Default Value : " + (@($DefaultValue.ValueEnumeration) -join " | "));
	
    $BoolReturn = $false;
	
    try {
		if(Test-WCBPolicyValues $DefaultValue $CurrentValue) { #Validate Current Value and Default Value
			#Calling Function to Compare the Array
			$BoolReturn = Compare-WCEnumToArray -LeftValue @($DefaultValue.ValueEnumeration) -RightValue @($CurrentValue.ValueEnumeration) -CompareMethod $CompareMethod;
			Write-WCLog -Level debug -Message "[Compare-WCEnumToArray] Status = $BoolReturn";
		}
	}
	Catch {
        Write-WCLog -Level Error -Message "[Compare-WCBaseLineEnum] Error Comparing Default and Current Value";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        $BoolReturn = $false;
    }
	
	Write-WCLog -Level debug -Message "[Compare-WCBaseLineEnum] Comparison Status $BoolReturn";
	return $BoolReturn
}

#----------------------------------------------------------------------------
#Function to Validate the ARRAY/ENUM Current Value to ARRAY/VALUEENUMERATION Default Value
#----------------------------------------------------------------------------
Function Compare-WCBEnumToSingleValue {
<#
  .SYNOPSIS
  Compare-WCBaseLineEnumToSingleValue 
  .DESCRIPTION
  Function to Compare the Current and Default Value of the Policy Node and return the Comparison Status
  Current Value of the Policy is a single field
  Default Value is an Arrays/(Enum Field in Baseline)
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCBaseLineEnumToSingleValue $DefaultValue $CurrentValue "-like"
  .PARAMETER DefaultValue
  DefaultValue of the Policy : DataType Array
  .PARAMETER CurrentValue
  CurrentValue of the Policy : String
  .PARAMETER CompareMethod
  Comparision Method to be used to compare
  -like,-match,-contains
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    $DefaultValue,
	[Parameter(Mandatory=$true)]
    $CurrentValue,
	[Parameter(Mandatory=$true)]
	$CompareMethod
    )
	Write-WCLog -Level debug -Message "[Compare-WCBEnumToSingleValue]";
	Write-WCLog -Level debug -Message ("Current Value : " + $CurrentValue.Value);
	Write-WCLog -Level debug -Message ("Default Value : " + (@($DefaultValue.ValueEnumeration) -join " | "));
	
    $BoolReturn = $false;

    try {
		if(Test-WCBPolicyValues $DefaultValue $CurrentValue) { #Validate Current and Default Value
			#Calling Function to Compare the Array
			$BoolReturn = Compare-WCEnumToArray -LeftValue @($DefaultValue.ValueEnumeration) -RightValue @($CurrentValue.Value) -CompareMethod $CompareMethod
			Write-WCLog -Level debug -Message "[Compare-WCEnumToArray] : Comparison Status = $BoolReturn";
		}                 
	}
	Catch {
        Write-WCLog -Level Error -Message "[Compare-WCBEnumToSingleValue] : Error Comparing Default and Current Value";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        $BoolReturn = $false;
    }
	Write-WCLog -Level debug -Message "[Compare-WCBEnumToSingleValue] : Comparison Status = $BoolReturn";
	return $BoolReturn
}
#----------------------------------------------------------------------------
#Function to Validate the Current Value to Default Value
#----------------------------------------------------------------------------
Function Compare-WCBSingleValue {
<#
  .SYNOPSIS
  Compare-WCBaseLineSingleValue 
  .DESCRIPTION
  Function to Compare the Current and Default Value of the Policy Node and return the Comparison Status
  Current Value of the Policy is a single field
  Default Value of the Policy is also a single field
  Return Value : Bool True/False
  .EXAMPLE
  Compare-WCBaseLineSingleValue $DefaultValue $CurrentValue "-like"
  .PARAMETER DefaultValue
  DefaultValue of the Policy : DataType String/Integer/Version
  .PARAMETER CurrentValue
  CurrentValue of the Policy : DataType String/Integer/Version
  .PARAMETER CompareMethod
  Comparision Method to be used to compare
  -like,-match,-contains,-eq,-ne,-lt,-le,-gt,-ge
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    $DefaultValue,
	[Parameter(Mandatory=$true)]
    $CurrentValue,
	[Parameter(Mandatory=$true)]
	$CompareMethod,
	[Parameter(Mandatory=$true)]
	$DataType
    )
	Write-WCLog -Level debug -Message "[Compare-WCBSingleValue]";
	Write-WCLog -Level debug -Message ("Current Value : " + $CurrentValue.Value);
	Write-WCLog -Level debug -Message ("Default Value : " + $DefaultValue.Value);
    $BoolReturn = $false;

    try {
		if(Test-WCBPolicyValues -DefaultValue $DefaultValue -CurrentValue $CurrentValue) { #Validate Current value and Default Value
			#If Both current Value and Default Value is null then mark test as Passed
			If($DefaultValue.Value -eq "" -and  $CurrentValue.Value -eq "") { 
				Write-WCLog -Level debug -Message "Both Default Value and Current Value is null.";
				$BoolReturn = $true; 
			}
			Else
			{
				#Data to be processed is a String/Number
				
				#IF Compare Method is gt,ge,lt,le comparision then change the data Type to Integer
				if(("-gt",">","-ge",">=","-le","<=","-lt","<") -contains $CompareMethod.Trim()) { $DataType = "number" }
				
				switch($DataType.ToLower()) {
					('string') {
						$BoolReturn = Compare-WCString -LeftValue $DefaultValue.Value -RightValue $CurrentValue.Value -CompareMethod $CompareMethod.Trim();
						Write-WCLog -Level debug -Message "[Compare-WCString] : Comparison Status = $BoolReturn";
					}
					('number') {
						$BoolReturn = Compare-WCInteger -LeftValue $DefaultValue.Value -RightValue $CurrentValue.Value -CompareMethod $CompareMethod.Trim();
						Write-WCLog -Level debug -Message "[Compare-WCInteger] : Comparison Status =$BoolReturn";
					}
					default {
						#Default setting is to compare String
						$BoolReturn = Compare-WCString -LeftValue $DefaultValue.Value -RightValue $CurrentValue.Value -CompareMethod $CompareMethod.Trim();
						Write-WCLog -Level debug -Message "[Compare-WCString] : Comparison Status = $BoolReturn";
					}
				}
			}
		}
	}
	Catch {
        Write-WCLog -Level Error -Message "[Compare-WCBSingleValue] : Error Comparing Default and Current Value";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        $BoolReturn = $false;
    }
	Write-WCLog -Level debug -Message "[Compare-WCBSingleValue] : Comparison Status : $BoolReturn";
	return $BoolReturn
}
#endregion
#-----------------------------------------------------------------------
#Function to Validate the default and current Value before Comparison
#-----------------------------------------------------------------------
Function Test-WCBPolicyValues{
<#
  .SYNOPSIS
  Test-WCPolicyValues
  .DESCRIPTION
  Function to validate the Current and Default Value of the Policy Before actually performing the Comparison
  Return Value : Bool True / False
  .EXAMPLE
  Test-WCPolicyValues $DefaultValue $CurrentValue 
  .PARAMETER DefaultValue
  DefaultValue of the Policy : DataType:String,Integer,Array
  .PARAMETER CurrentValue
  CurrentValue of the Policy : DataType:String,Integer,Array
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    $DefaultValue,
	[Parameter(Mandatory=$true)]
    $CurrentValue
    )  
    Write-WCLog -Level debug -Message "[Test-WCBPolicyValues]";
    
    try {
        #If one of the value is NULL that means node doesn't exists return false
        if($DefaultValue -eq $null -or $CurrentValue -eq $null) {
            Write-WCLog -Level Error -Message "[Test-WCBPolicyValues] : Validation Failed : Default Value or Current Value is NULL";
            return $false;
        }
        
        if($CurrentValue.HasChildNodes) { #Current Value has ENUM/ARRAY field       
            if($DefaultValue.HasChildNodes) { #Default Value has ARRAY/VALUEENUMERATION   field    
                if(@($DefaultValue.ValueEnumeration).Count -eq $null) { #Default Value ENUM/ARRAY Count is NULL then return False
					Write-WCLog -Level debug -Message "[Test-WCBPolicyValues] : Validation Failed : Default Value doesn't have ValueEnumeration";
					return $false; 
				} 
                elseif(@($CurrentValue.ValueEnumeration).Count -gt 0 -and @($DefaultValue.ValueEnumeration).Count -lt 1) { #Current Value has ENUM/ARRAY field and default value ValueEnumeration field is empty
					Write-WCLog -Level debug -Message "[Test-WCBPolicyValues] : Validation Failed : Default Value doesn't have ValueEnumeration";
					return $false;
				}
            }
            else { #The Default Value doesn't have VALUEENUMERATION
				Write-WCLog -Level debug -Message "[Test-WCBPolicyValues] : Validation Failed : Default Value doesn't have ValueEnumeration";
				return $false; }              
        }
        elseif($DefaultValue.HasChildNodes) { #Current Value is Single Value and Default value has VALUEENUMERATION field            
            if($CurrentValue.Value -eq "") { #If Current Value is Empty then return false
				Write-WCLog -Level debug -Message "[Test-WCBPolicyValues] : Validation Failed : Current Value is Empty";
				return $false; 
			}           
        }
        else {
            #Section to Process single value for Default Value and Current Value
            #If Current Value is "" and Default Value is not "" then return false
            #this is to ensure that -contains and -not contains doesn't get executed when current value is Empty and the Default value has some data
            if($CurrentValue -eq "" -and $DefaultValue -ne "") { 
				Write-WCLog -Level debug -Message "[Test-WCBPolicyValues] : Validation Failed : Current Value is Empty";
				return $false; 
			}
        }
    }
    Catch {
        Write-WCLog -Level Error -Message "[Test-WCBPolicyValues] : Error Validating Default and Current Value";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
    
    return $true;
}
#endregion

#endregion

#region Set XML Values
# function to set passed/failed count for given section or category
# -----------------------------------------------------------------
Function Set-WCBPolicyCounts {
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)] [ValidateSet("Section","Category")] $NodeType,
    [Parameter(Mandatory=$true)] $NodeName
)
    # based on given node type, set passed and failed policy counts respectively
     Write-WCLog -Level debug -Message "[Set-WCBPolicyCounts] setting $NodeType '$NodeName' counts"
    switch($NodeType) {
        'Section' {
            $p = Get-WCBPolicyCountBySection -SectionName $NodeName -TestResultType 'passed'
            $f = Get-WCBPolicyCountBySection -SectionName $NodeName -TestResultType 'failed'
            $t = Get-WCBPolicyCountBySection -SectionName $NodeName -TestResultType 'total'#includes unprocessed as well!
            $cats = @(Get-WCBCategories -Section $NodeName).count
            $section = Get-WCBSingleSection -SectionName $NodeName
            if($section) {
                $section.SetAttribute('Passed',$p.toString())
                $section.SetAttribute('Failed',$f.toString())
                $section.SetAttribute('PolicyCount',$t.toString())
                $section.SetAttribute('CategoryCount',$cats.toString())
            }
            else {
                 Write-WCLog -Level Error -Message "Unable to set policy counts for $NodeType $NodeName"
            }
        }
        'Category' {
            $p = Get-WCBPolicyCountByCategory -CategoryName $NodeName -TestResultType 'passed'
            $f = Get-WCBPolicyCountByCategory -CategoryName $NodeName -TestResultType 'failed'
            $t = Get-WCBPolicyCountByCategory -CategoryName $NodeName -TestResultType 'total'
            $category = Get-WCBSingleCategory -CategoryName $NodeName
            if($category) {
                $category.SetAttribute('Passed',$p.toString())
                $category.SetAttribute('Failed',$f.toString())
                $category.SetAttribute('PolicyCount',$t.toString())
            }
            else {
                 Write-WCLog -Level Error -Message "Unable to set policy counts for $NodeType $NodeName"
            }
        }
    }
}
#-----------------------------------------------------------------------
#Function to Set the Current Value Field in the Policy
#-----------------------------------------------------------------------
Function Set-WCBPolicyCurrentValue {
<#
  .SYNOPSIS
  Set-WCPolicyCurrentValue
  .DESCRIPTION
  Function to Set the CurrentValue Field of a policy in Baselinexml
  Return Value :
  BaseLine XML - If the Status is Success
  NULL- Incase of any Errors
  .EXAMPLE
  Set-WCPolicyCurrentValue "PP001" $BaseLineXML $CurrentValue 
  .PARAMETER PolicyID
  PolicyID that has to be set
  .PARAMETER CurrentValue
  CurrentValue is the value to be set in xml : DataType Array,String
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
    [string]$PolicyID,
	[Parameter(Mandatory=$true)]
    $CurrentValue
)
    #If the Return Value is NULL then an Error has Occurred
    #Else its Updated BaseLine XML
    
	Write-WCLog -Level debug -Message "[Set-WCBPolicyCurrentValue]";
	try {
		if($CurrentValue -ne $null) {
			#Get the Policy Node
			$PolicyNode = $null;
			$PolicyNode = (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy[@Id='$PolicyID']")
            
			Write-WCLog -Level debug -Message "[Set-WCBPolicyAttributes] : Setting CurrentValue for Policy ID [$($PolicyNode.Id)]";
			
            #Replace Invalid XML Characters
            $CurrentValue = Update-WCBInvalidXMLChars -Value $CurrentValue;
            
			if($PolicyNode -ne $null) { #If Policy Node is Valid
                #Remove All Existing Child Nodes
                if($PolicyNode.CurrentValue.HasChildNodes) {
                    $PolicyNode.CurrentValue.InnerXML = ""; 
                } 
                else {
                    $PolicyNode.CurrentValue.Value = "";
                }
                
				#If Current Value is an ARRAY/ENUM
				if($CurrentValue.GetType().BaseType.Name.ToLower() -eq "array") {
                    Write-WCLog -Level debug -Message ("[Set-WCBPolicyAttributes] : Current Value:" + ($CurrentValue -join " | "));
					#Set the ENUM/ARRAY Values
					foreach($Setting in $CurrentValue) {						
						#Create the Enum Node and Update each Value from the Array
						$xmlValueNode = $script:BaselineXML.CreateElement("ValueEnumeration");
						$xmlValueNode.InnerText = $Setting.ToString().Trim();
					
						#Update the Enum to CurrentValue Element of the Policy Node
						$PolicyNode.CurrentValue.AppendChild($xmlValueNode) | Out-Null; 						
					}
				}
				else { #Current Value is a Single value
					#Update the Value in CurrentValue in Value Attribute Field
					Write-WCLog -Level debug -Message "[Set-WCBPolicyAttributes] : Current Value:$CurrentValue";
					$PolicyNode.CurrentValue.SetAttribute("Value",$CurrentValue.ToString().Trim());
				}
			}
			else {
				Write-WCLog -Level Error -Message "Policy ID $PolicyID doesn't Exists.";
				#$BaseLineXML = $null;
			}
		}
		else {
			Write-WCLog -Level Error -Message "Current Value field is NULL.";
			#$BaseLineXML = $null;
		}
	}
	Catch {
		Write-WCLog -Level Error -Message "[Set-WCBPolicyCurrentValue] : Error Updating Current Value for PolicyID : $PolicyID";
        Write-WCLog -Level Error -Message $_.Exception.Message;
		#$BaseLineXML = $null;
	}
	#Return Updated BaselineXML
	#return $script:BaselineXML;
}
#-----------------------------------------------------------------------
#Function to Set attributes in a Policy
#-----------------------------------------------------------------------
Function Set-WCBPolicyAttributes {
<#
  .SYNOPSIS
  Set-WCPolicyAttributes
  .DESCRIPTION
  Function to Set the attributes and other Fields(fields except CurrentValue) of a policy in Baselinexml
  Return Value :
  BaseLine XML - If the Status is Success
  NULL- Incase of any Errors
  .EXAMPLE
  Set-WCPolicyAttributes "PP001" $BaseLineXML $Value 
  .PARAMETER PolicyID
  PolicyID that has to be set
  .PARAMETER Value
  Attribute or Field Value that has to be set. DataType String
  #>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)] [string]$PolicyID,
	[Parameter(Mandatory=$true)] $AttributeName,
	[Parameter(Mandatory=$true)] $Value,
	[Parameter(Mandatory=$true)] [ValidateSet("Attribute","Value")] $AttribType
)
    #If the Return Value is NULL then an Error has Occurred
    #Else its Updated BaseLine XML
    
	Write-WCLog -Level debug -Message "[Set-WCBPolicyAttributes]";
    
	try {
		if($Value -ne $null) {
			#Get the Policy Node
			$PolicyNode = $null;
			$PolicyNode = (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy[@Id='$PolicyID']")
			Write-WCLog -Level debug -Message "[Set-WCBPolicyAttributes] : Setting Value for Policy ID $PolicyID ID";
			Write-WCLog -Level debug -Message "[Set-WCBPolicyAttributes] : $AttributeName : $Value";
			
            #Replace Invalid XML Characters
            $Value = Update-WCBInvalidXMLChars -Value $Value;
            
			if($PolicyNode -ne $null) { #If Policy Node is Valid
				if($AttribType.ToLower().Trim() -eq "attribute") { #Set Attribute field
					$PolicyNode.SetAttribute($AttributeName,$Value.ToString());
				}
				else { #Set the Node Field
					$PolicyNode.$AttributeName = $Value.ToString();
				}
			}
			else {
				Write-WCLog -Level Error -Message "Policy ID $PolicyID doesn't Exist.";
				#$BaseLineXML = $null;
			}
		}
		else {
			Write-WCLog -Level Error -Message "Value field is NULL.";
			#$BaseLineXML = $null;
		}
	}
	Catch {
		Write-WCLog -Level Error -Message "[Set-WCBPolicyAttributes] : Error Updating Attribute/Value for PolicyID : $PolicyID";
        Write-WCLog -Level Error -Message $_.Exception.Message;
		#$BaseLineXML = $null;
	}
	#Return Updated BaselineXML
	#return $script:BaselineXML;
}

#-----------------------------------------------------------------------
#Function to Replace invalid XML Characters in a Policy
#-----------------------------------------------------------------------
Function Update-WCBInvalidXMLChars {
<#
  .SYNOPSIS
  Update-WCBInvalidXMLChars
  .DESCRIPTION
  Function to replace Invalid XML characters
  Return Value : Updated String
  .EXAMPLE
  Update-WCBInvalidXMLChars $Value 
  .PARAMETER Value
  Value to be processed. 
  #>
[cmdletBinding()]
Param (
	[Parameter(Mandatory=$true)] $Value,
	[switch]$XMLElement
)
    if($Value -eq $null) { return "";}
    
    $retValue = $Value;
    $InvalidXMLCharacters = @(("&","&amp;"),("<","&lt;"),(">","&gt;"),([string]([char]34),"&quot;"),("'","&apos;"));
    if($XmlElement.IsPresent) {
		$InvalidXMLCharacters += ("(",""),(")","");
		
	}
    Write-WCLog -Level debug -Message "[Update-WCBInvalidXMLChars]";
    
    try {
        #Check whether the Value is an Array
        if($retValue.GetType().BaseType.Name.ToLower() -eq "array") {
			Write-WCLog -Level debug -Message ("[Update-WCBInvalidXMLChars] : " + ($retValue -join " | "));
            #Check for Each Invalid Character and replace it in the array
            $InvalidXMLCharacters | ForEach-Object {
                For([int] $i=0;$i -lt $retValue.Count ;$i++) {
                    if($retValue[$i].ToString().Contains($_[0])) {
						Write-WCLog -Level debug -Message "[Update-WCBInvalidXMLChars] : Replaced the Character $_[0]"
                        $retValue[$i] = $retValue[$i].ToString().Replace($_[0],$_[1]);
                    }
                }
            }
        }
        else { #Value is not an Array
             #Check for Each Invalid Character and replace it
			 Write-WCLog -Level debug -Message "[Update-WCBInvalidXMLChars] : $retValue"
             $InvalidXMLCharacters | ForEach-Object {
                if($retValue.ToString().Contains($_[0])) {
					Write-WCLog -Level debug -Message "[Update-WCBInvalidXMLChars] : Replaced the Character $_[0]"
                    $retValue = $retValue.ToString().Replace($_[0],$_[1]);
                }
             }
        }
    }
    Catch {
		Write-WCLog -Level Error -Message "Error Repairing Value.";
        Write-WCLog -Level Error -Message $_.Exception.Message;
		$retValue = $null;
	}
	#Return Updated retValue
	return $retValue;
}

#endregion


#region SetPolicyCurrentValue
# This function will verify if WC policy item's platform is matching with current platform
# ----------------------------------------------------------------------------------------
Function Test-WCPolicyAllowedOnPlatform([string]$PolicyPlatform) {
    $hwVendor = Get-HardwareVendorName # get name of hardware/virtual vendor
    if($PolicyPlatform -ne 'all' -and ($hwvendor -notin @($PolicyPlatform -split ","))) {
        return $false
    }
    else { return $true } # platform matches, either it is 'all' or matching vendor
}

# This function will return registry in (key, value) format from a give registry policy key
Function Split-WCRegistryPolicyKey([string]$PolicyKey) {
    $regValue = $PolicyKey.split('\')[-1] # last string after last \ is valuename
    $regKey =  $PolicyKey.Substring(0,$PolicyKey.LastIndexOf('\')) # get key part, excluding valueName
    $regKey = $regKey.Replace('HKEY_LOCAL_MACHINE','HKLM:') #replace full key name with short name
    $regKey = $regKey.Replace('HKEY_CURRENT_USER','HKCU:') #replace full key name with short name

    # return key,value pair (array)
    return ($regKey,$regValue)
}

# This function will get a policy item, process it and call different functions to set its current value
# ------------------------------------------------------------------------------------------------------
Function Start-WCPolicyProcessing([System.Xml.XmlElement]$PolicyNode) {
    # todo: baselinexml can't be passed to it.. or it has to return baseline xml back
    # need a way around it otherwise we'll end up making lot of references to it here and there
    # identify it is is vendor specific test and wether current vendor matches it

    # hold values for tests that are passed or failed
    $testResultValues = ('Passed','Failed')
    $postProcessing = $true # indicate that after getting policy value, perform all other policy processing outwide switch
    
    if(Test-WCPolicyAllowedOnPlatform -PolicyPlatform $PolicyNode.Platform) {
        if($PolicyNode.Processed -eq $false) { # policy is not yet processed, process it
            Write-WCLog -Level info -Message "Processing policy $($PolicyNode.Id)"
            switch($PolicyNode.PolicyType) {
                "SystemAccess" { 
                    # get policy value for given policy name
                    $policyValue = Get-WCLSPSystemAccessPolicy -PolicyName $PolicyNode.PolicyKey
                }   
                "EventAudit" { 
                    # get policy value for given policy name
                    $policyValue = Get-WCLSPEventAuditPolicy -PolicyName $PolicyNode.PolicyKey
                } 
				"Kerberos" { 
                    # get policy value for given policy name
                    $policyValue = Get-WCLSPKerberosPolicy -PolicyName $PolicyNode.PolicyKey
                } 
                "AdvancedAuditPol" { 
                    # get policy value for given policy name
                    $policyValue = Get-WCLSPAdvAuditPolSubCategoryValue -SubcategoryName $PolicyNode.PolicyKey
                }
                 "PrivilegeRights" { 
                    # get policy value for given privilegeRights policy name, converting sid to value
                    $policyValue = Get-WCLSPPrivilegeRightsPolicy -PolicyName $PolicyNode.PolicyKey -ConvertSidToName
                }
                "LSPRegistry" { # Local Security Policy 'Security Options' policy category
                    $policyValue = Get-WCLSPRegistryValuesPolicyByFullName -PolicyName $PolicyNode.PolicyKey
                    # if policyValue is blank then make it 'NotDefined'
                    if($policyValue -eq '') { $policyValue = 'NotDefined' } # policy exists but it is blank
                    if($policyValue -eq $null) { $policyValue = 'NotExists' } # policy does not exist in LSP XML file
                    # this happens when a policy value is not set in LSP (you see it is blank in LSP MMC). when you 
                    # export using secedit, those blank policies do not appear in export!
                }
				"LGPRegistry" { 
                    # get policy value for given registry policy name, after getting its key/value pair
                    $regKeyValuePair = Split-WCRegistryPolicyKey -PolicyKey $PolicyNode.PolicyKey
                    Write-WCLog -Level debug -Message ("Registry policy key split: {0},{1}" -f $regKeyValuePair)
                    
                    # if given registry key/value doesn't exist, it will return 'NotExists'.
                    # if given registry key value is blank or null, it will return 'NotDefined' if -returnBlankAsNotDefined is specified
                    $policyValue = Get-WCRegistryValue -KeyPath $regKeyValuePair[0] -ValueName $regKeyValuePair[1] -ReturnBlankAsNotDefined
                }
                "Registry" { 
                    # get policy value for given registry policy name, after getting its key/value pair
                    $regKeyValuePair = Split-WCRegistryPolicyKey -PolicyKey $PolicyNode.PolicyKey
                    Write-WCLog -Level debug -Message ("Registry policy key split: {0},{1}" -f $regKeyValuePair)
                    
                    # if given registry key/value doesn't exist, it will return 'NotExists'.
                    # if given registry key value is blank or null, it will return 'NotDefined' if -returnBlankAsNotDefined is specified
                    $policyValue = Get-WCRegistryValue -KeyPath $regKeyValuePair[0] -ValueName $regKeyValuePair[1] -ReturnBlankAsNotDefined
                }
                "Service.StartupType" {
                    # get service startup type
                    $policyValue = Get-WCServiceStartMode -ServiceName $PolicyNode.PolicyKey
                }

                "Service.Status" {
                    # get service startup type
                    $policyValue = Get-WCServiceStatus -ServiceName $PolicyNode.PolicyKey
                }
				
				"PSCommand" {
					$policyValue = Get-WCPSValue -PSCommand $PolicyNode.PolicyKey 
				}
				"PSModule" {
					#In some cases default value has to be passed to the script for processing
					
					#Launch the ps command
					$policyValue = Invoke-Expression $PolicyNode.PolicyKey
				}
                # switch cases for filesystem tests, file/folder checks are for existence only
                "FileSystem.File" { $policyValue = Test-WCFileExists -FileName $PolicyNode.PolicyKey }
                "FileSystem.Folder" { $policyValue = Test-WCFolderExists -FolderName $PolicyNode.PolicyKey }
                "FileSystem.Version" { $policyValue = Get-WCFileVersion -FilePath $PolicyNode.PolicyKey }
                "FileSystem.Permission" { $policyValue = Get-WCACLValue -Path $PolicyNode.PolicyKey }

                default {
                    # this is unknown policyType 
                    Write-WCLog -Level warning -Message "unknown policy type $($PolicyNode.PolicyType)"
                    $postProcessing = $false # indiate that post processing has not to be done
                }
            }

            # perform post-processing if one of the switch conditions have processed current policy
            if($postProcessing -eq $true) {
                # set current value of policy node with value identified
                if($policyValue -ne $null) { # given policy has no current value
                    Set-WCBPolicyCurrentValue -PolicyID $PolicyNode.Id -CurrentValue $policyValue
                }
                else { Write-WCLog -Level warning -Message "Policy $($policyNode.Id) PolicyKey either not exists or it is null" }

                # based on comparison of current/default values, set the result
                $cresult = Compare-WCBPolicyByID -PolicyID $PolicyNode.Id
                    
                # set test result as passed or failed.. $testResultValues[0] is passed, [1] is failed
                if($cresult -eq $true) { $cresult = $testResultValues[0] } else { $cresult = $testResultValues[1] }
                Write-WCLog -Level debug -Message "setting policy result as $cresult"
                Set-WCBPolicyAttributes -PolicyID $PolicyNode.Id -AttributeName 'TestResult' -Value $cresult -AttribType Value

                # set Processed to True for this policy item
                Set-WCBPolicyAttributes -PolicyID $PolicyNode.Id -AttributeName 'Processed' -Value 'true' -AttribType Attribute
            }
        }
        else {
             Write-WCLog -Level debug -Message "Policy $($PolicyNode.Id) is already processed"
        }
    }
    else {
        Write-WCLog -Level debug -Message "Policy $($PolicyNode.Id) requires $($PolicyNode.Platform) platform, skipping"
    }

    # policy processing done
}


#endregion SetPolicyCurrentValue

#region UpdateReportSummary
# This function will update report summary
# -----------------------------------------
Function Update-WCBReportSummary([string] $BaselineFile, [string]$ReportName, [string]$HashConfigFile) {
    # remember that xml is case-sensitive so, xpath should include proper case!
    $osinfo = Get-CimInstance -ClassName Win32_OperatingSystem | select Caption, Version
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='ReportName']").Value = $ReportName 
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='ReportGenerationDateTime']").Value = (get-date).ToString()
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='ReportGeneratedOnServer']").Value = $env:COMPUTERNAME
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='OperatingSystem']").Value = ("{0} {1}" -f $osinfo.Caption, $osinfo.Version)
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='WCVersion']").Value = "3.0.1" # get a mechanism to get/set it centrally
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='BaselineUsed']").Value = (resolve-path $BaselineFile).path 
     
    #count policies
    $totalpolCount = (@((Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy") | Where-Object { $_.Processed -eq 'true'} ).count)
    $polCount = (@((Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy") | Where-Object { $_.Processed -eq 'true' -and $_.Purpose -eq 'Compliance'} ).count)
    $polInfoCount = (@((Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy") | Where-Object { $_.Processed -eq 'true' -and $_.Purpose -eq 'Info'} ).count)
    $totalpolPassed = (@((Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy") | Where-Object { $_.Processed -eq 'true' -and $_.TestResult -eq 'passed' } ).count)
    $totalpolFailed = (@((Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy") | Where-Object { $_.Processed -eq 'true' -and $_.TestResult -eq 'failed'} ).count)
    $polPassed = (@((Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy") | Where-Object { $_.Processed -eq 'true' -and $_.TestResult -eq 'passed' -and $_.Purpose -eq 'Compliance'} ).count)
    $polFailed = (@((Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy") | Where-Object { $_.Processed -eq 'true' -and $_.TestResult -eq 'failed' -and $_.Purpose -eq 'compliance'} ).count)
    $polInfoPassed = (@((Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy") | Where-Object { $_.Processed -eq 'true' -and $_.TestResult -eq 'passed' -and $_.Purpose -eq 'Info'} ).count)
    $polInfoFailed = (@((Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy") | Where-Object { $_.Processed -eq 'true' -and $_.TestResult -eq 'failed' -and $_.Purpose -eq 'Info'} ).count)
	
    #update xml value with policy count
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='PolicyProcessed']").Value = $totalpolCount.ToString()
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='CompliancePolicyProcessed']").Value = $polCount.ToString()
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='InfoPolicyProcessed']").Value = $polInfoCount.ToString()

    #update xml values with passed/failed status
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='PolicyPassed']").Value = $totalpolPassed.ToString()
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='PolicyFailed']").Value = $totalpolFailed.ToString()
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='CompliancePolicyPassed']").Value = $polPassed.ToString()
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='CompliancePolicyFailed']").Value = $polFailed.ToString()
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='InfoPolicyPassed']").Value = $polInfoPassed.ToString()
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='InfoPolicyFailed']").Value = $polInfoFailed.ToString()

    #compliance % - use Floor() to discard digits after decmal point
    $cp = [math]::Floor((([int]($polPassed)*100)/([int]$polCount))).ToString()
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='CompliancePercent']").Value = "$cp`%"
    
    # check whether custom apps were installed or not
    # 03-sep-15: If given value does not exist then return will be 'NotExists'. IF value is blank then
    # return will be 'NotDefined'
    #$ca = Get-WCRegistryValue -KeyPath 'HKLM:\Software\CSC\SOE' -ValueName 'CustomApps' -ReturnBlankAsNotDefined
    #if($ca -eq 'NotDefined' -or $ca -eq 'NotExists' -or $ca -eq 'None') { $ca = "False" } else { $ca = "True" }
    # updated to use a function to check custom apps install status based on apps installer entries
    $ca = test-SOECustomAppsInstallation 
    if($ca.length -eq 0) { $ca = "False" } else { $ca = "True" } # whether custom apps are found. 0 means not found
    (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='CustomAppsInstalled']").Value = $ca
    
    # Check if SOE default baseline was used to perform test or not
    $soeKey = $script:BaselineXML.WinCompliance.Baseline.SOEInfo.KeyName
    $valueName = $script:BaselineXML.WinCompliance.Baseline.SOEInfo.ValueName
    $expVer = $script:BaselineXML.WinCompliance.Baseline.SOEInfo.ExpectedValue
    $soeName = $script:BaselineXML.WinCompliance.Baseline.SOEInfo.Name
    $sver = Get-WCRegistryValue -KeyPath $soeKey -ValueName $valueName -ReturnBlankAsNotDefined
    if($sver -eq 'NotDefined') { 
        (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='ServerSOEVersion']").Value = "Not built using SOE $expVer" 
        (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='CompatibleBaseline']").Value = 'False' 
    }
    else {
        (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='ServerSOEVersion']").Value = $sver
        if($sver -eq $expVer) { # baseline of same SOE version used for testing that is installed on this server
            (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='CompatibleBaseline']").Value = 'True'
        }
        else { (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='CompatibleBaseline']").Value = 'False' }
    }
    # whether SOE provided baseline was used for testing
    $isDefBsl = Test-WCBaselineIntegrity -Baseline $BaselineFile -HashConfigFile $HashConfigFile
    if($isDefBsl) { (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='DefaultBaselineUsed']").Value = 'True' }
    else { (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//RSItem[@Name='DefaultBaselineUsed']").Value = 'False' } 
}
#endregion UpdateReportSummary


#region BaseLine Validation
Function Test-WCBaseLineXML {
<#
  .SYNOPSIS
  Test-WCBaseLineXML
  .DESCRIPTION
  Function to Validate BaseLine XML
  .EXAMPLE
  Test-WCBaseLineXML
  #>
[CmdletBinding()]
Param()
    Write-WCLog -Level debug -Message "[Test-WCBaselLineXML]";
    try {
        #Validate Category
        if((Test-WCBValidateCategory) -eq $false) {return $false;}
        #Validate Policy Item
        if((Test-WCBValidatePolicyItem) -eq $false) {return $false;}
    }
    catch {
        Write-WCLog -Level Error -Message "[Test-WCBaselLineXML] : Error Validating BaseLine XML";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
    return $True;
}

Function Test-WCBValidateCategory {
<#
  .SYNOPSIS
  Test-WCBValidateCategory
  .DESCRIPTION
  Function to Validate Category Sections in XML
  .EXAMPLE
  Test-WCBValidateCategory
  #>
[CmdletBinding()]
Param()
    Write-WCLog -Level debug -Message "[Test-WCBValidateCategory]";
    
    try {
        #Validate Category       
        $ValidateCategories = (Get-WCBCategories);
		#XML will append the Node Name as Category if not Specified
        if((@($ValidateCategories) | where-object { ($_.Name -eq "") -or ($_.Name -eq "Category") }) -ne $NULL) { 
            Write-WCLog -Level Error -Message "[Test-WCBValidateCategory] : Category Names are not specified for some of the Nodes in XML";
            return $false; 
        }
        
        #Validate Duplicate Category Names
        $CompareResult = ([string[]]($ValidateCategories | Select-Object Name) | Group-Object | Where-Object {$_.Count -gt 1}) |Select-Object Name;
        if($CompareResult -ne $NULL) {
            Write-WCLog -Level Error -Message "[Test-WCBValidateCategory] : Duplicate Category Names Exists : " + ([string[]]($CompareResult) -Join ',');
            return $false;
        }
    }
    catch {
        Write-WCLog -Level Error -Message "[Test-WCBValidateCategory] : Error Validating BaseLine XML";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
   return $true; 
}

Function Test-WCBValidatePolicyItem {
<#
  .SYNOPSIS
  Test-WCBValidatePolicyItem
  .DESCRIPTION
  Function to Validate Policy Items  in XML
  .EXAMPLE
  Test-WCBValidatePolicyItem 
  #>
[CmdletBinding()]
Param()
    Write-WCLog -Level debug -Message "[Test-WCBValidatePolicyItem]";
    
    try {
         
        $ColMandatoryFields = "PolicyKey","PolicyName","PolicyType","Id","CompareMethod","DataType","DefaultValue","CurrentValue","TestResult";
        $ColNonEmptyFields = "PolicyKey","PolicyName","PolicyType","Id";
        
        #Validate Policy Mandatory Fields and Non Empty Fields
        $boolStatus = $true
        $colIPolicyItem = (Get-WCXMLNodes -Xml $script:BaselineXML -XPath "//Policy")
		
        ForEach($PolicyItem in $colIPolicyItem) {
            ForEach($MandatoryField in $ColMandatoryFields) {
                if($PolicyItem.$MandatoryField -eq $NULL) { #Check for Mandatory Fields
                    Write-WCLog -Level Error -Message "[Test-WCBValidatePolicyItem] : MandatoryField $MandatoryField is missing for the Policy $($PolicyItem.ID)";
                    $boolStatus = $false;
                }
                elseif($ColNonEmptyFields -contains $MandatoryField) { #Check for NonEmty Fields
                    if($PolicyItem.$MandatoryField -eq "") {
                        Write-WCLog -Level Error -Message "[Test-WCBValidatePolicyItem] : MandatoryField $MandatoryField is Empty for Policy $($PolicyItem.ID)";
                        $boolStatus = $false;
                    }
                }           
            } 
        }
        if($boolStatus -eq $false) { return $false; }
        
        #Validate Duplicate Policy ID
        $CompareResult = ([string[]]($colIPolicyItem | Select-Object ID)  | Group-Object | Where-Object {$_.Count -gt 1}) |Select-Object Name;
        if($CompareResult -ne $NULL) {
            Write-WCLog -Level Error -Message "[Test-WCBValidatePolicyItem] : Duplicate Policy ID Exists : " + ([string[]]($CompareResult) -Join ',');
            return $false;
        }
        
    }
    catch {
        Write-WCLog -Level Error -Message "[Test-WCBValidatePolicyItem] : Error Validating BaseLine XML";
        Write-WCLog -Level Error -Message $_.Exception.Message;
        return $false;
    }
   return $true; 
}
#endregion

# this function will test if Custom Apps are installed during SOE load process
# to be used to set wincompliance test summary item to indicate custom apps installation
# --------------------------------------------------------------------------------------
function test-SOECustomAppsInstallation {
    $customApps = @() # default, there are no custom apps
    $caReg = 'HKLM:\software\csc\SOEAppsInstaller\Custom_Apps' # path of custom apps installed registry
    try {
        $capps = Get-childItem -Path $caReg -Recurse -ErrorAction Stop
        foreach($app in $capps) { 
            $customApps = $customApps + $app.getvalue('appDisplayName') 
        } 
    }
    catch {
        # no custom apps are installed, do nothing
    }
    $customApps # return list of custom apps or an empty array (if no custom apps are found)
}
