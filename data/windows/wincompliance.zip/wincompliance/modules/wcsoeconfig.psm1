# This module will include functions related to converting WC SOE Configurations
# Author: Harikrishnan GN
# Date  : 17-july-2015
# Updated: 06-jun-16 by Umesh - Updated Invoke-SOEConfigFirewall function to consider Nano server too
# Updated: 10-jun-16 by Hari - updated code for Local user based policies support on Nano, added CustomBranding
# ----------------------------------------------------------------------------------------

#Powershell version prerequisite -  the below comment automatically verifies the ps version
#requires -Version 3.0

# ----------------------------------------------------------------------------------------
# This function will apply IPV6 Configurations based on selection from SOEBuild.xml
# ----------------------------------------------------------------------------------------
Function Invoke-SOEConfigIPV6 {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[ValidateSet("Enabled","Disabled")] $DefaultValue #Passed by Remediator.psm1 which will hold the current value data from report.Especially designed for revert action 
)
	#Note Scan result should return either one of the value in the $CurrentValue field
     Write-WCLog -Message "[Invoke-SOEConfigIPV6]"

    #Registry Path for IPV6
    $RegPath = "HKLM:SYSTEM\CurrentControlSet\Services\tcpip6\Parameters"
	$RegKey = "DisabledComponents";
    $IPV6DisableVal = "4294967295"; #Value for Disabled IPV6 config
    $IPV6EnableVal = "0"
    
    try {
		if($Action -eq "scan") {
            #Read Current Status of IPV6
			$Value = Get-WCRegistryValue -KeyPath $RegPath -ValueName $RegKey
			
            #Check IPV6 Status,return value should match currentvalue field in parameter
			if($Value -eq $IPV6DisableVal) { $return = "Disabled"}
			else { $return = "Enabled" }
            Write-WCLog -Level debug -Message "Current Status of IPV6 : $return"
		}  
        else { #For Remediate and Revert
            if($Action -eq "Remediate") { #Note Build Mode is not applicable to Revert
                
                #If the WC is launched in Build Mode then entry in soeconfig.xml takes precedence
                $InstallMode = Get-SOEConfigInstallMode
                Write-WCLog -Level info -Message "BuildMode : $InstallMode";

                if($InstallMode -eq "Build") {
                    #Get IPV6 Status  from XML
                    $result = Get-SOEConfigXMLValue -Setting "IPV6"
                    if($result.length -gt 0) {
                        $DefaultValue = $result;
                    }                   
			    }
            }

            Write-WCLog -Level info -Message "Setting IPV6 Status to $DefaultValue"

            #Set the registry Value if IPV6 is enabled/Disabled
            $ExpectedValue = $IPV6DisableVal;
            if($DefaultValue -eq "Enabled") { $ExpectedValue = $IPV6EnableVal; }

             #Set IPV6
            if(Set-WCRegistryValue -Path $RegPath -Key $RegKey -Value $ExpectedValue -Type "DWord") { $return = "Success"; }

            if($Action -eq "Remediate") {#Update SOE registry key if action is remediate
                #Set SOE Registry for IPV6 only if the action is remediate
			    if(!(Set-WCRegistryValue -Path "HKLM:\SOFTWARE\CSC\SOE" -Key "IpV6" -Value "$($InstallMode)_$DefaultValue" -Type "String")) {
				    $return =  "Failed";
                }
            }         
        }
        #Return failed if IPV6 Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return;
}
# ----------------------------------------------------------------------------------------
# This function will apply SNMP Configurations based on selection from SOEBuild.xml
# ----------------------------------------------------------------------------------------
Function Invoke-SOEConfigSNMP {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[ValidateSet("Enabled","Disabled","Notinstalled")] $DefaultValue, #Passed by Remediator.psm1 which will hold the default/current value data from report.
$CommunityName
)
    $ServiceName = "SNMP";
    $TrapReg = "HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\TrapConfiguration";
    $CommunityReg = "HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\ValidCommunities";
    $arrSNMPFeatures = "SNMP-Service","RSAT-SNMP";

    Write-WCLog -Message "[Invoke-SOEConfigSNMP]"

	try {
		if($Action -eq "scan") {
			#Get Start Mode
            $StartMode = (Get-CimInstance -ClassName Win32_Service -Property StartMode -Filter "Name='$ServiceName'").StartMode
			
            #Check IPV6 Status,return value should match currentvalue field in parameter
            if($StartMode -eq $Null) { $return ="NotInstalled" }
            elseif($StartMode -eq "Disabled") { $return = "Disabled"; }
			else { $return = "Enabled" }

            Write-WCLog -Level debug -Message "Current Status of SNMP : $return"
		}
		else{ 
			if($Action -eq "Remediate") {#Build Mode applicable only for remediate action
				$InstallMode = Get-SOEConfigInstallMode;
				Write-WCLog -Level info -Message "BuildMode : $InstallMode";

				if($InstallMode -eq "Build") {

					#Get SNMP Status and  Community String from soeconfig XML
					$result = Get-SOEConfigXMLValue -Setting "SNMP"
					if($result.length -gt 0) {
						$DefaultValue = $result[0];
						$CommunityName = $result[1];                      
					}
				}
			}
            Write-WCLog -Level info -Message "Setting SNMP Status to : $DefaultValue"

            if($DefaultValue -eq "Notinstalled") {
                
                #Uninstall features installed
                Invoke-SOEConfigWindowsFeatures -Features $arrSNMPFeatures -Action "Remediate" -DefaultValue "UnInstall"

                Write-WCLog -Level info -Message "Removing trap configuration realted to Community String: $CommunityName"
                #Remove Community string
                if(Remove-WCRegistryValue -Path $CommunityReg -Key $CommunityName) {
    			    #ReSet Trap Config
                    if(Test-Path "$TrapReg\$CommunityName") {
                        Remove-Item "$TrapReg\$CommunityName" -Force | Out-Null
                    }
                    $return = "Success";
                }
                else { $return  = "failed" }
                
            }
            else { #enable disable SNMP
    			#Install SNMP if not installed

                Write-WCLog -Level info -Message "Community String: $CommunityName"

                #Install SNMP features
    			Invoke-SOEConfigWindowsFeatures -Features $arrSNMPFeatures -Action "Remediate" -DefaultValue "Installed"
    			
                if($CommunityName.Length -gt 0) {
    			    #Set Community String #assign a temp variable to hold the return value - this return value is not used anywhere
    			    $return = Set-WCRegistryValue -Path $CommunityReg -Key $CommunityName -Value 4 -Type DWord
    			    #Set Trap Config
    	 		    New-Item "$TrapReg\$CommunityName" -Force | Out-Null
    			}

    			if($DefaultValue -eq "Disabled") {
    				#Disable SNMP
    				$res = Set-Service $ServiceName -StartUpType Disabled -ErrorAction SilentlyContinue;
    				$res = Stop-Service $ServiceName -WarningAction SilentlyContinue;
    				
    				$return = "Success";
    			}
    			elseif($DefaultValue -eq "Enabled") {
    				#Enable SNMP
    				$res=Set-Service $ServiceName -StartUpType Automatic
    				$res = Start-Service $ServiceName;

    				$return = "Success";               
    			}
            }
            if($Action -eq "Remediate") {#Update SOE registry key if action is remediate
			#Set SOE Registry for SNMP
			    if(!(Set-WCRegistryValue -Path "HKLM:\SOFTWARE\CSC\SOE" -Key "SNMP" -Value "$($InstallMode)_$DefaultValue" -Type "String")) {
				$return =  "Failed";
                }
            }
		}

		#Return failed if  Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return;
}
# ----------------------------------------------------------------------------------------
# This function will disable Hibernation
# ----------------------------------------------------------------------------------------
Function Invoke-SOEConfigHibernate {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[ValidateSet("on","off")] $DefaultValue
)
	$HibernateFile = "$env:SystemDrive\hiberfil.sys"
    Write-WCLog -Message "[Invoke-SOEConfigHibernate]"

	try {
		if($Action -eq "scan") {
			#Check whether Hibernation File Exists
			if(Test-Path $HibernateFile) { $return = "on" }
            else { $return = "off" }
            Write-WCLog -Level debug -Message "Current Status of Hibernation : $return"
		}
		else {
            
			#Disable/enable Hibernation
			$Arg = "/h $DefaultValue"
			Start-Process 'powercfg.exe' -Verb runAs -ArgumentList $Arg
            Write-WCLog -Level debug -Message "Running Command powercfg.exe $Arg to $DefaultValue Hibernation"

            #Remove Hiberfil.sys if state is off
			if((Test-Path $HibernateFile) -and ($DefaultValue -eq "off")) {								
                 Write-WCLog -Level debug -Message "Removing $HibernateFile"

				#Change File Attributes
				(Get-ChildItem $HibernateFile -Force).Attributes = 'Normal'
				#Delete File
				Remove-Item $HibernateFile -Force;
                
			}
			$return ="Success";
		}

		#Return failed if SOEConfigHibernate Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch {
		$return =  "Error : $($_.Exception.Message)"
	}
	return $return;
}
#-----------------------------------------------------------------------------------------
#This function will query and modify netBIOS over TCP settings
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigNetBIOS {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[ValidateSet("Enabled","Disabled")] $DefaultValue
)
     Write-WCLog -Message "[Invoke-SOEConfigNetBIOS]"

	try {
		$RegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces"
        $ColInterfaces = Get-ChildItem $RegPath | Select-Object Name,PSChildName
        $keyName = "NetBIOSOptions";
		
		$NetBiosDisableVal = "2";
		$NetBiosEnableVal = "0";
        
		if($Action -eq "scan") {
			ForEach($Interface in $ColInterfaces) {
                $Status = "";

                $Status = Get-WCRegistryValue -KeyPath ($Interface.Name -Replace "HKEY_LOCAL_MACHINE","HKLM:") -ValueName $keyName
                if($Status -ne $NetBiosDisableVal) { $return = "Enabled"; } #if one of the interfaces has netBIOS enabled - return Enabled
                Write-WCLog -Level info -Message "NetBIOS Status on Interface $($Interface.name) : $Status"

            }
            if($return -eq $NULL) { $return = "Disabled";}
            Write-WCLog -Level debug -Message "NetBIOS over TCP Status : $return"
		}
		else {
            #Set expected avlue based on defaultvalue
            # 0 -enabled 2 - disabled
            $ExpectedValue = $NetBiosDisableVal;
            if($DefaultValue -eq "Enabled") { $ExpectedValue = $NetBiosEnableVal; }
            
            Write-WCLog -Level info -Message "Setting NetBIOS over TCP to : $DefaultValue"

    		ForEach($Interface in $ColInterfaces) {
                Write-WCLog -Level debug -Message "Setting NetBIOS on $Interface.PSChildName : $DefaultValue"

                #Disable/Enable NetBIOS over TCP for all interfaces
				if (!(Set-WCRegistryValue -Path "$RegPath\$($Interface.PSChildName)" -Key $keyName -Value $ExpectedValue -Type "DWord")) {
				    $return = "Failed";
                }
            }
            if($return -eq $Null) { $return = "Success"; }
		}

		#Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}
# ----------------------------------------------------------------------------------------
# This function will apply Firewall Configurations based on selection from SOEBuild.xml
# ----------------------------------------------------------------------------------------
Function Invoke-SOEConfigFirewall {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[ValidateSet("Enabled","Disabled")] $DefaultValue #Passed by Remediator.psm1 which will hold the current value data from report.Especially designed for revert action 
)

    Write-WCLog -Message "[Invoke-SOEConfigFirewall]"

    #Default SOE Firewall Status
	$RegPath = @();
	$RegPath += "HKLM:\Software\Policies\Microsoft\WindowsFirewall\DomainProfile"
	$RegPath += "HKLM:\Software\Policies\Microsoft\WindowsFirewall\PrivateProfile"
	$RegPath += "HKLM:\Software\Policies\Microsoft\WindowsFirewall\PublicProfile"
	
	$RegKey = "EnableFirewall"
	$LGPOLogPath = "$env:SystemDrive\SUPPORT\Logs\wcBuild"
	$LGPOLogFile = "LGPOFirewall_$((Get-Date).ToString('MMddyyhhmmss')).txt";
    
    $Enablefirewallval = "1"
    $DisableFirewallVal = "0"
    
	try {
		if($Action -eq "scan") {
            ForEach($RPath in $RegPath) {
			    $Value = Get-WCRegistryValue -KeyPath $RPath -ValueName $RegKey
                Write-WCLog -Level debug -Message "Current Status of $(($Regpath -split "\\")[-1]) : $Value"

			    #Check Firewall Status
			    if($Value -eq $Enablefirewallval) { $return = "Enabled";}
            }
            #If firewall sstatus is not enabled, return disabled
            if($return -eq $null) { $return = "Disabled" }
            Write-WCLog -Level info -Message "Current Status of Firewall : $return"
		}
		else {
            if($Action -eq "remediate") {

                $InstallMode = Get-SOEConfigInstallMode

                if($InstallMode -eq "Build") {
                    #Get Firewall Status  from XML
                    $result = Get-SOEConfigXMLValue -Setting "Firewall"
                    if($result.length -gt 0) {
                        $DefaultValue = $result;
                    }
                }    
			}
            
            #Set the RegValue for firewall
            $ExpectedValue = $DisableFirewallVal
            if($DefaultValue -eq "Enabled") {
                $ExpectedValue = $Enablefirewallval
            }
            Write-WCLog -Level info -Message "Setting Firewall Status to $DefaultValue through local group policy"

            # 06-jun-2016 - by Umesh - update code to configure wall on nano server too
            if((Get-WCInterfaceMode -ShortName) -ne 'Nano') { # not running on Nano server
                #configure firewall on full/core using LGPO
			    #Create inf file for applying LGPO_delta
			    if(!(Test-Path $LGPOLogPath)) { New-Item $LGPOLogPath -ItemType Directory -Force | Out-Null }
			    New-Item -Path "$LGPOLogPath\$LGPOLogFile" -ItemType File -Force | Out-Null
			
			    #the variable ExpectedValue will be set to configure Firewall
                #Build the file for applying firewall config through LGPO
			    foreach($RPath in $RegPath) {
				    Add-Content -Path "$LGPOLogPath\$LGPOLogFile" -Value "Computer"
				    Add-Content -Path "$LGPOLogPath\$LGPOLogFile" -Value "$($RPath.SubString(6,$RPath.Length-6))"
                    Add-Content -Path "$LGPOLogPath\$LGPOLogFile" -Value $RegKey
				    Add-Content -Path "$LGPOLogPath\$LGPOLogFile" -Value "DWORD:$ExpectedValue"
                    Add-Content -Path "$LGPOLogPath\$LGPOLogFile" -Value ""
			    }
			    Write-WCLog -Level info -Message "Local Group Policy File Location : $LGPOLogFile"

			    Set-WCRLGPSettings -Path "$LGPOLogPath\$LGPOLogFile"
			    $return = "Success";
            }
            else { #configure firewall on nano using GPRegistryPolicy
                $LGPOLogFile = $LGPOLogFile -replace '.txt','.csv' # rename to .csv
                if(!(Test-Path $LGPOLogPath)) { New-Item $LGPOLogPath -ItemType Directory -Force | Out-Null }
			    New-Item -Path "$LGPOLogPath\$LGPOLogFile" -ItemType File -Force | Out-Null
                # write CSV header
                Write-WCRFile -Path "$LGPOLogPath\$LGPOLogFile" -Value "KeyName,ValueName,ValueType,ValueData"
                # loop thru all policies and add them in CSV
                foreach($RPath in $RegPath) {
                    $cline = "$($RPath.SubString(6,$RPath.Length-6))" # KeyName
                    $cline = "$cline,$RegKey" # ValueName
                    $cline = "$cline,REG_DWORD" # ValueType
                    $cline = "$cline,$ExpectedValue" # ValueData
                    # write policy line to CSV
                    Write-WCRFile -Path "$LGPOLogPath\$LGPOLogFile" -Value $cline
                }
                # CSV created, now apply it
                Write-WCLog -Message "Configuring Windows Firewall status using temp CSV file $LGPOLogPath\$LGPOLogFile"
                Set-WCRLGPSettingsFromCSV -CSVPath "$LGPOLogPath\$LGPOLogFile" 
                Write-WCLog -Message "Windows Firewall status configured, refer to log for details"
            }

            if($Action -eq "Remediate") {#Update SOE registry key if action is remediate
			#Set SOE Branding for Firewall
			    if(!(Set-WCRegistryValue -Path "HKLM:\SOFTWARE\CSC\SOE" -Key "WindowsFirewall" -Value "$($InstallMode)_$DefaultValue" -Type "String")) {
				$return =  "Failed";
            }
            }
		}

		#Return failed if Firewall Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
    }
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return;
}
#-----------------------------------------------------------------------------------------
#This function set Guest Password
#-----------------------------------------------------------------------------------------
Function Set-SOEConfigGuestPassword {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
$Password,
$DefaultValue #Mandatory Parameter - not usedin this function as revert is not applicable
)
	try {
		Write-WCLog -Message "[Set-SOEConfigGuestPassword]"
		$cmdletFound = $false
		
		#ADSI doesnt work in Nano TP5
		if(get-command Get-LocalUser -ErrorAction SilentlyContinue) {
			$objGuest = Get-LocalUser "Guest" -ErrorAction SilentlyContinue
			if($objGuest -eq $null) { $objGuest = Get-LocalUser "SOE-Visitor" -ErrorAction SilentlyContinue } 
			$cmdletFound = $true
		}
		else { #For OS where Get-LocalUser Commamd let is not installed
			$objGuest = [ADSI] "WinNT://$env:computername/Guest"
			if($objGuest.Name -eq $null) {$objGuest = [ADSI] "WinNT://$env:computername/SOE-Visitor"}
		}
		
		if($Action -eq "scan" -or $Action -eq "Revert") {
			$return = "N/A";
		}
		elseif($Action -eq "remediate") {
			#change password
			if($objGuest.Name -ne $null) {
				Write-WCLog -Level info -Message "Setting the guest user password : $($objGuest.Name)"
				if($cmdletFound) {
					$SecurePassword = Convertto-SecureString -String $Password -AsPlainText -Force
					Set-LocalUser -InputObject $objGuest -Password $SecurePassword
				}
				else {
					$objGuest.SetPassword($Password);
				}
				$return = "Success"
			}
			else {
				$return = "User doesnt Exists"
			}			
		}

        #Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}
#-----------------------------------------------------------------------------------------
#This function is to Remove Wndows Update Icon
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigRemoveWindowsUpdateIcon {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[ValidateSet("Enabled","Disabled")]$DefaultValue
)
	try {
        
        #Link to Windows Update Icon
		$Path = "$env:ProgramData\Microsoft\Windows\Start Menu\Windows Update.lnk"

		if($Action -eq "scan") {
			#Check whether Update icon exists
			if(Test-Path "$Path")  { $return = "Disabled"; } 
			else { $return = "Enabled"; }
		}
		else {
        
            if($DefaultValue -eq "Enabled") {
    			if(Test-Path $Path) {
                    Remove-Item "$Path" -Force #Remove Link
                }
            }
            else { #Enabled
                #Yet to be coded
            }
            $return = "Success"
		}

        #Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}
#-----------------------------------------------------------------------------------------
#This function is to Remove Wndows Update Icon
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigNotepadtoSendTo {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[ValidateSet("Enabled","Disabled")]$DefaultValue
)
	try {
        Write-WCLog -Message "[Invoke-SOEConfigNotepadtoSendTo]"

        #Link to Windows Update Icon
		$SourcePath = "$env:UserProfile\Appdata\Roaming\Microsoft\Windows\Start Menu\Programs\Accessories\Notepad.Lnk"
        $DestinationPath = @()
        $DestinationPath += "$env:UserProfile\Appdata\Roaming\Microsoft\Windows\SendTo";
        $DestinationPath += "$env:SystemDrive\USERS\DEFAULT\Appdata\Roaming\Microsoft\Windows\SendTo";
        
		if($Action -eq "scan") {
			ForEach($Path in $DestinationPath) {
                #Test whether the Notepad.lnk exists in above sentoto folders
                if(!(Test-Path "$Path\Notepad.Lnk")) {
                   $return = "Disabled"; 
                }
            }
            if($return -eq  $Null) { $return = "Enabled"; }
            Write-WCLog -Level info -Message "Current status of 'Notepad to Sendto' is : $return"
		}
		else {
            Write-WCLog -Level info -Message "Setting 'Notepad to Sendto' to : $DefaultValue"
            if(Test-Path $SourcePath) {
                if($DefaultValue -eq "Enabled") {
                #Copy the Notepad link to sendto folder
    			$DestinationPath | ForEach-Object {Copy-Item "$SourcePath" -Destination "$_" }
            }
                else { #Disabled
                #Remove the Notepad link to sendto folder
                $DestinationPath | ForEach-Object {Remove-Item "$_\Notepad.Lnk" -Force }
            }
            }
            else { #Notepad.lnk doesnt exists
                $return = "Failed";
                Write-WCLog -Level debug -Message "$SourcePath doesnt Exists";
            }
            $return = "Success";
		}

        #Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}
#-----------------------------------------------------------------------------------------
#Function to Granting Authenticated Users with Read permission for the company Logo in system properties to appear even when UAC in enabled
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigLogo{
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
$OEMLogoPath,
[ValidateSet("Enabled","Disabled")]$DefaultValue
)
	try {
        Write-WCLog -Message "[Invoke-SOEConfigLogo]"

        #Link to company Logo
		$Path =  "$env:SystemDrive\Windows\System32\OEMLOGO.BMP"
        $RegPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation"
        $RegKey = "Logo"
	
		if($Action -eq "scan") {
			 if(Test-Path $Path) {

                #Enssure that registry is set
                $Value = Get-WCRegistryValue -KeyPath $RegPath -ValueName $RegKey
                if($Value -eq $Path) { 
			        $perm = "icacls $path";
                    $Result = Invoke-Expression $perm
					#Authenticated Users should have read permissions for this file
                    if(($Result -join ",") -like "*Authenticated Users:(R)*") { $return = "Enabled" }
                    else { 
                        $return = "Disabled";
                        Write-WCLog -Level debug -Message "Authenticated users doesnt have read permissions on OEMLogo"   
                    }
                }
            }
            else {
                $return = "Disabled";
                Write-WCLog -Level debug -Message "$OEMLogoPath doesnt exists";
            }
            Write-WCLog -Level info -Message "Current Status of company Logo : $return"
        }
		else {
            #If OEM path is relative Path replace it with full path
            if(($OEMLogoPath -like ".\*") -or ($OEMLogoPath -like "..\*")) {
                $OEMLogoPath = "$psScriptRoot\.$OEMLogoPath";
            }

            Write-WCLog -Level info -Message "Setting company Logo Status to $DefaultValue";
            if($DefaultValue -eq "Enabled") {
                if(Test-Path $OEMLogoPath) {
                   
				    #Copy OEM Logo File
                    Write-WCLog -Level debug -Message "Copying $OEMLogopath to $Path"
                    Copy-Item -Path $OEMLogoPath -Destination $Path -Force;
				
				    #Authenticated Users should have read permissions for this file
                    Write-WCLog -Level debug -Message "Setting Authenticated Users read permission to $Path";
                    $perm = " $path /grant *S-1-5-11:" + [char]96 + "(r" + [char]96 + ")";
			        $Result = [string] (Invoke-Expression "icacls $perm");

				    #Get result status
				    if(($Result -join ",") -like "*Successfully Processed 1 File*") {
                        $return ="Success";
                        
                    }
				    else { 
                        $return = "Failed";
                         Write-WCLog -Level debug -Message "Failed while updating ACL";
                    }
				
				    #Set the OEM Logo Registry
				    if(!(Set-WCRegistryValue -Path $RegPath -Key $RegKey -Value $Path -Type "String")) {
					    $return = "Failed";
				    }				
                }
                else {
                    Write-WCLog -Level error -Message "$OEMLogoPath doesnt Exists";
                    $return = "Failed"; 
                }
            }
            else { #company Logo is disabled
                $return  = "Failed" ; #return success if logo file rmoved and registry set;
                if(Test-Path $Path) {
                    Remove-Item $Path -force;
                    if(Remove-WCRegistryValue -Path $RegPath -Key $RegKey) {
					    $return = "Success";
				    }
                }
            }
		}        

        #Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}
#-----------------------------------------------------------------------------------------
#Offer "Edit with NotePad" on right-click menu of files with unregistered file-extentions.
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigUnknownFileApp {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[ValidateSet("Enabled","Disabled")] $DefaultValue
)
 Write-WCLog -Message "[Invoke-SOEConfigUnknownFileApp]"
	try {
        New-PSDrive -PSProvider registry -Root HKEY_CLASSES_ROOT -Name HKCR | out-Null
        $RegPath = "HKCR:\Unknown\shell\Edit_with_NotePad\Command"
		$RegNP = "HKCR:\Unknown\shell\Edit_with_NotePad"
        $RegKey = "(default)"
        $RegValue = "%SystemRoot%\system32\NotePad.Exe " + [char]34 + "%1" + [char]34;

		if($Action -eq "scan") {
            If(Test-Path $RegPath) {
				#Check the resitry key to see if notepad is added to unknown file extensions
                $Value =  Get-ItemProperty -Path $RegPath -Name $RegKey  -ErrorAction SilentlyContinue
				$cValue = [Environment]::ExpandEnvironmentVariables($RegValue)
				$rValue = [Environment]::ExpandEnvironmentVariables($Value.$RegKey)
				
                if($rValue -eq $cValue) { $return ="Enabled" } 
				else { $return = "Disabled" }
               
            }
            else { $return = "Disabled" }

            Write-WCLog -Level info -Message "Add notepad to unknown file config : $return"
		}
		else {
             Write-WCLog -Level info -Message "Setting notepad to unknown file config to $DefaultValue"

             if($DefaultValue -eq "Enabled") {
                # Action is to set the unknwon file extension key
                #Set-WCRegistryValue will not support HKCR so registry set values are updated here
                try {
                    if(!(Test-Path $RegPath)) { New-Item $RegPath -Force | Out-Null; }
                    Set-ItemProperty -Path $RegPath -Name $RegKey -Value $RegValue -Type "ExpandString";
                    Set-ItemProperty -Path $RegNP -Name '(default)' -Value "Edit with Note&Pad" -Type "String";
                    $return = "Success";
                }
                catch {
                      Write-WCLog -Level Error -Message "Error trying to update Registry: $($_.Exception.Message))";
                      $return = "Failed";
                }
			    
		    }
            else {
                #Action is to reset unknown file extensions
                if(Test-Path $RegPath) {
                    Write-WCLog -Level info -Message "Removing $RegPath";
                    Remove-Item $RegPath -Force;
                    $return = "Success";
                }
            }
        }

        #Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}
#-----------------------------------------------------------------------------------------
#Function to Disable NIC Power Management
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigNICPowerMgmt {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[ValidateSet("Enabled","Disabled")]$DefaultValue
)
Write-WCLog -Message "[Invoke-SOEConfigNICPowerMgmt]"
	try {
		
        $nwAdapterList = Get-CimInstance -ClassName Win32_NetworkAdapter -filter "AdapterTypeId=0"       
        $msPowerDeviceList = Get-WMIObject -ClassName MSPower_DeviceEnable -Namespace "root\WMI" -ErrorAction SilentlyContinue

        if($Action -eq "scan") {
			if($msPowerDeviceList -eq $null) { $return = "Disabled" }
			
            forEach($nwAdapter in $nwAdapterList) { #For Each NIC Adapter in the server
                $strNetworkAdapterID=$nwAdapter.PNPDeviceID.ToUpper()
                $msPowerDevice = $msPowerDeviceList | Where-Object { $_.InstanceName -like "$($strNetworkAdapterID)*" } 
                
                if($msPowerDevice){
                    if($msPowerDevice.Enable -eq $True) { #If Powermgmt is true then return enabled
                        $return = "Enabled";
                    }
                    Write-WCLog -Level info -Message "$strNetworkAdapterID : $($msPowerDevice.Enable)";
                }
            }
            if($return -ne "Enabled") {
                $return = "Disabled";
            }
        }
        else {
			if($msPowerDeviceList -eq $null) { 
				Write-WCLog -Level debug -Message "No Action taken and PowerMgmt is not applicable";
				return "Success";
			}
			
            Write-WCLog -Level info -Message "Setting the NICPowerManagement to $DefaultValue";
            if($DefaultValue -eq "Enabled") { $ExpectedValue = $True; }
            else { $ExpectedValue = $False; }

            forEach($nwAdapter in $nwAdapterList) { #For Each NIC Adapter in the server
                $strNetworkAdapterID=$nwAdapter.PNPDeviceID.ToUpper()
                $msPowerDevice = $msPowerDeviceList | Where-Object { $_.InstanceName -like "$($strNetworkAdapterID)*" } 
                
                if($msPowerDevice){
                    $msPowerDevice.Enable = $ExpectedValue #Disable/Enable NIC Power Mgmt
                    $msPowerDevice.Put() | Out-Null
                    Write-WCLog -Level debug -Message "Setting $strNetworkAdapterID : $ExpectedValue";
                }
            }
			$return ="Success"
        }

        #Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}
#-----------------------------------------------------------------------------------------
#This function will query and modify All User Settings
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigAllUser {
Param(
[ValidateSet("Remediate","Revert")] $Action,
$ProfilePolicyNode
)
    
    #command to unload registry hive		
	$regUnLoad = "& reg unload HKLM\SOETEMP 2>&1"

    #remediation has to happen for all users  who has profile including default user
    #get all users profile except current user profile as its already in use and cannot be loaded, including hidden ones
    $colUserProfiles = Get-Childitem "$env:SystemDrive\Users" -Directory -Force | Where-Object { $_.FullName -ne "$env:UserProfile" } 

    foreach($uProfile in $colUserProfiles) {
        if(Test-Path "$($UProfile.FullName)\NTUSER.DAT") {
            
            try {
                #Load registry for each user
                $regLoad =  "reg load HKLM\SOETEMP '$($UProfile.FullName)\NTUSER.DAT'"
                $ret = Invoke-Expression $regLoad

                foreach($ProfilePolicy in $ProfilePolicyNode) {
                    try {
                        $splitPath = ($ProfilePolicy.PolicyKey -split "-")

                        #identify the reistry key path and type
                        $RegPath = ($splitPath -match "RegPath").replace("RegPath","").Trim()
                        if($RegPath -like "'*'") { $RegPath = $RegPath.SubString(1,$RegPath.Length-2) }

                        $RegKey = ($splitPath -match "RegKey").replace("RegKey","").Trim()
						if($RegKey -like "'*'") { $RegKey = $RegKey.SubString(1,$RegKey.Length-2) }
						
                        $RegType = ($splitPath -match "RegType").replace("RegType","").Trim()
						if($RegType -like "'*'") { $RegType = $RegType.SubString(1,$RegType.Length-2) }

                        #if action is remedoate user default value if its rever use current value
                        $psDefValue = $ProfilePolicy.DefaultValue
                        if($Action -eq "Revert" ) { $psDefValue = $ProfilePolicy.CurrentValue }

                        if($psDefValue.ValueEnumeration -ne $Null) { #default value is an array
						    $psValue = $psDefValue.ValueEnumeration	
					    }
					    else {
						    $psValue = $psDefValue.Value #DefaultValue is a string
					    }
                            
                        Write-WCLog -Level info -Message "Setting $RegPath\$RegKey : $psValue for UserProfile : $($UProfile.FullName)"

                        #remove the registry key if default value is notexists
                        if($psValue -eq "NotExists") {
                            if(Test-WCRegistryValue -Path "HKLM:\SOETEMP\$RegPath" -Name $RegKey ) {
                                Remove-ItemProperty -Path "HKLM:\SOETEMP\$RegPath" -Name $RegKey -Force;
                                Write-WCLog -Level debug -Message "Successfully Removed the Key";
                            }
                        }
                        else {
                            #Remediation Action is to set the registry key
		                    if(Set-WCRegistryValue -Path "HKLM:\SOETEMP\$RegPath" -Key $RegKey -Value $psValue -Type $RegType) {
                                 Write-WCLog -Level debug -Message "Successfully updated the Key";   
		                    }
                        } 
                    }
                    Catch { 
                        Write-WCLog -Level Error -Message $_.Exception.Message; 
                    }
                }

                #Close all handles before Unload
		        [gc]::Collect();
		        [gc]::WaitForPendingFinalizers();
		        $ret = Invoke-Expression $regUnLoad;

            }                 
            Catch { 
                Write-WCLog -Level Error -Message $_.Exception.Message; 
            }
        }
    }
}

#-----------------------------------------------------------------------------------------
#This function will query and modify DefaultUser Settings
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigDefaultUser {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
$RegPath,
$RegKey,
$RegType,
$DefaultValue,
$ProfilePolicyNode
)
Write-WCLog -Message "[Invoke-SOEConfigDefaultUser]"

	try {
        #command to unload registry hive		
		$regUnLoad = "& reg unload HKLM\SOETEMP 2>&1"

        #If Profile Policy List is passed then its a node list perform remediation for all users in nodelist
        if($ProfilePolicyNode -ne $null -and $Action -ne "Scan") { 
            Invoke-SOEConfigAllUser -Action $Action -ProfilePolicyNode $ProfilePolicyNode
        }	
		elseif($Action -eq "scan") {
            $regLoad =  "reg load HKLM\SOETEMP $env:SystemDrive\Users\Default\NTUser.Dat"
		    $ret = Invoke-Expression $regLoad
            
            If(Test-Path "HKLM:\SOETEMP\$RegPath") {
			    $Value =  Get-WCRegistryValue -KeyPath "HKLM:\SOETEMP\$RegPath" -ValueName $RegKey
                $return= $Value;
            }
    		#Close all handles before Unload
		    [gc]::Collect();
		    [gc]::WaitForPendingFinalizers();
		    $ret = Invoke-Expression $regUnLoad;

		}
		else { #default User Remediate
            $regLoad =  "reg load HKLM\SOETEMP $env:SystemDrive\Users\Default\NTUser.Dat"
		    $ret = Invoke-Expression $regLoad

            Write-WCLog -Level info -Message "Setting $RegKey : $DefaultValue"
            #remove the registry key id default value is notexists
            if($DefaultValue -eq "NotExists") {
                if(Test-WCRegistryValue -Path "HKLM:\SOETEMP\$RegPath" -Name $RegKey ) {
                    Remove-ItemProperty -Path "HKLM:\SOETEMP\$RegPath" -Name $RegKey -Force;
                    Write-WCLog -Level debug -Message "Successfully Removed the Key";
                }
            }
            else {
                #Remediation Action is to set the unknwon file extension key
		        if(Set-WCRegistryValue -Path "HKLM:\SOETEMP\$RegPath" -Key $RegKey -Value $DefaultValue -Type $RegType) {
                    $return = "Success"
		        }
            }
    		#Close all handles before Unload
		    [gc]::Collect();
		    [gc]::WaitForPendingFinalizers();
		    $ret = Invoke-Expression $regUnLoad;
        }
        #Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { 	
		$return =  "Error : $($_.Exception.Message)";
	}
	finally {
		if($ret -like "*access is denied*") {
			[gc]::Collect();
			[gc]::WaitForPendingFinalizers();
			Start-Sleep -s 1;
			$ret = Invoke-Expression $regUnLoad;
		}
	}
	
	return $return
}
#-----------------------------------------------------------------------------------------
#File Actions PinUnpin Items.
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigPinUnpinItems {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
$NameSpace,
$ParseName,
$Name,
[ValidateSet("Pin","Unpin","N/A")] $DefaultValue
)
Write-WCLog -Message "[Invoke-SOEConfigPinUnpinItems]"

	try {
        $SA = new-object -c Shell.Application;
		$PN = $SA.namespace($NameSpace).ParseName($ParseName) 
			 
        if($Action -eq "Scan") { 
            
            $vName = ($PN.Verbs() | select Name)
            #If verb contains Pin to item then return status in Unpin
            if($vName -match "Pin to $Name") { $return = "UnPin"; } 
            elseif($vName -match "UnPin from $Name") { $return = "Pin"; } #if viceversa return pin
            else { $return = "N/A"; } #else return Not applicable
            
            Write-WCLog -Level info -Message "$ParseName $Name : $return"
        }
		elseif($DefaultValue -ne "N/A") {

             #If the DefaultValue is Pin append "Pin to" else append "Unpin from"
             if($DefaultValue -eq "Pin") { $pinName = "Pin to $Name"; }
             else { $pinName = "Unpin from $Name"; }

             #Pin Unpin Item
             $verbAction = $PN.Verbs() | Where-Object { $_.Name -eq $pinName }; #pin/unpin items
             if($verbAction -ne $Null) { 
                $VerbAction.Doit();
                $return ="Success";
                Write-WCLog -Level debug -Message "Succesfully completed the action  : $pinName";
            }
            else {
                $return = "Failed";
                Write-WCLog -Level error -Message "Unable to find Parse name in Verbs";
            }
		}

		#Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}
#-----------------------------------------------------------------------------------------
#SOE Configurations Common to pre and post Imaging
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigImaging {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
$NameSpace,
$ParseName,
$Name
)
	try {
		if($Action -eq "remediate") {
			#showing hidden files if user is build administrator during profile load for post imaging purposes as sysprep will have removed build admin spec settings
            $currentuser = Get-CimInstance -ClassName Win32_UserAccount  -Filter "name='$env:username' and domain='$env:userdomain'";
			if($currentUser.SID.Contains('S-1-5-21') -and $currentUser.SID.Contains('-500')) {
				#Display protected operating system files 
				if(!(Set-SOEConfigRegistryValue -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Key "ShowSuperHidden"  -Value 1 -Type "DWORD")) {
					$return = "Failed";
				}
				#Show Hidden Files
				if(!(Set-SOEConfigRegistryValue -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Key "Hidden" -Value 1 -Type "DWORD")) {
					$return = "Failed";
				}
				#Remove Desktop ini
				Remove-Item "$([System.Environment]::ExpandEnvironmentVariables("%UserProfile%"))\Desktop\Desktop.ini" -Force
				if($return -ne "Failed") {$return = "Success";}
			}
			else { $return = "Success" }
		}
		else { #Scan and Revert is not applicable for this setting
			$return = "N/A";
		}
		#Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}


#Function to enable Windows Features
Function Invoke-SOEConfigWindowsFeatures {
Param(
	[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
	[Parameter(Mandatory=$true,ParameterSetName="Features")][string[]] $Features,
    [ValidateSet("Installed","Uninstall","Available","NotAvailable")] $DefaultValue,
	$IfFeatureNotInstalled,
	[Switch]$force
)
    
    Write-WCLog -Message "[Invoke-SOEConfigWindowsFeatures]"
	#Identify OS for 2k8 as for 2k8 we will need to use ADD-WindowsFeature and Remove-WindowsFeature
	if((get-ciminstance -ClassName win32_operatingsystem).Version.startsWith("6.1.")) { $OS = "2K8" }
	
	try {
		if($IfFeatureNotInstalled -ne $null -and $Action -ne "Scan") {
			$returnVal = Test-SOEConfigFeatureInstalled -default_Features $IfFeatureNotInstalled
			#Exit if Default Features are already installed 
			if($returnVal -ne "false") { return $returnVal }
		}
		#Read the current status of features to install
	   $FeaturestoInstall = get-WindowsFeature $Features 

        #return term Not available if its a invalid feature
        if($FeaturestoInstall -eq $null) { 
            $return = "NotAvailable";
            Write-WCLog -Level info -Message "Features $($Features -join ",") are not available on this server."
         } 
        else {
            #Identify pending features to be installed/Installed
            $pFeaturestoInstall = ($FeaturestoInstall | Where-Object { $_.Installed -eq $false }).Name
            $pFeaturestoUninstall = ($FeaturestoInstall | Where-Object { $_.Installed -eq $True }).Name
            
            if($Action -eq "Scan") {#Action Scan
                #If there are no pending features to be installed return Insatlled
                if($pFeaturestoInstall -eq $null) { $return = "Installed" } 
                else { $return = "Available" } #else return Not Installed
                Write-WCLog -Level info -Message "Current Status of Feature $($Features -join ",") : $return"
            }
            else {
                Write-WCLog -Level info -Message "$($DefaultValue)ing $($Features -join ",")";
                if($DefaultValue -eq "Installed") {	#Features tp Install

                    if($pFeaturestoInstall -ne $Null) {	#Install Pending Features if present
					
						if($OS -eq "2K8") {
							$returnVal = Add-WindowsFeature $pFeaturestoInstall -ErrorAction SilentlyContinue;
						}
						else {
							#Installing ServerRole/Features
							$returnVal = Install-WindowsFeature $pFeaturestoInstall -ErrorAction SilentlyContinue;
						}
                        #If success field is not true then return exit code
                        if($returnVal.Success -eq $false) { $return = $returnVal.ExitCode + "," + $Error[0].ToString() }
                        else { $return = "Success";}

                        Write-WCLog -Level debug -Message "Return Value : $return";
                    }
					else { #features are already installed
						$return = "Success"
					}
                }
                elseif($DefaultValue -eq "Uninstall" -or $DefaultValue -eq "Available") {	#Features to Uninstall

                    if($pFeaturestoUninstall -ne $Null) {	#Install Pending Features if present
						if($OS -eq "2K8") {
							$returnVal = Remove-WindowsFeature $pFeaturestoInstall -ErrorAction SilentlyContinue;
						}
						else {
							#UnInstalling ServerRole/Features
							$returnVal = UnInstall-WindowsFeature $pFeaturestoUninstall -ErrorAction SilentlyContinue;
						}
                
                        #If success field is not true then return exit code
                        if($returnVal.Success -eq $false) { $return = $returnVal.ExitCode + "," + $Error[0].ToString() }
                        else { $return = "Success";}
                        Write-WCLog -Level debug -Message "Return code : $returnVal";

                    }
					else { #features are already uninstalled
						$return = "Success"
					}
                }
            }
        }

        #If no operation or incase of a failure, mark the test as failed
        if($return -eq $Null) { $return = "Failed" }
	}
    catch {
         $return = $_.Exception.Message;
    }
    return $return;
}

#Function to DisableUser Account
Function Invoke-SOEConfigLocalUser {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[Parameter(Mandatory=$True)]$UserName,
[ValidateSet("Enabled","Disabled")]$DefaultValue
)

Write-WCLog -Message "[Invoke-SOEConfigLocalUser]"
try {
		$cmdletFound = $false;
		
        #Read User Profile
		#windows server 2016 and above especially nano
		#ADSI doesnt work in Nano TP5
		if(get-command Get-LocalUser -ErrorAction SilentlyContinue) {
			$oUser = Get-LocalUser $UserName -ErrorAction SilentlyContinue
			$cmdletFound = $true
		}
		else { #For OS where Get-LocalUser Commamd let is not installed
			$oUser = [ADSI] "WinNT://$env:computername/$UserName"
		}

        if($oUser.Name -ne $Null) {
             if($Action -eq "Scan") {
				if($cmdletFound) { #Use ps commandlets in case of Windows Server 2016
					if($oUser.Enabled -eq $True) { $return = "Enabled" }
					else { $return = "Disabled"}
				}
				else { #for older OS
					if($oUser.AccountDisabled -eq $True) { $return = "Disabled" }
					else { $return = "Enabled"}
				}
                Write-WCLog -Level info -Message "Current Status of $Username : $return"
            }
            else { #action remediate or revert
                Write-WCLog -Level info -Message "Setting Status of $UserName : $DefaultValue"
				
				if($cmdletFound) {#Use ps commandlets to disable /enable user in case of Windows Server 2016
					if($DefaultValue -eq "Disabled")  {
						Disable-LocalUser -Name $UserName
					}
					else {
						Enable-LocalUser -Name $UserName
					}
				}
				else { #on OS where get-localuser is not supported
					if($DefaultValue -eq "Disabled") { #Disable User
						$oUser.InvokeSet("AccountDisabled", "True")
						$oUser.SetInfo() | out-null;
					}
					else { # Enable User
						 $oUser.InvokeSet("AccountDisabled", "False")
						 $oUser.SetInfo() | out-null;
					}
				}				
                $return = "Success";
            }
        }
        else {
            $return = "User Doesnt Exists";
        }

        #If no operation or incase of a failure, mark the test as failed
        if($return -eq $Null) { $return = "Failed" }
    }
    Catch {
        $return = $_.Exception.Message;
    }
    return $return
}

#-----------------------------------------------------------------------------------------
#SOE Configurations Set Tunneling Interface
#-----------------------------------------------------------------------------------------
Function Invoke-SOEConfigTunnelingInterface {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
[Parameter(Mandatory=$True)]
[ValidateSet("teredo","6to4","isatap")]$Interface,
[ValidateSet("Automatic","Client","Default","Disabled","EnterpriseClient","Relay","Server","Enabled")] $DefaultValue,
[Switch]$UseNetsh
)
 
Write-WCLog -Message "[Invoke-SOEConfigTunnelingInterface]"

	try {
		if($Action -eq "Scan") {
            if($UseNetsh.IsPresent) {
				Switch($Interface) { #get state
					"Teredo" { $return = (netsh int teredo show state | Select-String "Type").ToString().Split(":")[1].Trim();break;}
					"6to4" { $return = (netsh int 6to4 show state | Select-String "State").ToString().Split(":")[1].Trim();break; }
					"ISATAP" { $return = (netsh int ISATAP show state | Select-String "State").ToString().Split(":")[1].Trim();break; }
				}
			}
			else {
				Switch($Interface) { #get state
					"Teredo" { $return = (Get-NetTeredoConfiguration -ErrorAction "SilentlyContinue").Type;break;}
					"6to4" { $return = (Get-Net6to4Configuration -ErrorAction "SilentlyContinue").State;break; }
					"ISATAP" { $return = (get-NetIsatapConfiguration -ErrorAction "SilentlyContinue").State;break; }
				}
			}
             Write-WCLog -Level info -Message "$Interface Status : $return";
        }
        else { #perform remediation or revert
            Write-WCLog -Level info -Message "Setting $Interface Status to : $DefaultValue";
            If($UseNetsh.IsPresent) {
				Write-WCLog -Level info -Message "Netsh is used to set this mode";
				Switch($Interface) { 
					"Teredo" { $return = (netsh interface teredo set state type=$DefaultValue);break;}
					"6to4" { $return = (netsh interface 6to4 set state state=$DefaultValue undoonstop=$DefaultValue);break; }
					"ISATAP" { $return = (netsh interface isatap set state $DefaultValue);break; }
				}
				
				if($return -eq "ok.") { $return = "Success" }
			}
			else {
				Switch($Interface) { #Set state
					"Teredo" { Set-NetTeredoConfiguration -Type $DefaultValue; $return = "Success";break;}
					"6to4" { Set-Net6to4Configuration -State $DefaultValue; $return = "Success"; break;}
					"ISATAP" { Set-NetIsatapConfiguration -State $DefaultValue; $return = "Success";break; }
				}
			}
        }

         #Return failed if Status is not checked or remediated is not processed
		if($return -eq $Null) { $return = "Failed"; }
	}
	catch { $return =  "Error : $($_.Exception.Message)" }
	
	return $return
}

#----------------------------------------------------------------------
#Function to update Custom Branding
#----------------------------------------------------------------------
Function Invoke-SOEConfigCustomAccountBranding {
[CmdletBinding()]
Param(
[ValidateSet("Scan","Remediate","Revert")] $Action = "Scan",
$DefaultValue
)
    
    try  {
        Write-WCLog -Level debug -Message "Updating Account Branding"
        $RegPath = "HKLM:\SOFTWARE\CSC\SOE"
        $RegKey = "CustomBranding"
        if($Action -eq "Scan") {
            If(Test-Path $RegPath) {
			    $return =  Get-WCRegistryValue -KeyPath $RegPath -ValueName $RegKey
            }
            else {
                $return = "NotExists"
            }
        }
	    elseif($Action -eq "remediate") {

            $InstallMode = Get-SOEConfigInstallMode
            $return = "Success"
            if($InstallMode -eq "Build") {
                #Get AccountName from XML
                $AccountName = Get-SOEConfigXMLValue -Setting "CustomBranding"

                #Update Registry
                if($AccountName.length -gt 0) {
					#Get Existing BrandName if exists - SOE Customization Tool created same key
					$ExistingName =  Get-WCRegistryValue -KeyPath $RegPath -ValueName $RegKey
					
					#Append AnnounceName if AlreadyExists
                    if($ExistingName -ne "" -and $ExistingName -ne "NotExists") {
                        $ExistingName = $ExistingName.Replace("`n","") 
                        $AccountName = "$($ExistingName)_$($AccountName)"
                     }
					 
                    if(!(Set-WCRegistryValue -Path $RegPath -Key $RegKey -Value $AccountName -Type "String")) {
						$return = "Failed";

                    }
                }
            }    
		}
    }
    catch {
        $return = $_.Exception.Message;
    }
    return $return;
}
#region Common Functions to support SOE Config
#Function to read the BaseLine XML File
Function Get-SOEConfigXML($SBMConfigXML) {

	try {
		if(Test-Path $SBMConfigXML) {
			$xmlSBM = [xml](get-content $SBMConfigXML)
		}
	}
	catch {}
	return $xmlSBM
}

# ------------------------------------------------------
# This function will get Windows Server Licensing Status
#-------------------------------------------------------
Function Get-WindowsActivationStatus {
    [CmdletBinding()]
    Param(
    [ValidateSet("Scan")] $Action = "Scan")
    # 14-jun-2016 - by Umesh - ensure slmgr doesn't run on nano
    if((Get-WCInterfaceMode -ShortName) -ne 'Nano') { # not running on Nano server
        $ls = ((cscript (Get-Command slmgr).path -dli) -match "License Status").split(":")[1].trim()
        return $ls
    }
    else { # this is nano box
        # TODO: remove below line and update this block with actual nano license implementation
        return 'not implemented on nano yet' # remove and replace it with actual Nano implementation when available
    }
}

#Function to Get Install Mode
Function Get-SOEConfigInstallMode{
	If(Test-Path "$env:systemdrive\SUPPORT") {
		If ((Test-Path -Path "$env:systemdrive\SUPPORT\sbmConfig.xml") -and ((Get-ChildItem "$env:systemdrive\SUPPORT" -Directory | Where-Object { $_.Name -Like "BOOT*" }) -ne $NULL)) {
			$return =  "Build" #Detected as running within the original Windows Server SOE Install process
		}
	}
	if($return -eq $NULL) { 
		$return =  "Modular" #Detected as running as a standalone module
	}
	return $return;
}

#Function to test whether default roles for a ServerRole SOE is already installed
Function Test-SOEConfigFeatureInstalled($default_Features) {
	#Read the state of Default Features
    $State = Get-WindowsFeature $default_Features;
    if ($State -eq $NULL) {
        return "Unknown Default Feature list in ServerRole XML";
    }
    elseif($State.Installed -contains "True")
    {
        return "The features for this role is already installed.No Action taken."
    } 
    else {
        return "false";
    }
}

#Function to validate that the ServerRolexml is applicable to current OS
Function Test-SOEConfigSOECompatibility($ServerRoleXML) {
	
	#Get the SOE Version if exists
	If(Test-Path "HKLM:SOFTWARE\CSC\SOE") { 
        
        try { #Adding a try catch just to skip the error
            #Read SOE Version
		    $SOE = Get-ItemPropertyValue -Path "HKLM:SOFTWARE\CSC\SOE" -Name "GlobalVersion" -ErrorAction SilentlyContinue;
        }
        Catch {}

		if($SOE -ne $NULL) { #Incase of Vannila build SOE version will be null

			#"SOE Version : $SOE" ;
			#"BaselineXML SOE Version :$($ServerRoleXML.SOE)";

			if($SOE -like $ServerRoleXML.SOE) { #Compare SOE Version with XML version
				#"XML is compatible with current SOE version";
				return "True";
			}
			else { #SOE Version is not compatible
				return "XML is not compatible with current SOE version";
			}
		}
	}

	#If SOE key is not present use OS comparison. incase of non SOE build etc
	if($SOE -eq $NULL) {
		#Get OS Version
		$OS = (Get-CimInstance -ClassName Win32_Operatingsystem -Property Caption).Caption

		if($OS -like $ServerRoleXML.OS) {
			#"XML is compatible with current SOE version";
			return "True";
		}
		else { #SOE Version is not compatible
			   return "XML is not compatible with current OS version";
		}
	}
    
}

#Function read SOE Config XML
Function Get-SOEConfigXMLValue {
Param(
[ValidateSet("SNMP","IPV6","Firewall","CustomBranding")]$Setting)

	$sbmConfigXML = "$env:SystemDrive\SUPPORT\sbmconfig.xml";
	
    Write-WCLog -Level debug -Message "Reading $Setting status from sbmConfig.xml"

    $xmlSBM = Get-SOEConfigXML -SBMConfigXML $SBMConfigXML #Read SOEConfig XML

    $return =@();

    try {
	    if($xmlSBM -ne $null) {
            if($Setting -eq "IPV6") {
		        if($xmlSBM.BuildManager.EnableIPV6 -ne $null) {
			        if($xmlSBM.BuildManager.EnableIPV6 -eq "true") { #If ipv6 is enabled in SBMConfig.xml return enabled
				        $return += "Enabled";
			        }
                    else { #else return Disabled
                        $return += "Disabled";
                    }
                    Write-WCLog -Level debug -Message "IPV6 Status from XML : $result"
		        }
            }
            elseif($Setting -eq "SNMP") {
                if($xmlSBM.BuildManager.SNMP.Enabled -ne $null) { #Read SNMP Configuration
				    if($xmlSBM.BuildManager.SNMP.Enabled -eq "true") { #If SNMP is enabled in SBMConfig.xml then return enabled
					    $return += "Enabled"
				    }
                    else { $return += "Disabled" } #return disabled
		        }
			    #Get Community Name
			    if($xmlSBM.BuildManager.SNMP.CommunityName -ne $null) {
				    $return += $xmlSBM.BuildManager.SNMP.CommunityName;
			    }
                else { $return +="" }
            
                Write-WCLog -Level debug -Message "SNMP Status from XML : $($return[0])"
                Write-WCLog -Level debug -Message "Community String from XML : $($return[1])"   
            }
            elseif($Setting -eq "CustomBranding") {
                if($xmlSBM.BuildManager.CustomBranding) {
                    $return = $xmlSBM.BuildManager.CustomBranding;
                }
            }
            elseif($Setting -eq "Firewall") {
                if($xmlSBM.BuildManager.EnableWindowsFirewall -ne $null) { #read firewall status
			        if($xmlSBM.BuildManager.EnableWindowsFirewall -eq "true") { #If Firewall is enabled in SBMConfig.xml then set the status to enabled
					    $return += "Enabled";
				    }
                    else {
                        $return += "Disabled";
                    }
                    Write-WCLog -Level debug -Message "Firewall Status from XML : $result"
		        }  
            }
	    }
        else {
            Write-WCLog -Level debug -Message "SOE Config file doesnt exists or XML is corrupt"
        }
    }
     Catch {
        $return = "Error : $($_.Exception.Message)" 
    }
    return $return
}

#endregion

