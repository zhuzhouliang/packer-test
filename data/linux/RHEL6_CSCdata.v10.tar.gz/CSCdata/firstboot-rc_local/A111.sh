#!/bin/bash
#
echo Do some change to the system

exit 0
