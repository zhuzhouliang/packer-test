#!/bin/bash
#
echo This shell should not be called !!!

exit 0
